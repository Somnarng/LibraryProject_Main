// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

//#define ENABLE_GODOT_EXPORT

#include "Runtime/Launch/Resources/Version.h"
#include "GameFramework/Actor.h"
#include "Engine/StaticMesh.h"
#include "Engine/TextureDefines.h"
#include <string>

void DoExportScene( UWorld *World, FString ExportFolder );
int64_t LoadFile( const char *File, uint8** data );
bool SaveFile( const char *File, void *data, int64_t size );
bool VerifyOrCreateDirectory( const wchar_t * TestDir );
bool VerifyOrCreateDirectory( const FString& TestDir );
void ExportFBXForActor( AActor* Actor );
int StringReplacement( std::string& OriginalString, const char* What, const char* Replace, int StartPos = 0 );

class UMaterial;
class UMaterialInstance;
class FMaterialResource;
class FMaterialRenderProxy;
class USkeletalMesh;
class UPrimitiveComponent;
class UAnimSequence;
class UMaterialExpression;
class USkeletalMeshComponent;
struct FExpressionInput;
struct FScalarMaterialInput;
struct FColorMaterialInput;
class UMaterialFunctionInterface;

struct MaterialBinding
{
	MaterialBinding();
	FString GenerateName();

	class UMaterialInterface *MaterialInterface = nullptr;
	class UnityMaterial *UnityMat = nullptr;
	FString ShaderSource;

	//IntermediaryData
	UMaterial*			BaseMaterial = nullptr;
	UMaterialInstance*	MaterialInstance = nullptr;
	FMaterialResource*	MaterialResource = nullptr;
	FMaterialRenderProxy*	RenderProxy = nullptr;
	int ID = 0;
	TArray<FString> TextureParamNames;
};

class UnityMesh;
class UnityTexture;

class MeshBinding
{
public:
	UnityMesh* TheUnityMesh = nullptr;
	UStaticMesh* UnrealStaticMesh = nullptr;
	USkeletalMesh* UnrealSkeletalMesh = nullptr;
	UPrimitiveComponent* MeshComp = nullptr;
	AActor* OwnerActor = nullptr;
	int LOD = 0;
	int TotalLods = -1;
	UAnimSequence* AnimSequence = nullptr;
};

#if ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 26

struct FPreshaderDataContext
{
	explicit FPreshaderDataContext( const FMaterialPreshaderData& InData )
		: Ptr( InData.Data.GetData() )
		, EndPtr( Ptr + InData.Data.Num() )
		, Names( InData.Names.GetData() )
		, NumNames( InData.Names.Num() )
	{
	}

	explicit FPreshaderDataContext( const FPreshaderDataContext& InContext, const FMaterialUniformPreshaderHeader& InHeader )
		: Ptr( InContext.Ptr + InHeader.OpcodeOffset )
		, EndPtr( Ptr + InHeader.OpcodeSize )
		, Names( InContext.Names )
		, NumNames( InContext.NumNames )
	{
	}

	const uint8* RESTRICT Ptr;
	const uint8* RESTRICT EndPtr;
	const FScriptName* RESTRICT Names;
	int32 NumNames;
};

#endif
#if 0//ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 3

#include "Shader/ShaderTypes.h"
#include "Shader/PreshaderTypes.h"
#include "Runtime/Engine/Private/Shader/PreshaderEvaluate.h"
//Causes a weird template error in 5.4 !!!
using namespace UE::Shader;

struct FPreshaderDataContext2
{
	FPreshaderDataContext2( const FPreshaderData& InData )
		: Ptr( InData.Data.GetData() )
		, EndPtr( Ptr + InData.Data.Num() )
		, Names( InData.Names )
		, StructTypes( InData.StructTypes )
		, StructComponentTypes( InData.StructComponentTypes )
	{
	}

	FPreshaderDataContext2( const FPreshaderDataContext2& InContext, uint32 InOffset, uint32 InSize )
		: Ptr( InContext.Ptr + InOffset )
		, EndPtr( Ptr + InSize )
		, Names( InContext.Names )
		, StructTypes( InContext.StructTypes )
		, StructComponentTypes( InContext.StructComponentTypes )
	{
	}
	const uint8* RESTRICT Ptr;
	const uint8* RESTRICT EndPtr;
	TArrayView<const FScriptName> Names;
	TArrayView<const FPreshaderStructType> StructTypes;
	TArrayView<const EValueComponentType> StructComponentTypes;
};
#endif

TArray<UMaterialExpression*> GetExpressions( UMaterial* Material );
const TArray<FStaticMaterial>& GetStaticMaterials( const UStaticMesh* StaticMesh );
class UExporter;
bool UseUEExporter( UExporter* ExporterToUse, UObject* ObjectToExport, FString Filename, bool ShowOptions = true );
UExporter* GetExporterForAsset( UObject* Asset, FString* RequiredName = nullptr );

class TextureBinding;

#if ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION < 26
	#define TArray64 TArray
#endif

class UETextureExporter
{
public:
	static void ConvertToColors( TArray64<uint8>& SourceData, ETextureSourceFormat Format, int32 Width, int32 Height, int32 Depth, TArray<FColor>& InputImageData, FString TextureFileName );
	static bool DoExport( UTexture* Tex );
	static bool CompressAndSaveTexture( FString TextureFileName, TArray<FColor>& InputImageData, int Width, int Height );
	static TextureBinding* Find( UTexture* Tex );
	static TextureBinding* Export( UTexture* T );
};

class TextureBinding
{
public:
	UnityTexture* UnityTex = nullptr;
	UTexture* UnrealTexture = nullptr;
	bool IsNormalMap = false;
	FGraphEventRef TaskHandle = nullptr;
};

TArray<UMaterialExpression*> GetMaterialExpressionsIncludingFunctions( UMaterialInterface* Mat );
const TArray<UMaterialExpression*> GetFunctionExpressions( UMaterialFunctionInterface* MaterialFunction );
TArray<UMaterialExpression*> GetExpressions( UMaterial* Material );
FExpressionInput* GetMaterialAttributes( UMaterial* Material );
FScalarMaterialInput* GetOpacity( UMaterial* Material );
FScalarMaterialInput* GetOpacityMask( UMaterial* Material );
FColorMaterialInput* GetBaseColor( UMaterial* Material );
FColorMaterialInput* GetEmissiveColor( UMaterial* Material );
FExpressionInput* GetNormal( UMaterial* Material );
FExpressionInput* GetMetallic( UMaterial* Material );
FExpressionInput* GetRoughness( UMaterial* Material );
FExpressionInput* GetSpecular( UMaterial* Material );
FExpressionInput* GetAnisotropy( UMaterial* Material );
FExpressionInput* GetTangent( UMaterial* Material );
FExpressionInput* GetWorldPositionOffset( UMaterial* Material );
FExpressionInput* GetSubsurfaceColor( UMaterial* Material );
FExpressionInput* GetClearCoat( UMaterial* Material );
FExpressionInput* GetClearCoatRoughness( UMaterial* Material );
FExpressionInput* GetAmbientOcclusion( UMaterial* Material );
FExpressionInput* GetRefraction( UMaterial* Material );
FExpressionInput* GetPixelDepthOffset( UMaterial* Material );
FExpressionInput* GetShadingModelFromMaterialExpression( UMaterial* Material );
FExpressionInput* GetCustomizedUVs( UMaterial* Material, int i );
float ConvertSpotAngle( float OuterConeAngle );
UAnimSequence* GetAnimationSequence( USkeletalMeshComponent* SkeletalMeshComp );
void CopyToOutput( FString SourceFile, FString OutFilePath, bool Overwrite = true );