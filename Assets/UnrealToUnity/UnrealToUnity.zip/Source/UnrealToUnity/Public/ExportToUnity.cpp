

#include "ExportToUnity.h"

#include "UnityScene.h"
#ifdef ENABLE_GODOT_EXPORT
	#include "GodotScene.h"
#endif
#include "Module.h"

#include "Runtime/Core/Public/GenericPlatform/GenericPlatformFile.h"
#include "Runtime/Core/Public/HAL/PlatformFilemanager.h"
#include "EngineUtils.h"
#include "StaticMeshResources.h"
#include "ImageUtils.h"
#include "Runtime/Core/Public/Misc/FileHelper.h"
#include "Kismet/KismetStringLibrary.h"

#include "Runtime/Engine/Classes/Components/LightComponent.h"
#include "Runtime/Engine/Classes/Components/PointLightComponent.h"
#include "Runtime/Engine/Classes/Components/SpotLightComponent.h"
#include "Runtime/Engine/Classes/Components/RectLightComponent.h"
#include "Runtime/Engine/Classes/Components/DirectionalLightComponent.h"
#include "Camera/CameraComponent.h"
#include "Runtime/Engine/Classes/Components/SkeletalMeshComponent.h"
#include "Runtime/Engine/Classes/Components/SplineComponent.h"
#include "Runtime/Engine/Classes/Components/SplineMeshComponent.h"
#include "Runtime/Engine/Classes/Components/DecalComponent.h"
#include "Runtime/Engine/Classes/Components/SphereReflectionCaptureComponent.h"
#include "Runtime/Engine/Classes/Components/BoxReflectionCaptureComponent.h"
#include "Runtime/Engine/Classes/Engine/StaticMesh.h"
#include "Runtime/Engine/Classes/Materials/Material.h"
#include "Runtime/Engine/Private/Materials/MaterialUniformExpressions.h"
#include "Runtime/Engine/Classes/Materials/MaterialInstance.h"
#include "Runtime/Engine/Classes/Engine/TextureCube.h"
#include "Runtime/Engine/Classes/Exporters/Exporter.h"
#include "Editor/UnrealEd/Classes/Exporters/TextureCubeExporterHDR.h"
#include "Editor/UnrealEd/Classes/Exporters/TextureExporterHDR.h"
#include "Editor/UnrealEd/Classes/Exporters/SoundExporterOGG.h"
#include "Runtime/Engine/Public/AssetExportTask.h"
#include "UObject/GCObjectScopeGuard.h"
#include "ObjectTools.h"
#include "Runtime/Projects/Public/Interfaces/IPluginManager.h"

#include "Runtime/Engine/Classes/Materials/MaterialExpressionTextureSampleParameter2D.h"
#include "Runtime/Engine/Classes/Materials/MaterialExpressionMultiply.h"
#include "Runtime/Engine/Classes/Materials/MaterialExpressionStaticSwitchParameter.h"
#include "Runtime/Engine/Classes/Materials/MaterialExpressionConstant.h"
#include "Runtime/Engine/Classes/Materials/MaterialExpressionMaterialFunctionCall.h"
#include "Runtime/Engine/Classes/Materials/MaterialExpressionMakeMaterialAttributes.h"
#include "Runtime/Engine/Classes/Materials/MaterialExpressionCollectionParameter.h"
#include "Runtime/Engine/Classes/Materials/MaterialParameterCollection.h"
#include "Runtime/Engine/Classes/Materials/MaterialExpressionConstant4Vector.h"

#include "Framework/MultiBox/MultiBoxExtender.h"
#include "Misc/ScopedSlowTask.h"
#include "Misc/Paths.h"

#include "Runtime/Engine/Classes/Materials/MaterialInstanceDynamic.h"

#include "Runtime/Engine/Public/Rendering/SkeletalMeshRenderData.h"
#include "Engine/SkeletalMesh.h"
#include "Animation/AnimSequence.h"
#include "Misc/MessageDialog.h"
#include "Engine/Blueprint.h"

#include "Runtime/Engine/Classes/Engine/LODActor.h"
#include "Editor/UnrealEd/Classes/Editor/GroupActor.h"
#include "Engine/StaticMeshActor.h"
#include "Runtime/Engine/Classes/Engine/VolumeTexture.h"

#include "Async/Async.h"
#include "Sound/SoundWave.h"
#include "PhysicsEngine/BodySetup.h"
#include "Engine/RendererSettings.h"
#include "Animation/AnimSingleNodeInstance.h"

#define LOCTEXT_NAMESPACE "FUnrealToUnityModule"

#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION > 20) || ENGINE_MAJOR_VERSION == 5
	#include "Runtime/Engine/Classes/Engine/Texture2DArray.h"
#endif

#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 0
	#include "WorldPartition/HLOD/HLODActor.h"
#endif

#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 2
	#include "Runtime/Engine/Public/StaticMeshComponentLODInfo.h"

	#include "MaterialDomain.h"
	#include "Materials/MaterialRenderProxy.h"
	#include "Engine/SkinnedAssetCommon.h"
	#include "Animation/BuiltInAttributeTypes.h"
#endif

ERHIFeatureLevel::Type GlobalFeatureLevel = ERHIFeatureLevel::SM5;
EMaterialQualityLevel::Type GlobalQualityLevel = EMaterialQualityLevel::High;

FString GetMetaExtension()
{
	if( UTUSettings->Engine == EngineType::GODOT )
		return TEXT( ".import" );
	else
		return TEXT( ".meta" );
}
FString GetMeshExtension()
{
	if( UTUSettings->Engine == EngineType::GODOT )
		return TEXT( ".glb" );
	else
		return TEXT( ".fbx" );
}
FString GetMaterialExtension()
{
	if( UTUSettings->Engine == EngineType::GODOT )
		return TEXT( ".tres" );
	else
		return TEXT( ".mat" );
}
FString GetSceneExtension()
{
	if( UTUSettings->Engine == EngineType::GODOT )
		return TEXT( ".tscn" );
	else
		return TEXT( ".unity" );
}
FString GetShaderExtension()
{
	if( UTUSettings->Engine == EngineType::GODOT )
		return TEXT( ".tres" );
	else
		return TEXT( ".shader" );
}

TAutoConsoleVariable<int> CVarUseOriginalPaths(
	TEXT( "utu.UseOriginalPaths" ),
#if ENGINE_MINOR_VERSION >= 26 || ENGINE_MAJOR_VERSION >= 5
	1,
#else
	0,
#endif
	TEXT( "Use Original Unreal paths just in case there's 2 files with the same name, default is 1" ),
	ECVF_Cheat );
TAutoConsoleVariable<int> CVarUsePostImportTool(
	TEXT( "utu.UsePostImportTool" ),
	1,
	TEXT( "Uses the PostImportTool to fix UV sets and submeshes" ),
	ECVF_Cheat );
TAutoConsoleVariable<int> CVarRenderPipeline(
	TEXT( "utu.RenderPipeline" ),
	0,
	TEXT( "Selects Render pipeline shaders to be generated" ),
	ECVF_Cheat );
TAutoConsoleVariable<int> CVarAssetsWithYUp(
	TEXT( "utu.AssetsWithYUp" ),
	1,
	TEXT( "By Default assets have Z up (Unreal Default). If 1 assets will have Y up but the scene won't look right." ),
	ECVF_Cheat );
TAutoConsoleVariable<int> CVarExportTangents(
	TEXT( "utu.ExportTangents" ),
	1,
	TEXT( "By Tangents are exported. Disable if you have meshes with black parts in unity" ),
	ECVF_Cheat );
bool ReusePrefabs = false;
TAutoConsoleVariable<int> CVarFBXPerActor(
	TEXT( "utu.FBXPerActor" ),
	1,
	TEXT( "Do FBXs per actor instead of OBJs" ),
	ECVF_Cheat );

#if WITH_EDITOR


//#include "MaterialShared.generated.h"
#include "Editor/MaterialEditor/Public/MaterialEditorUtilities.h"

#include "UnrealEdGlobals.h"//for GUnrealEd
#include "Editor/UnrealEdEngine.h"

void ConvertTransform( FTransform Trans, TransformComponent* Transform, bool IsRelative = false, bool HasDecals = false );
void ConvertTransformForBones( FTransform Trans, TransformComponent* Transform, bool IsRoot );

#if PLATFORM_WINDOWS

//maybe TCHAR_TO_UTF8 ?

std::wstring ToWideString( std::string str )
{
	std::wstring w;
	for( int i = 0; i < str.length(); i++ )
	{
		w += str[ i ];
	}
	return w;
}
//Should be upgraded to TCHAR_TO_ANSI I guess
std::string ToANSIString( std::wstring w )
{
	std::string s;
	for( int i = 0; i < w.length(); i++ )
	{
		s += w[ i ];
	}
	return s;
}
#else
std::u16string ToWideString( std::string str )
{
	std::u16string w;
	for( int i = 0; i < str.length(); i++ )
	{
		w += str[ i ];
	}
	return w;
}
std::string ToANSIString( std::u16string w )
{
	std::string s;
	for( int i = 0; i < w.length(); i++ )
	{
		s += w[ i ];
	}
	return s;
}

//#define _snscanf_s scanf
#define _ftelli64 ftell
#endif


int TotalMeshes = 0;
int TotalTriangles = 0;

bool ExportMeshes = true;// false;
bool ExportTextures = true;
bool DoAsyncTextureExport = true;
bool ForceShaderRecompilation = false;

FString GGlobalExportFolder;

FString GetAssetsFolder()
{
	EnsureSettingsExists();

	FString Folder = GGlobalExportFolder;
	if ( UTUSettings->Engine == EngineType::UNITY )
		Folder += TEXT("Assets/" );

	return Folder;
}
std::string FixUnicodeCharacters( std::string & In )
{
	for( int i = 0; i < In.length(); i++ )
	{
		if( In[ i ] == '?' )
		{
			In[ i ] = '_';
		}
	}
	return In;
}
FString FixUnicodeCharacters( FString& In )
{
	for( int i = 0; i < In.Len(); i++ )
	{
		if( In[ i ] == '?' || In[ i ] > 255 )
		{
			In[ i ] = '_';
		}
	}
	return In;
}
int CreateAllDirectories( FString FileName )
{
	int created = 0;
	//detects directories, hierarchly and creates them	
	int len = FileName.Len();
	for( int y = 0; y < len; y++ )
	{
		if( FileName[ y ] == '\\' || FileName[ y ] == '/' )
		{
			FString DirName = UKismetStringLibrary::GetSubstring( FileName, 0, y );

			created += VerifyOrCreateDirectory( DirName );
		}
	}

	return created;
}

UnityScene* GUnityScene = nullptr;

std::vector< TextureBinding* > AllTextures;

FString GetAssetPathFolder( const UObject* Obj )
{
	FString Path;
	if( CVarUseOriginalPaths.GetValueOnAnyThread() == 1 )
	{
	#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 26) || ENGINE_MAJOR_VERSION == 5
		FString AssetPath = Obj->GetPackage()->GetPathName();
		AssetPath = AssetPath.Replace( TEXT( "/Game/" ), TEXT( "" ) );
		//AssetPath = AssetPath.Replace( TEXT( "/" ), TEXT( "\\" ) );
		AssetPath.RemoveFromEnd( Obj->GetName() );
		Path += *AssetPath;
	#endif
	}
	return Path;
}
FString GenerateTexturePath( UTexture *Tex, bool IsResourcePath = false )
{
	UTextureCube* CubeTex = Cast<UTextureCube>( Tex );
	FString TextureFileName;
	if (!IsResourcePath )
		TextureFileName = GetAssetsFolder();
	ETextureSourceFormat Format = Tex->Source.GetFormat();

	if( CVarUseOriginalPaths.GetValueOnAnyThread() == 1 )
	{
		TextureFileName += GetAssetPathFolder( Tex );
		CreateAllDirectories( TextureFileName );
	}
	else
	{
		TextureFileName += TEXT("Textures/" );
	}

	TextureFileName += *Tex->GetName();
	if ( CubeTex || Format == TSF_RGBA16F )
		TextureFileName += TEXT(".hdr" );
	else
		TextureFileName += TEXT(".png" );

	return TextureFileName;
}
FString GenerateAssetPath( UObject* Asset, FString Extension )
{
	FString FileName = GetAssetsFolder();

	FileName += GetAssetPathFolder( Asset );
	FileName += *Asset->GetName();
	FileName += Extension;

	return FileName;
}

bool UseUEExporter( UExporter* ExporterToUse, UObject* ObjectToExport, FString Filename, bool ShowOptions )
{
	bool Status = false;
	
	ExporterToUse->SetBatchMode( false );
	ExporterToUse->SetCancelBatch( false );
	ExporterToUse->SetShowExportOption( ShowOptions );
	ExporterToUse->AddToRoot();
		

	UAssetExportTask* ExportTask = NewObject<UAssetExportTask>();
	FGCObjectScopeGuard ExportTaskGuard( ExportTask );
	ExportTask->Object = ObjectToExport;
	ExportTask->Exporter = ExporterToUse;
	ExportTask->Filename = Filename;
	ExportTask->bSelected = false;
	ExportTask->bReplaceIdentical = true;
	ExportTask->bPrompt = false;
	ExportTask->bUseFileArchive = ObjectToExport->IsA( UPackage::StaticClass() );
	ExportTask->bWriteEmptyFiles = false;

	Status = UExporter::RunAssetExportTask( ExportTask );

	ExporterToUse->SetBatchMode( false );
	ExporterToUse->SetCancelBatch( false );
	ExporterToUse->SetShowExportOption( true );
	ExporterToUse->RemoveFromRoot();

	return Status;
}
UExporter* GetExporterForAsset( UObject* Asset, FString* RequiredName )
{
	TArray<UExporter*> Exporters;
	ObjectTools::AssembleListOfExporters( Exporters );
	for( int i = 0; i < Exporters.Num(); i++ )
	{
		UExporter* Exporter = Exporters[ i ];
		bool HasRequiredName = true;
		if( RequiredName )
		{
			HasRequiredName = Exporter->GetName().Contains( *RequiredName );
		}
		if( Exporter && Exporter->SupportedClass == Asset->GetClass() && HasRequiredName )
		{
			return Exporter;
		}
	}

	return nullptr;
}
void ExportSounds()
{
	TArray<USoundWave*> SoundArray;
	TArray<FString> Messages;
	auto lambdaTextures = [&]( FAssetData& Asset )
	{
		bool Modified = false;
		USoundWave* Sound = Cast<USoundWave>( Asset.GetAsset() );
		if( Sound )
		{
			Sound->AddToRoot();
			SoundArray.Add( Sound );
		}

		return Modified;
	};

	IterateOverAllAssetsOfType( FName( "SoundWave" ), lambdaTextures );

	FScopedSlowTask ProgressDialog( SoundArray.Num() );
	ProgressDialog.MakeDialog();

	for(int i=0; i< SoundArray.Num(); i++ )
	{
		USoundWave* Sound = SoundArray[i];
		UExporter* Exporter = GetExporterForAsset( Sound );
		FString Extension = TEXT( ".wav" );
		if( Exporter->GetClass()->GetName().Contains( "OGG" ) )
			Extension = TEXT( ".ogg" );
		FString Filename = GenerateAssetPath( Sound, Extension);
		if( !FPlatformFileManager::Get().GetPlatformFile().FileExists( *Filename ) )
		{
			CreateAllDirectories( Filename );
			UseUEExporter( Exporter, Sound, Filename );
		}
		Sound->RemoveFromRoot();

		ProgressDialog.EnterProgressFrame( 1, LOCTEXT( "ExportingSounds", "Exporting Sounds" ) );
	}
}

bool ExportCubeMap( UTextureCube* Cubemap, FString Filename )
{
	TArray<UExporter*> Exporters;
	ObjectTools::AssembleListOfExporters( Exporters );
	for( int i = 0; i < Exporters.Num(); i++ )
	{
		UTextureCubeExporterHDR* CubeExporter = Cast<UTextureCubeExporterHDR>( Exporters[i] );
		if( CubeExporter )
		{
			if( DoAsyncTextureExport )
			{
				AsyncTask( ENamedThreads::GameThread, [=]()
				{
					UseUEExporter( CubeExporter, Cubemap, Filename );
				} );
				return true;
			}
			else
				return UseUEExporter( CubeExporter, Cubemap, Filename );
		}
	}

	return false;
}
void ExportTextureHDR( UTexture2D* Tex, FString Filename )
{
	TArray<UExporter*> Exporters;
	ObjectTools::AssembleListOfExporters( Exporters );
	for( int i = 0; i < Exporters.Num(); i++ )
	{
		if ( Exporters[ i ]->GetName().Contains(TEXT("TextureExporterHDR")))
		{
			if( DoAsyncTextureExport )
			{
				AsyncTask( ENamedThreads::GameThread, [=]()
				{
					UseUEExporter( Exporters[ i ], Tex, Filename );
				} );
			}
			else
			{
				UseUEExporter( Exporters[ i ], Tex, Filename );
			}
			return;
		}
	}
}

void UETextureExporter::ConvertToColors( TArray64<uint8>& SourceData, ETextureSourceFormat Format, int32 Width, int32 Height, int32 Depth, TArray<FColor>& InputImageData, FString TextureFileName )
{
	if( SourceData.Num() == 0 )
	{
		FString DialogText = FString::Printf( TEXT(
			"Error for %s !\n"
			"\n"
			"ConvertToColors -> SourceData.Num() == 0\n" ), *TextureFileName );
		FText Txt = FText::FromString( DialogText );
		FMessageDialog::Open( EAppMsgType::Ok, Txt );
		return;
	}

	if( Format == TSF_G8 )
	{
		for( int i = 0; i < SourceData.Num(); i++ )
		{
			FColor Color( SourceData[ i ], SourceData[ i ], SourceData[ i ], SourceData[ i ] );
			InputImageData.Add( Color );
		}
	}
	#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION > 20) || ENGINE_MAJOR_VERSION == 5
	else if( Format == TSF_G16 )
	{
		const uint16* Pixels = (const uint16*)SourceData.GetData();
		int NumPixels = Width * Height;
		for( int i = 0; i < NumPixels; i++ )
		{
			const float Val = float( Pixels[ i ] ) / 65535.0f;
			//uint16 R16 = OutMipData[ i + 1 ] * 256 + OutMipData[ i + 0 ];
			//uint8 Val = (uint8)( float( R16 ) / 256.0f );
			FLinearColor Color( Val, Val, Val, 1.0 );
			FColor Color2 = Color.ToFColor( false );
			//FColor Color( Val, Val, Val, Val );
			InputImageData.Add( Color2 );
		}
	}//These textures must not be compressed inside unity because we can get artifacts
	#endif
	else if( Format == TSF_RGBA16F )
	{
		//Maybe Bring back this function ?
		//ExportTextureHDR( Tex2D, TextureFileName );

		FFloat16Color* Pixels = (FFloat16Color*)SourceData.GetData();
		int NumPixels = Width * Height;
		for( int i = 0; i < NumPixels; i++ )
		{
			FLinearColor Color( Pixels[ i ] );
			FColor C = Color.ToFColor( true );
			InputImageData.Add( C );
		}
	}
	else if( Format == TSF_RGBA16 )
	{
		for( int i = 0; i < SourceData.Num(); i += 8 )
		{
			FColor Color;
			uint16 R16 = SourceData[ i + 0 ] * 256 + SourceData[ i + 1 ];
			uint16 G16 = SourceData[ i + 2 ] * 256 + SourceData[ i + 3 ];
			uint16 B16 = SourceData[ i + 4 ] * 256 + SourceData[ i + 5 ];
			uint16 A16 = SourceData[ i + 6 ] * 256 + SourceData[ i + 7 ];
			//Color.R = R16 / 256;
			//Color.G = G16 / 256;
			//Color.B = B16 / 256;
			//Color.A = A16 / 256;
			Color.B = SourceData[ i + 5 ];
			Color.G = SourceData[ i + 3 ];
			Color.R = SourceData[ i + 1 ];
			Color.A = SourceData[ i + 7 ];
			InputImageData.Add( Color );
		}
	}
	else
	{
		auto AddPixel = [&]( int x, int y, int z )
		{
			int i = ( z * Width * Height + y * Width + x ) * 4;
			if( i + 3 < SourceData.Num() )
			{
				FColor Color( SourceData[ i + 2 ], SourceData[ i + 1 ], SourceData[ i + 0 ], SourceData[ i + 3 ] );
				InputImageData.Add( Color );
			}
		};
		bool UpsideDown = false;// true;
		if( UpsideDown )
		{
			for( int y = Height - 1; y >= 0; y-- )
			{
				for( int x = 0; x < Width; x++ )
				{
					AddPixel( x, y, 0 );
				}
			}
		}
		else
		{
			for( int z = 0; z < Depth; z++ )
			{
				for( int y = 0; y < Height; y++ )
				{
					for( int x = 0; x < Width; x++ )
					{
						AddPixel( x, y, z );
					}
				}
			}
		}
	}
}
bool UETextureExporter::CompressAndSaveTexture( FString TextureFileName, TArray<FColor>& InputImageData, int Width, int Height )
{
	#if ENGINE_MAJOR_VERSION == 4
		TArray<uint8> PNG_Compressed_ImageData;
	#else
		TArray64<uint8> PNG_Compressed_ImageData;
	#endif
	//~~~~~~~~~~~~~~~~
	// Compress to PNG
	//~~~~~~~~~~~~~~~~
	if( InputImageData.Num() == 0 )
	{
		FString DialogText = FString::Printf( TEXT(
			"Error!\n\n"
			"Could not save texture %s !\n"
			"\n"
			"InputImageData.Num() == 0 Tex->Source.GetMipData probably failed ?\n"), *TextureFileName );
		FText Txt = FText::FromString( DialogText );
		FMessageDialog::Open( EAppMsgType::Ok, Txt );
		return false;
	}

	#if ENGINE_MAJOR_VERSION == 4
		FImageUtils::CompressImageArray(
			Width,
			Height,
			InputImageData,
			PNG_Compressed_ImageData
		);
	#else
		FImageUtils::PNGCompressImageArray(
			Width,
			Height,
			InputImageData,
			PNG_Compressed_ImageData
		);
	#endif

	bool Status = FFileHelper::SaveArrayToFile(
		PNG_Compressed_ImageData,
		*TextureFileName
		);

	if( !Status )
	{
		FString DialogText = FString::Printf( TEXT(
			"Error!\n\n"
			"Could not save texture %s !\n"
			"\n"
			"Do you have enough free space on that drive ?\n"
			"Do you have permission to save files there ?\n" ), *TextureFileName );
		if( TextureFileName.Len() > 255 )
		{
			DialogText += TEXT( "FileName.Len() > 255 !!" );
		}
		FText Txt = FText::FromString( DialogText );
		FMessageDialog::Open( EAppMsgType::Ok, Txt );
	}
	return Status;
}
bool UETextureExporter::DoExport( UTexture *Tex )
{
	UTextureCube* CubeTex = Cast<UTextureCube>( Tex );
	UVolumeTexture* VolTex = Cast< UVolumeTexture>( Tex );
	#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION > 20) || ENGINE_MAJOR_VERSION == 5
		UTexture2DArray* Tex2DArray = Cast< UTexture2DArray>( Tex );
	#endif
	FString TextureFileName = GenerateTexturePath( Tex );
		
	if( !ExportTextures )
		return false;
	
	FString FileNameOnDisk = FPlatformFileManager::Get().GetPlatformFile().GetFilenameOnDisk( *TextureFileName );
	//Don't save duplicates !
	if ( !FPlatformFileManager::Get().GetPlatformFile().FileExists( *TextureFileName ) )
	{
		if( CubeTex )
		{
			return ExportCubeMap( CubeTex, TextureFileName );
		}
		if( VolTex )
		{
			#if ENGINE_MAJOR_VERSION == 4
				Tex = VolTex->Source2DTexture;
			#else
				Tex = VolTex->Source2DTexture.Get();
			#endif
		}
		#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION > 20) || ENGINE_MAJOR_VERSION == 5
		if( Tex2DArray )
		{
			TArray<FColor> FinalImageColors;
			//TArray<TArray<FColor>*> SliceImageDataArray;
			for( int i = 0; i < Tex2DArray->SourceTextures.Num(); i++ )
			{
				UTexture2D* SourceTex = Tex2DArray->SourceTextures[ i ];
				if( !SourceTex )
					continue;
				int32 Width = SourceTex->Source.GetSizeX();
				int32 Height = SourceTex->Source.GetSizeY();
				int32 Depth = SourceTex->Source.GetNumSlices();
				ETextureSourceFormat Format = SourceTex->Source.GetFormat();

				TArray64<uint8> SliceData;
				SourceTex->Source.GetMipData( SliceData, 0 );

				//TArray<FColor>* SliceColors = new TArray<FColor>;
				TArray<FColor> SliceColors;
				ConvertToColors( SliceData, Format, Width, Height, Depth, SliceColors, TextureFileName );
					
				for( int c = 0; c < SliceColors.Num(); c++ )
				{
					FinalImageColors.Add( SliceColors[ c ] );
				}
			}

			int32 Width = Tex->Source.GetSizeX();
			int32 Height = Tex->Source.GetSizeY() * Tex2DArray->SourceTextures.Num();
			return CompressAndSaveTexture( TextureFileName, FinalImageColors, Width, Height );
		}
		#endif
			
		ETextureSourceFormat Format = Tex->Source.GetFormat();

		#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 5
			#define TSF_RGBA8 TSF_RGBA8_DEPRECATED
		#endif

		if ( Format != TSF_BGRA8 && Format != TSF_RGBA8 && Format != TSF_RGBA16 && Format != TSF_G8 &&
				Format != TSF_BGRE8 &&
				Format != TSF_RGBA16F
				#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION > 20) || ENGINE_MAJOR_VERSION == 5
					&& Format != TSF_G16 
				#endif
			 )
		{
			//UE_LOG( LogClass, Log, TEXT("UETextureExporter::DoExport Format %d is not standard!"), Format );
			FString DialogText = FString::Printf( TEXT( "UETextureExporter::DoExport Format %d is not supported!" ), Format );
			FText Txt = FText::FromString( DialogText );
			FMessageDialog::Open( EAppMsgType::Ok, Txt );

			return false;
		}

		int32 Width = Tex->Source.GetSizeX();
		int32 Height = Tex->Source.GetSizeY();
		int32 Depth = Tex->Source.GetNumSlices();

		TArray64<uint8> OutMipData;
		Tex->Source.GetMipData( OutMipData, 0 );

		TArray<FColor> InputImageData;

		ConvertToColors( OutMipData, Format, Width, Height, Depth, InputImageData, TextureFileName );

		if( Tex->bFlipGreenChannel)
		{
			for( int i = 0; i < InputImageData.Num(); i++ )
			{
				FColor& Color = InputImageData[ i ];
				Color.G = 255 - Color.G;
			}
		}

		return CompressAndSaveTexture( TextureFileName, InputImageData, Width, Height );
	}
	else//File exists, so already exported ?
		return true;
	//~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	//~~~ Empty PNG Buffer ~~~
	//PNG_Compressed_ImageData.Empty();
	//~~~~~~~~~~~~~~~~~~~~~~~~

	//~~~ Empty Color Buffer ~~~
	//PNGScreenShot_ColorBuffer.Empty();
	//~~~~~~~~~~~~~~~~~~~~~~~~
}
TextureBinding* UETextureExporter::Find( UTexture *Tex )
{
	for( int i = 0; i < AllTextures.size(); i++ )
	{
		auto Binding = AllTextures[ i ];
		if( Binding->UnrealTexture == Tex )
			return Binding;
	}

	return nullptr;
}
TextureBinding* UETextureExporter::Export( UTexture *T )
{
	auto Existent = Find( T );
	if( Existent )
		return Existent;

	if( !DoAsyncTextureExport)
		DoExport( T );

	TextureBinding *NewTextureBinding = new TextureBinding;
	NewTextureBinding->UnrealTexture = T;
	AllTextures.push_back( NewTextureBinding );

	return NewTextureBinding;
}

class FExportTextureTask
{

public:
	FExportTextureTask( UTexture* Texture )
	{
		TargetTexture = Texture;
	}
	static const TCHAR* GetTaskName()
	{
		return TEXT( "FExportTextureTask" );
	}
	FORCEINLINE TStatId GetStatId() const
	{
		RETURN_QUICK_DECLARE_CYCLE_STAT( FExportTextureTask, STATGROUP_TaskGraphTasks );
	}

	ENamedThreads::Type GetDesiredThread()
	{
		return ENamedThreads::AnyNormalThreadNormalTask;
	}

	static ESubsequentsMode::Type GetSubsequentsMode()
	{
		return ESubsequentsMode::TrackSubsequents;
	}
	void DoTask( ENamedThreads::Type CurrentThread, const FGraphEventRef& MyCompletionGraphEvent )
	{
		bool Status = UETextureExporter::DoExport( TargetTexture );
	}

	UTexture* TargetTexture = nullptr;
};

std::vector< MaterialBinding *> AllMaterials;

MaterialBinding *GetMaterialIfAlreadyExported( UMaterialInterface *M )
{
	for ( int i = 0; i < AllMaterials.size(); i++ )
	{
		if ( AllMaterials[ i ]->MaterialInterface == M )
			return AllMaterials[ i ];
	}

	return nullptr;
}
MaterialBinding *ProcessMaterialReference( UMaterialInterface *M )
{
	MaterialBinding *Mat = GetMaterialIfAlreadyExported( M );

	if ( !Mat )
	{
		Mat = new MaterialBinding();
		Mat->MaterialInterface = M;
		Mat->ID = AllMaterials.size();
		//Prevent crashes when exporting multiple scenes
		if( ReusePrefabs )
		{
			UMaterialInstanceDynamic* MID = Cast<UMaterialInstanceDynamic>( M );
			if( MID )
			{
				FName UniqueName = MakeUniqueObjectName( GetTransientPackage(), MID->GetClass(), *MID->GetName() );
				MID->Rename( *UniqueName.ToString(), GetTransientPackage() );
			}
			M->AddToRoot();
		}
		AllMaterials.push_back( Mat );
	}
	
	return Mat;
}
FString GetProjectName()
{
	FString ProjectFilePath = FPaths::GetProjectFilePath();
	int PointStart = ProjectFilePath.Find( TEXT( "." ), ESearchCase::IgnoreCase, ESearchDir::FromEnd );
	int NameStart = ProjectFilePath.Find( TEXT( "/" ), ESearchCase::IgnoreCase, ESearchDir::FromEnd );
	FString ProjectName = ProjectFilePath.Mid( NameStart + 1, PointStart - NameStart - 1 );
	return ProjectName;
}
FString GetResourceDir()
{
	TSharedPtr<IPlugin> ThisPlugin = IPluginManager::Get().FindPlugin( TEXT( "UnrealToUnity" ) );
	
	FString ResourceDir = ThisPlugin->GetBaseDir() / TEXT( "Resources/" );

	//ProjectDir.Append( TEXT( "/Plugins/UnrealToUnity/Resources/" ) );

	return ResourceDir;
}
void CopyToOutput( FString SourceFile, FString OutFilePath, bool Overwrite )
{
	FString ResourceDir = GetResourceDir();
	FString SourceFilePath = ResourceDir;
	SourceFilePath += SourceFile;
	FString To = GGlobalExportFolder;
	To += OutFilePath;

	if( !Overwrite )
	{
		if( FPlatformFileManager::Get().GetPlatformFile().FileExists( *To ) )
			return;
	}

	bool Result = FPlatformFileManager::Get().GetPlatformFile().CopyFile( *To, *SourceFilePath );
	if( !Result )
	{
		if( !FPlatformFileManager::Get().GetPlatformFile().FileExists( *SourceFilePath ) )
		{
			FString Text = FString::Printf( TEXT( "SourceFile %s not found. Check your plugin installation !" ), *SourceFilePath );
			FText Txt = FText::FromString( Text );
			FMessageDialog::Open( EAppMsgType::Ok, Txt );
		}
		else
		{
			FString Text = FString::Printf( TEXT( "CopyToOutput Error on SourceFile=%s OutFilePath=%s" ), *SourceFilePath, *To );
			FText Txt = FText::FromString( Text );
			FMessageDialog::Open( EAppMsgType::Ok, Txt );
		}
	}
}
bool DoesOutputFileExists( FString OutFilePath )
{
	FString Target = GGlobalExportFolder;
	Target += OutFilePath;
	bool Exists = FPlatformFileManager::Get().GetPlatformFile().FileExists( *Target );
	return Exists;
}
bool WarnAboutRenderPipelineMismatch( RenderPipeline CurrentRenderPipeline)
{
	if( DoesOutputFileExists( TEXT( "/Assets/Settings/ForwardRenderer.asset" ) ) )
	{
		if( CurrentRenderPipeline != RenderPipeline::RP_URP )
		{
			FString Text = FString::Printf( TEXT( "Output folder contains files for a URP project ! Aborting export" ) );
			FText Txt = FText::FromString( Text );
			FMessageDialog::Open( EAppMsgType::Ok, Txt );
			return true;
		}
	}
	else if( DoesOutputFileExists( TEXT( "/Assets/HDRPDefaultResources/DefaultHDRPAsset.asset" ) ) )
	{
		if( CurrentRenderPipeline != RenderPipeline::RP_HDRP )
		{
			FString Text = FString::Printf( TEXT( "Output folder contains files for a HDRP project ! Aborting export" ) );
			FText Txt = FText::FromString( Text );
			FMessageDialog::Open( EAppMsgType::Ok, Txt );
			return true;
		}
	}
	else if( DoesOutputFileExists( TEXT( "ProjectSettings/ProjectSettings.asset" ) ) )
	{
		if( CurrentRenderPipeline != RenderPipeline::RP_BUILTIN )
		{
			FString Text = FString::Printf( TEXT( "Output folder contains files for a BuiltIn project ! Aborting export" ) );
			FText Txt = FText::FromString( Text );
			FMessageDialog::Open( EAppMsgType::Ok, Txt );
			return true;
		}
	}

	return false;
}
void ProcessMaterial_RenderThread( MaterialBinding *Mat, const char *ProxyShaderString, const char* GraphShaderString );
void ProcessAllMaterials( )
{
	FString ResourceDir = GetResourceDir();
	FString ProxyShader = ResourceDir;
	FString GraphShader = ResourceDir;
	if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_URP  ||
		CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
	{
		ProxyShader += TEXT("/ProxyURP_HDRP.hlsl" );
	}
	else
		ProxyShader += TEXT("/Proxy.shader" );

	if( UTUSettings->Engine == EngineType::UNITY )
	{
		if( UTUSettings->Shaders == ShadersType::ST_CUSTOM_SHADERS )
		{
			CopyToOutput( TEXT( "UnrealCommon.cginc" ), TEXT( "Assets/Shaders/UnrealCommon.cginc" ), false );
		#if ENGINE_MAJOR_VERSION >= 5
			CopyToOutput( TEXT( "LargeWorldCoordinates.hlsl" ), TEXT( "Assets/Shaders/LargeWorldCoordinates.hlsl" ), false );
			CopyToOutput( TEXT( "LWCOperations.hlsl" ), TEXT( "Assets/Shaders/LWCOperations.hlsl" ), false );
		#endif
		}
	}
	
	const char *ProxyShaderString = nullptr;
	int Size = LoadFile( ToANSIString( *ProxyShader ).c_str(), (uint8**)&ProxyShaderString );
	if ( Size < 0 )
	{
		FString Text = FString::Printf( TEXT( "ProxyShader %s not found. Check your plugin installation !" ), *ProxyShader );
		FText Txt = FText::FromString( Text );
		FMessageDialog::Open( EAppMsgType::Ok, Txt );	
		return;
	}
	FString DecalGraphShader;
	const char* GraphShaderData = nullptr;
	const char* DecalGraphShaderData = nullptr;
	if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_URP )
	{
		DecalGraphShader = GraphShader;
		GraphShader += TEXT("URP/URPGraphShader.shader" );
		Size = LoadFile( ToANSIString( *GraphShader ).c_str(), (uint8**)&GraphShaderData );
		
		DecalGraphShader += TEXT("URP/URPDecalGraphShader.shader" );
		Size = LoadFile( ToANSIString( *DecalGraphShader ).c_str(), (uint8**)&DecalGraphShaderData );
	}
	else if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
	{
		DecalGraphShader = GraphShader;
		GraphShader += TEXT("HDRP/HDRPGraphShader.shader");
		Size = LoadFile( ToANSIString( *GraphShader ).c_str(), (uint8**)&GraphShaderData );

		DecalGraphShader += TEXT("HDRP/HDRPDecalGraphShader.shader");
		Size = LoadFile( ToANSIString( *DecalGraphShader ).c_str(), (uint8**)&DecalGraphShaderData );
	}
	
	for ( int i = 0; i < AllMaterials.size(); i++ )
	{
		auto Mat = AllMaterials[ i ];
		const char* SelectedGraphShaderData = GraphShaderData;
		if( Mat->BaseMaterial->MaterialDomain == MD_DeferredDecal )
		{
			Mat->UnityMat->IsDecalMaterial = true;
			SelectedGraphShaderData = DecalGraphShaderData;
		}
		ProcessMaterial_RenderThread( Mat, ProxyShaderString, SelectedGraphShaderData );
	}

	if ( GraphShaderData )
		delete[]GraphShaderData;
	if ( DecalGraphShaderData )
		delete[]DecalGraphShaderData;
}
FString GetOutputFile( FString SubFolder, FString Name, FString Ext )
{
	FString OutFolder = GetAssetsFolder();
	OutFolder += *SubFolder;
	OutFolder += *Name;
	OutFolder += Ext;

	return OutFolder;
}
class FUniformExpressionSet_Override : public FUniformExpressionSet
{
public:
	
	#if ENGINE_MAJOR_VERSION >= 5
	TMemoryImageArray<FMaterialNumericParameterInfo>& GetUniformNumericParameters()
	{
		return this->UniformNumericParameters;
	}
	TMemoryImageArray<FMaterialUniformPreshaderHeader>& GetUniformPreshaders()
	{
		return this->UniformPreshaders;
	}
	#if ENGINE_MINOR_VERSION >= 1
	TMemoryImageArray<FMaterialUniformPreshaderField>& GetUniformPreshaderFields()
	{
		return this->UniformPreshaderFields;
	}
	#endif
	UE::Shader::FPreshaderData& GetUniformPreshaderData()
	{
		return UniformPreshaderData;
	}
	#elif ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 26
	TMemoryImageArray<FMaterialScalarParameterInfo>& GetUniformScalarParameters()
	{		
		return this->UniformScalarParameters;
	}
	TMemoryImageArray<FMaterialVectorParameterInfo>& GetUniformVectorParameters()
	{		
		return this->UniformVectorParameters;
	}
	TMemoryImageArray<FMaterialUniformPreshaderHeader>& GetVectorPreshaders()
	{
		return this->UniformVectorPreshaders;
	}
	TMemoryImageArray<FMaterialUniformPreshaderHeader>& GetScalarPreshaders()
	{
		return this->UniformScalarPreshaders;
	}
	FMaterialPreshaderData& GetUniformPreshaderData()
	{
		return UniformPreshaderData;
	}
	#elif ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 20
	TArray<TRefCountPtr<FMaterialUniformExpression>>& GetUniformVectorExpressions()
	{
		return UniformVectorExpressions;
	}
	TArray<TRefCountPtr<FMaterialUniformExpression>>& GetUniformScalarExpressions()
	{
		return UniformScalarExpressions;
	}
	TArray<TRefCountPtr<FMaterialUniformExpressionTexture>>& GetUniform2DTextureExpressions()
	{
		return Uniform2DTextureExpressions;
	}
	TArray<TRefCountPtr<FMaterialUniformExpressionTexture>>& GetUniformCubeTextureExpressions()
	{
		return UniformCubeTextureExpressions;
	}
	TArray<TRefCountPtr<FMaterialUniformExpressionTexture>>& GetUniformVolumeTextureExpressions()
	{
		return UniformVolumeTextureExpressions;
	}
	#endif
};

class ShaderProperty
{
public:
	std::string Name;
	int ScalarIndex = -1;
	int VectorIndex = -1;
	//int BufferOffset= -1;
};
#if ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 26
using FPreshaderStack = TArray<FLinearColor, TInlineAllocator<64u>>;
void EvaluatePreshader2( const FUniformExpressionSet* UniformExpressionSet, const FMaterialRenderContext& Context, FPreshaderStack& Stack, FPreshaderDataContext& RESTRICT Data, FLinearColor& OutValue,
						 uint16& LastVectorIndex, uint16& LastScalarIndex, int& NumOpCodes );
void GetPropertyNames( FUniformExpressionSet_Override* Set_Override, FMaterialRenderContext MaterialRenderContext, std::vector< ShaderProperty>& Properties, uint8* TempBuffer, int TempBufferSize )
{
	void* BufferCursor = TempBuffer;
	TMemoryImageArray<FMaterialUniformPreshaderHeader>& VectorPreshaders = Set_Override->GetVectorPreshaders();
	TMemoryImageArray<FMaterialUniformPreshaderHeader>& ScalarPreshaders = Set_Override->GetScalarPreshaders();
	TMemoryImageArray<FMaterialScalarParameterInfo>& UniformScalarParameters = Set_Override->GetUniformScalarParameters();
	TMemoryImageArray<FMaterialVectorParameterInfo>& UniformVectorParameters = Set_Override->GetUniformVectorParameters();

	FPreshaderStack PreshaderStack;
	FPreshaderDataContext PreshaderBaseContext( Set_Override->GetUniformPreshaderData() );
	for( int32 VectorIndex = 0; VectorIndex < VectorPreshaders.Num(); ++VectorIndex )
	{
		FLinearColor VectorValue( 0, 0, 0, 0 );

		const FMaterialUniformPreshaderHeader& Preshader = VectorPreshaders[ VectorIndex ];
		FPreshaderDataContext PreshaderContext( PreshaderBaseContext, Preshader );
		uint16 LastVectorIndex;
		uint16 LastScalarIndex;
		int NumOpCodes;
		EvaluatePreshader2( Set_Override, MaterialRenderContext, PreshaderStack, PreshaderContext, VectorValue, LastVectorIndex, LastScalarIndex, NumOpCodes );
		if( NumOpCodes == 1 && LastVectorIndex != (uint16)-1 )
		{
			ShaderProperty NewShaderProperty;
			const FMaterialVectorParameterInfo& Parameter = Set_Override->GetVectorParameter( LastVectorIndex );
			FString UStr = Parameter.ParameterInfo.Name.ToString();
			NewShaderProperty.Name = ToANSIString( *UStr );
			NewShaderProperty.VectorIndex = VectorIndex;// LastVectorIndex;
			//NewShaderProperty.BufferOffset = VectorIndex;
			Properties.push_back( NewShaderProperty );
		}

		FLinearColor* DestAddress = (FLinearColor*)BufferCursor;
		*DestAddress = VectorValue;
		BufferCursor = DestAddress + 1;
		check( BufferCursor <= TempBuffer + TempBufferSize );
	}

	// Dump scalar expression into the buffer.
	for( int32 ScalarIndex = 0; ScalarIndex < ScalarPreshaders.Num(); ++ScalarIndex )
	{
		FLinearColor VectorValue( 0, 0, 0, 0 );

		const FMaterialUniformPreshaderHeader& Preshader = ScalarPreshaders[ ScalarIndex ];
		FPreshaderDataContext PreshaderContext( PreshaderBaseContext, Preshader );
		uint16 LastVectorIndex;
		uint16 LastScalarIndex;
		int NumOpCodes;
		EvaluatePreshader2( Set_Override, MaterialRenderContext, PreshaderStack, PreshaderContext, VectorValue, LastVectorIndex, LastScalarIndex, NumOpCodes );
		if( NumOpCodes == 1 && LastScalarIndex != (uint16)-1 )
		{
			ShaderProperty NewShaderProperty;
			const FMaterialScalarParameterInfo& Parameter = Set_Override->GetScalarParameter( LastScalarIndex );
			FString UStr = Parameter.ParameterInfo.Name.ToString();
			NewShaderProperty.Name = ToANSIString( *UStr );
			NewShaderProperty.ScalarIndex = ScalarIndex;// LastScalarIndex;
			//NewShaderProperty.BufferOffset = ScalarIndex;
			Properties.push_back( NewShaderProperty );
		}
		float* DestAddress = (float*)BufferCursor;
		*DestAddress = VectorValue.R;
		BufferCursor = DestAddress + 1;
		check( BufferCursor <= TempBuffer + TempBufferSize );
	}
}
#endif

//#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 3
#if 0
FPreshaderValue EvaluatePreshader2(const FUniformExpressionSet* UniformExpressionSet, const FMaterialRenderContext& Context, FPreshaderStack& Stack, FPreshaderDataContext2& RESTRICT Data);
void GetProperyNames( FUniformExpressionSet_Override* Set, FMaterialRenderContext& MaterialRenderContext, void* BufferCursor, int TempBufferSize )
{
	float* const PreshaderBuffer = (float*)BufferCursor;
	FPreshaderStack PreshaderStack;
	FPreshaderDataContext2 PreshaderBaseContext( Set->GetUniformPreshaderData() );
	for( const FMaterialUniformPreshaderHeader& Preshader : Set->GetUniformPreshaders() )
	{
		FPreshaderDataContext2 PreshaderContext( PreshaderBaseContext, Preshader.OpcodeOffset, Preshader.OpcodeSize );
		const FPreshaderValue Result = EvaluatePreshader2( Set, MaterialRenderContext, PreshaderStack, PreshaderContext );

		// Fast path for non-structure float1 to float4 fields, which represents the vast majority of cases
		EValueType FirstFieldType = Set->GetUniformPreshaderFields()[ Preshader.FieldIndex ].Type;
		EValueType ResultType = Result.Type.ValueType;

		// This min-max logic assumes that Float1 through Float4 are sequential in the EValueType enum, so we can do just two comparisons
		// to detect if both Result and the destination field are float types.
		static_assert( (int32)EValueType::Float2 == (int32)EValueType::Float1 + 1 );
		static_assert( (int32)EValueType::Float3 == (int32)EValueType::Float2 + 1 );
		static_assert( (int32)EValueType::Float4 == (int32)EValueType::Float3 + 1 );

		int32 MinValueType = FMath::Min( (int32)FirstFieldType, (int32)ResultType );
		int32 MaxValueType = FMath::Max( (int32)FirstFieldType, (int32)ResultType );

		if( Preshader.NumFields == 1 && MinValueType >= (int32)EValueType::Float1 && MaxValueType <= (int32)EValueType::Float4 )
		{
			float* DestAddress = PreshaderBuffer + Set->GetUniformPreshaderFields()[ Preshader.FieldIndex ].BufferOffset;

			// Copy components that exist in both result and destination buffer
			int32 NumCopyComponents = MinValueType - ( (int32)EValueType::Float1 - 1 );
			for( int32 i = 0; i < NumCopyComponents; ++i )
			{
				*DestAddress++ = Result.Component[ i ].Float;
			}

			// Zero out any additional components that exist in the destination buffer
			int32 NumDestComponents = (int32)FirstFieldType - ( (int32)EValueType::Float1 - 1 );
			for( int32 i = NumCopyComponents; i < NumDestComponents; ++i )
			{
				*DestAddress++ = 0.0f;
			}
		}
		else
		{
			/*for( uint32 FieldIndex = 0u; FieldIndex < Preshader.NumFields; ++FieldIndex )
			{
				const FMaterialUniformPreshaderField& PreshaderField = Set->GetUniformPreshaderFields()[ Preshader.FieldIndex + FieldIndex ];
				const FValueTypeDescription UniformTypeDesc = GetValueTypeDescription( PreshaderField.Type );
				const int32 NumFieldComponents = UniformTypeDesc.NumComponents;

				const int32 NumResultComponents = FMath::Min<int32>( NumFieldComponents, Result.Component.Num() - PreshaderField.ComponentIndex );
				check( NumResultComponents > 0 );

				// The type generated by the preshader might not match the expected type
				// In the future, with new HLSLTree, preshader could potentially include explicit cast opcodes, and avoid implicit conversions
				// Making this change is difficult while also maintaining backwards compatibility however
				FValue FieldValue( Result.Type.GetComponentType( PreshaderField.ComponentIndex ), NumResultComponents );
				for( int32 i = 0; i < NumResultComponents; ++i )
				{
					FieldValue.Component[ i ] = Result.Component[ PreshaderField.ComponentIndex + i ];
				}

				if( UniformTypeDesc.ComponentType == EValueComponentType::Float )
				{
					FFloatValue FloatValue;// = FieldValue.AsFloat();
					float* DestAddress = PreshaderBuffer + PreshaderField.BufferOffset;
					for( int32 i = 0; i < NumFieldComponents; ++i )
					{
						*DestAddress++ = FloatValue[ i ];
					}
				}
				else if( UniformTypeDesc.ComponentType == EValueComponentType::Int )
				{
					FIntValue IntValue;// = FieldValue.AsInt();
					int32* DestAddress = (int32*)PreshaderBuffer + PreshaderField.BufferOffset;
					for( int32 i = 0; i < NumFieldComponents; ++i )
					{
						*DestAddress++ = IntValue[ i ];
					}
				}
				else if( UniformTypeDesc.ComponentType == EValueComponentType::Bool )
				{
					FBoolValue BoolValue;// = FieldValue.AsBool();
					uint32 Mask = 0u;
					for( int32 i = 0; i < NumFieldComponents; ++i )
					{
						if( BoolValue[ i ] )
						{
							Mask |= ( 1u << i );
						}
					}

					const uint32 BufferOffset = PreshaderField.BufferOffset / 32u;
					const uint32 BufferBitOffset = PreshaderField.BufferOffset % 32u;
					check( BufferBitOffset + NumFieldComponents <= 32u );

					uint32* DestAddress = (uint32*)PreshaderBuffer + BufferOffset;
					if( BufferBitOffset == 0u )
					{
						// First update to a group of bits needs to initialize memory
						*DestAddress = Mask;
					}
					else
					{
						// Combine with any previous bits
						*DestAddress |= ( Mask << BufferBitOffset );
					}
				}
				else if( UniformTypeDesc.ComponentType == EValueComponentType::Double )
				{
					FDoubleValue DoubleValue;// = FieldValue.AsDouble();

					float TileValue[ 4 ];
					float OffsetValue[ 4 ];
					for( int32 i = 0; i < NumFieldComponents; ++i )
					{
						const FLargeWorldRenderScalar Value( DoubleValue[ i ] );
						TileValue[ i ] = Value.GetTile();
						OffsetValue[ i ] = Value.GetOffset();
					}

					float* DestAddress = PreshaderBuffer + PreshaderField.BufferOffset;
					for( int32 i = 0; i < NumFieldComponents; ++i ) *DestAddress++ = TileValue[ i ];
					for( int32 i = 0; i < NumFieldComponents; ++i ) *DestAddress++ = OffsetValue[ i ];
				}
				else
				{
					ensure( false );
				}
			}*/
		}
	}
}
#endif
FLinearColor RemoveNans( FLinearColor Value )
{
	if( FMath::IsNaN( Value.R ) )
		Value.R = 0.0f;
	if( FMath::IsNaN( Value.G ) )
		Value.G = 0.0f;
	if( FMath::IsNaN( Value.B ) )
		Value.B = 0.0f;
	if( FMath::IsNaN( Value.A ) )
		Value.A = 0.0f;

	return Value;
}
FVector RemoveNans( FVector Value )
{
	if( FMath::IsNaN( Value.X ) )
		Value.X = 0.0f;
	if( FMath::IsNaN( Value.Y ) )
		Value.Y = 0.0f;
	if( FMath::IsNaN( Value.Z ) )
		Value.Z = 0.0f;

	return Value;
}
bool HasNans( FVector Value )
{
	if( FMath::IsNaN( Value.X ) || !FMath::IsFinite( Value.X ) )
		return true;
	if( FMath::IsNaN( Value.Y ) || !FMath::IsFinite( Value.Y ) )
		return true;
	if( FMath::IsNaN( Value.Z ) || !FMath::IsFinite( Value.Z ) )
		return true;

	return false;
}
std::string GetPropertyName( int Vector, int Scalar, const std::vector< ShaderProperty > & Properties )
{
	for( int i = 0; i < Properties.size(); i++ )
	{
		if( Vector != -1 && Vector == Properties[ i ].VectorIndex )
		{
			return Properties[ i ].Name;
		}
		if( Scalar != -1 && Scalar == Properties[ i ].ScalarIndex )
		{
			return Properties[ i ].Name;
		}
	}

	return "(Unknown)";
}
std::string GenerateInitializeExpressions( MaterialBinding *Mat, int & NumVectorExpressions, int & NumScalarExpressions )
{
	std::string DataString;

	if( !Mat || !Mat->MaterialResource )
	{
		UE_LOG( LogTemp, Error, TEXT( "ERROR! !Mat || !Mat->MaterialResource" ) );
		GLog->Flush();
		return "";
	}

	FMaterialResource* MaterialResource = Mat->MaterialResource;// M->GetMaterialResource( ERHIFeatureLevel::SM5 );
	const FMaterialShaderMap* ShaderMapToUse = MaterialResource->GetRenderingThreadShaderMap();
	
	if( !ShaderMapToUse )
	{
		UE_LOG( LogTemp, Error, TEXT( "ERROR! !ShaderMapToUse" ) );
		GLog->Flush();
		return "";
	}
	
	const FUniformExpressionSet* Set = &ShaderMapToUse->GetUniformExpressionSet();
	if( !Set )
	{
		UE_LOG( LogTemp, Error, TEXT( "ERROR! !Set" ) );
		GLog->Flush();
		return "";
	}
	FUniformExpressionSet_Override* Set_Override = (FUniformExpressionSet_Override*)Set;

	#if ENGINE_MAJOR_VERSION >= 5
		TMemoryImageArray<FMaterialUniformPreshaderHeader>& Preshaders = Set_Override->GetUniformPreshaders();	
		#if ENGINE_MINOR_VERSION >= 1
		TMemoryImageArray<FMaterialUniformPreshaderField>& PreshaderFields = Set_Override->GetUniformPreshaderFields();
		if( PreshaderFields.Num() > 0 )
		{
			FMaterialUniformPreshaderField Field = PreshaderFields[ PreshaderFields.Num() - 1 ];
			int BufferOffset = Field.BufferOffset;
			int NumFloats = ( (int)Field.Type - (int)UE::Shader::EValueType::Float1) + 1;
			int Size = NumFloats * sizeof( float );
			int TotalBufferSize = BufferOffset * sizeof(float) + Size;

			int Div = TotalBufferSize / ( sizeof( float ) * 4 );
			int Mod = TotalBufferSize % ( sizeof( float ) * 4 );
			NumVectorExpressions = Div;
			if( Mod > 0 )
				NumVectorExpressions++;
		}
		#else
			NumVectorExpressions = Preshaders.Num();
		#endif
		NumScalarExpressions = 0;
	#elif ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 26
		TMemoryImageArray<FMaterialUniformPreshaderHeader>& VectorPreshaders = Set_Override->GetVectorPreshaders();
		TMemoryImageArray<FMaterialUniformPreshaderHeader>& ScalarPreshaders = Set_Override->GetScalarPreshaders();

		NumVectorExpressions = VectorPreshaders.Num();
		NumScalarExpressions = ScalarPreshaders.Num();
	#endif

	int NumScalarVectors = ( NumScalarExpressions + 3 ) / 4;

	int ExtraSpaceForResources = 300;
	int BaseSize = ( NumVectorExpressions + NumScalarExpressions ) * 16;
	int TempBufferSize = BaseSize + ExtraSpaceForResources;	

	FMaterialRenderProxy* RenderProxy = Mat->RenderProxy;
	if( !RenderProxy )
	{
		if( Mat->MaterialInterface )
		{
			FString MessageText = FString::Printf( TEXT(
				"Error in %s"
				"!RenderProxy"
			), *Mat->MaterialInterface->GetName() );
			FText Txt = FText::FromString( MessageText );
			FMessageDialog::Open( EAppMsgType::Ok, Txt );
		}
		return "";
	}
	auto Cache = RenderProxy->UniformExpressionCache[ GlobalFeatureLevel ];
	static bool AllocatedVTsEarlyOut = false;
	#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION > 20) || ENGINE_MAJOR_VERSION == 5
	if( Cache.AllocatedVTs.Num() > 0 && AllocatedVTsEarlyOut )
	{
		if( Mat->MaterialInterface )
		{
			FString MessageText = FString::Printf( TEXT(
				"Error in %s\n"
				"Cache.AllocatedVTs.Num() > 0 !\n\n"
			), *Mat->MaterialInterface->GetName() );
			FText Txt = FText::FromString( MessageText );
			FMessageDialog::Open( EAppMsgType::Ok, Txt );
		}
		//Fix for crash in FillUniformBuffer
		return "";
	}
	#endif
	FMaterialRenderContext DummyContext( RenderProxy, *MaterialResource, nullptr );

	std::vector< ShaderProperty > Properties;


	#if ENGINE_MAJOR_VERSION >= 5
		const FRHIUniformBufferLayout* UniformBufferLayout = ShaderMapToUse->GetUniformBufferLayout();
		TempBufferSize = UniformBufferLayout->ConstantBufferSize;
		//if( UniformBufferLayout->Resources.Num() > 0 )
		//{
		//	int Offset = UniformBufferLayout->Resources[ UniformBufferLayout->Resources.Num() - 1 ].MemberOffset;
		//	FMath::Max( TempBufferSize, Offset + BaseSize );
		//}
		uint8* TempBuffer = new uint8[ TempBufferSize ];
		//Prevent nans from appearing in ScalarExpressions values
		float* FloatArray = (float*)TempBuffer;
		for( int i = 0; i < TempBufferSize / 4; i++ )
		{
			FloatArray[ i ] = 0.0f;
		}
		Set->FillUniformBuffer( DummyContext, Cache, UniformBufferLayout, TempBuffer, TempBufferSize );
	#elif (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 26)
		uint8* TempBuffer = new uint8[ TempBufferSize ];
		//Prevent nans from appearing in ScalarExpressions values
		float* FloatArray = (float*)TempBuffer;
		for( int i = 0; i < TempBufferSize / 4; i++ )
		{
			FloatArray[ i ] = 0.0f;
		}
		Set->FillUniformBuffer( DummyContext, Cache, TempBuffer, TempBufferSize );
	#else
		uint8* TempBuffer = new uint8[ TempBufferSize ];
	#endif
	#if ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 26
		GetPropertyNames( Set_Override, DummyContext, Properties, TempBuffer, TempBufferSize );
	#endif

	char ValueStr[ 256 ];
	snprintf( ValueStr, sizeof( ValueStr ),
			  "void InitializeExpressions()\r\n"
			  "{\r\n" );// , VectorExpressions.Num(), ScalarExpressions.Num() );
	DataString += ValueStr;

	int SizePerVTStack = 32;
	int SizePerVirtualTextureUsed = sizeof( FUintVector4 );
	int NumVirtualTextures = 0;
	int TotalOffset = 0;
	#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION > 20) || ENGINE_MAJOR_VERSION == 5
		NumVirtualTextures = Set->GetNumTextures( EMaterialTextureParameterType::Virtual );
		TotalOffset = Cache.AllocatedVTs.Num() * SizePerVTStack + NumVirtualTextures * SizePerVirtualTextureUsed;
	#endif
	uint8* BufferCursor = TempBuffer + TotalOffset;
	
	for( int i = 0; i < NumVectorExpressions; i++ )
	{
		FLinearColor OutValue = *(FLinearColor*)BufferCursor;
		if( BufferCursor + sizeof( FLinearColor ) < TempBuffer + TempBufferSize )
		{
			BufferCursor += sizeof( FLinearColor );
		}
		OutValue = RemoveNans( OutValue );
		std::string Name = GetPropertyName( i, -1, Properties );
	#if ENGINE_MAJOR_VERSION >= 5
		snprintf( ValueStr, sizeof( ValueStr), "\tMaterial.PreshaderBuffer[%d] = float4(%f,%f,%f,%f);//%s\r\n", i, OutValue.R, OutValue.G, OutValue.B, OutValue.A, Name.c_str());
	#else
		snprintf( ValueStr, sizeof( ValueStr ), "\tMaterial.VectorExpressions[%d] = float4(%f,%f,%f,%f);//%s\r\n", i, OutValue.R, OutValue.G, OutValue.B, OutValue.A, Name.c_str() );
	#endif
		DataString += ValueStr;
	}

	for( int i = 0; i < NumScalarVectors; i++ )
	{
		FLinearColor ScalarValues = *(FLinearColor*)BufferCursor;
		BufferCursor += sizeof( FLinearColor );
		ScalarValues = RemoveNans( ScalarValues );
		std::string Name1 = GetPropertyName( -1, i * 4 + 0, Properties );
		std::string Name2 = GetPropertyName( -1, i * 4 + 1, Properties );
		std::string Name3 = GetPropertyName( -1, i * 4 + 2, Properties );
		std::string Name4 = GetPropertyName( -1, i * 4 + 3, Properties );
		snprintf( ValueStr, sizeof( ValueStr ), "\tMaterial.ScalarExpressions[%d] = float4(%f,%f,%f,%f);//%s %s %s %s\r\n", i,
					ScalarValues.R, ScalarValues.G, ScalarValues.B, ScalarValues.A, Name1.c_str(), Name2.c_str(), Name3.c_str(), Name4.c_str() );
		DataString += ValueStr;

		ensure( BufferCursor <= TempBuffer + TempBufferSize );
	}	

	DataString += "}\r\n";
	delete[] TempBuffer;
	
	return DataString;	
}

std::string AddNumberInString( std::string OriginalString, const char *Prefix, int Number )
{
	int PrefixOffset = OriginalString.find( Prefix );
	int NumberStart = PrefixOffset + strlen( Prefix );

	char NumberStr[ 32 ];
	snprintf( NumberStr, sizeof( NumberStr ), "%d", Number );
	//Erases the existing "1"
	OriginalString.replace( NumberStart, 1, "" );
	OriginalString.insert( NumberStart, NumberStr );
	return OriginalString;
}
int StringReplacement( std::string & OriginalString, const char *What, const char* Replace, int StartPos)
{
	int WhatLen = strlen( What );
	int ReplaceLen = strlen( Replace );

	int pos = StartPos;
	int Replacements = 0;
	pos = OriginalString.find( What, StartPos );
	while( pos != -1 )
	{
		OriginalString.replace( pos, WhatLen, Replace );
		pos = OriginalString.find( What, pos + ReplaceLen );
		Replacements++;
	}

	return Replacements;
}
int DetectMaxVariableSize( std::string GeneratedShader, std::string VariableName )
{
	int Offset = 0;
	int Val = 0;
	int MaxValue = -1;
	int pos = 0;
	while( pos != - 1 )
	{
		pos = GeneratedShader.find( VariableName, Offset );
		if( pos == -1 )
		{
			break;
		}
		else
		{
			int IndexEndPos = GeneratedShader.find( "]", pos );
			int IndexStartPos = pos + VariableName.length() + 1;
			std::string StrIndex = GeneratedShader.substr( IndexStartPos, IndexEndPos - IndexStartPos );
			if( sscanf( StrIndex.c_str(), "%d", &Val ) == 1 )
			{
				if( MaxValue == -1 )
					MaxValue = Val;
				else
					MaxValue = FMath::Max( MaxValue, Val );
			}
			Offset = pos + 1;
		}
	}
	if( MaxValue == -1 )
		MaxValue = 0;
	return MaxValue;
}
const int MaxTextures = 48;
void DetectNumTexturesUsed( std::string GeneratedShader, int* Actual2DTexturesUsed, int* ActualCubeTexturesUsed,
							int* ActualTextureArraysUsed, int* ActualCubeArraysUsed, int* Actual3DTexturesUsed, int* ActualPhysicalTexturesUsed,
							const char* BeginMarker, const char* EndMarker)
{
	int Offset = 0;
	if ( BeginMarker )
		Offset = GeneratedShader.find( BeginMarker );
	int End = GeneratedShader.length();
	if ( EndMarker )
		End = GeneratedShader.find( EndMarker );

	for( int i = 0; i < MaxTextures; i++ )
	{
		char Tex2DRef[ 256 ];
		snprintf( Tex2DRef, sizeof( Tex2DRef ), "Material_Texture2D_%d", i );
		int pos = GeneratedShader.find( Tex2DRef, Offset );
		if( pos != -1 && pos < End )
		{
			Actual2DTexturesUsed[ i ] = 1;
			continue;
		}
	}

	for( int i = 0; i < MaxTextures; i++ )
	{
		char TexCubeRef[ 256 ];
		snprintf( TexCubeRef, sizeof( TexCubeRef ), "Material_TextureCube_%d", i );
		int pos = GeneratedShader.find( TexCubeRef, Offset );
		if( pos != -1 && pos < End )
		{
			ActualCubeTexturesUsed[ i ] = 1;
		}
	}

	for( int i = 0; i < MaxTextures; i++ )
	{
		char Tex2DRef[ 256 ];
		snprintf( Tex2DRef, sizeof( Tex2DRef ), "Material_Texture2DArray_%d", i );
		int pos = GeneratedShader.find( Tex2DRef, Offset );
		if( pos != -1 && pos < End )
		{
			ActualTextureArraysUsed[ i ] = 1;
			continue;
		}
	}

	for( int i = 0; i < MaxTextures; i++ )
	{
		char TexCubeRef[ 256 ];
		snprintf( TexCubeRef, sizeof( TexCubeRef ), "Material_TextureCubeArray_%d", i );
		int pos = GeneratedShader.find( TexCubeRef, Offset );
		if( pos != -1 && pos < End )
		{
			ActualCubeArraysUsed[ i ] = 1;
		}
	}

	for( int i = 0; i < MaxTextures; i++ )
	{
		char Tex3DRef[ 256 ];
		snprintf( Tex3DRef, sizeof( Tex3DRef ), "Material_VolumeTexture_%d", i );
		int pos = GeneratedShader.find( Tex3DRef, Offset );
		if( pos != -1 && pos < End )
		{
			Actual3DTexturesUsed[ i ] = 1;
			continue;
		}
	}

	for( int i = 0; i < MaxTextures; i++ )
	{
		char PhysicalTexRef[ 256 ];
		snprintf( PhysicalTexRef, sizeof( PhysicalTexRef ), "Material_VirtualTexturePhysical_%d", i );
		int pos = GeneratedShader.find( PhysicalTexRef, Offset );
		if( pos != -1 && pos < End )
		{
			ActualPhysicalTexturesUsed[ i ] = 1;
			continue;
		}
	}
}
void AddTexProperty( int& Cursor, std::string* TargetString, int i, int ParamIndex, MaterialBinding* Mat, const char* Format1, const char* Format2 )
{
	char Line[ 1024 ];
	snprintf( Line, sizeof( Line ), Format1, i );
	FString TexParamName( Line );
	if( ParamIndex < Mat->TextureParamNames.Num() )
		TexParamName = Mat->TextureParamNames[ ParamIndex ];
	std::string TexParamNameCStr = ToANSIString( *TexParamName );

	snprintf( Line, sizeof( Line ), Format2, i, TexParamNameCStr.c_str() );
	int LineLen = strlen( Line );
	TargetString->insert( Cursor, Line );
	Cursor += LineLen;
}
void AddTexDecalaration( int& Cursor, std::string* TargetString, int i, std::string& VS, std::string& PS, const char* UESamplerFormat, const char* UnitySamplerFormat,
						 const char* TextureSamplerFormatURP_HDRP, const char* TextureSamplerFormatBuiltIn )
{
	char Line[ 1024 ];
	if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_URP ||
		CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
	{
		char SamplerNameOriginal[ 1024 ] = "";
		snprintf( SamplerNameOriginal, sizeof( SamplerNameOriginal ), UESamplerFormat, i );
		char SamplerNameReplacement[ 1024 ] = "";
		snprintf( SamplerNameReplacement, sizeof( SamplerNameReplacement ), UnitySamplerFormat, i );

		StringReplacement( PS, SamplerNameOriginal, SamplerNameReplacement );
		StringReplacement( VS, SamplerNameOriginal, SamplerNameReplacement );

		snprintf( Line, sizeof( Line ), TextureSamplerFormatURP_HDRP, i, i, i, i );
	}
	else
	{
		snprintf( Line, sizeof( Line ), TextureSamplerFormatBuiltIn, i, i );
	}
	int LineLen = strlen( Line );
	TargetString->insert( Cursor, Line );
	Cursor += LineLen;
}
void GeneratePropertyFields( std::string & GeneratedShader, MaterialBinding* Mat, std::string& GraphShader, std::string& VSStr )
{
	std::string* TargetString = &GeneratedShader;
	
	int Actual2DTexturesUsed[ MaxTextures ] = { 0 };
	int ActualCubeTexturesUsed[ MaxTextures ] = { 0 };
	int ActualTextureArraysUsed[ MaxTextures ] = { 0 };
	int ActualCubeArraysUsed[ MaxTextures ] = { 0 };
	int Actual3DTexturesUsed[ MaxTextures ] = { 0 };
	int ActualPhysicalTexturesUsed[ MaxTextures ] = { 0 };
	DetectNumTexturesUsed( *TargetString, Actual2DTexturesUsed, ActualCubeTexturesUsed, ActualTextureArraysUsed, ActualCubeArraysUsed, Actual3DTexturesUsed,
						   ActualPhysicalTexturesUsed, "CalcPixelMaterialInputs", "PixelMaterialInputs.PixelDepthOffset =" );
	if( VSStr.length() > 0 )
	{
		DetectNumTexturesUsed( VSStr, Actual2DTexturesUsed, ActualCubeTexturesUsed, ActualTextureArraysUsed, ActualCubeArraysUsed, Actual3DTexturesUsed,
							   ActualPhysicalTexturesUsed,
							   nullptr, nullptr );
	}

	if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_URP || CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
		TargetString = &GraphShader;

	int MainTexStart = TargetString->find( "_MainTex" );
	if( MainTexStart == -1 )
	{
		UE_LOG( LogTemp, Error, TEXT( "[UTU] ERROR! GeneratePropertyFields pos == -1 wtf ?" ) );
		return;
	}

	int Cursor = TargetString->find( "\n", MainTexStart );
	Cursor++;

	int ParamIndex = 0;
	for( int i = 0; i < MaxTextures; i++ )
	{
		bool Used = ( Actual2DTexturesUsed[ i ] == 1 );
		if( Used )
		{
			AddTexProperty( Cursor, TargetString, i, ParamIndex, Mat, "Tex%d", "\t\tMaterial_Texture2D_%d( \"%s\", 2D ) = \"white\" {}\n" );
			ParamIndex++;
		}
	}
	for( int i = 0; i < MaxTextures; i++ )
	{
		bool Used = ( ActualCubeTexturesUsed[ i ] == 1 );
		if( Used )
		{
			AddTexProperty( Cursor, TargetString, i, ParamIndex, Mat, "TexCube%d", "\t\tMaterial_TextureCube_%d( \"%s\", Cube ) = \"white\" {}\n" );
			ParamIndex++;
		}
	}
	for( int i = 0; i < MaxTextures; i++ )
	{
		bool Used = ( ActualTextureArraysUsed[ i ] == 1 );
		if( Used )
		{
			AddTexProperty( Cursor, TargetString, i, ParamIndex, Mat, "Tex2DArray%d", "\t\tMaterial_Texture2DArray_%d( \"%s\", 2DArray ) = \"white\" {}\n" );
			ParamIndex++;
		}
	}
	for( int i = 0; i < MaxTextures; i++ )
	{
		bool Used = ( Actual3DTexturesUsed[ i ] == 1 );
		if( Used )
		{
			AddTexProperty( Cursor, TargetString, i, ParamIndex, Mat, "Tex3D%d", "\t\tMaterial_VolumeTexture_%d( \"%s\", 3D ) = \"white\" {}\n" );
			ParamIndex++;
		}
	}
	for( int i = 0; i < MaxTextures; i++ )
	{
		bool Used = ( ActualPhysicalTexturesUsed[ i ] == 1 );
		if( Used )
		{
			AddTexProperty( Cursor, TargetString, i, ParamIndex, Mat, "PhysicalTex%d", "\t\tMaterial_VirtualTexturePhysical_%d( \"%s\", 2D ) = \"white\" {}\n" );
			ParamIndex++;
		}
	}

	TargetString = &GeneratedShader;	

	const char* SamplersStart = "//samplers start";
	Cursor = TargetString->find( SamplersStart, 0 );
	Cursor = TargetString->find( "\n", Cursor );
	Cursor++;

	if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_URP ||
		CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
	{
		const char* SamplerLines = "SAMPLER( SamplerState_Linear_Repeat );\n"
								   "SAMPLER( SamplerState_Linear_Clamp );\n";
		TargetString->insert( Cursor, SamplerLines );
		Cursor += strlen( SamplerLines );
	}

	for( int i = 0; i < MaxTextures; i++ )
	{
		bool Used = (Actual2DTexturesUsed[ i ] == 1);
		if( Used )
		{
			AddTexDecalaration( Cursor, TargetString, i, VSStr, GeneratedShader, "Material_Texture2D_%dSampler", "samplerMaterial_Texture2D_%d",
								"TEXTURE2D(       Material_Texture2D_%d );\n"
								"SAMPLER(  samplerMaterial_Texture2D_%d );\n"
								"float4 Material_Texture2D_%d_TexelSize;\n"
								"float4 Material_Texture2D_%d_ST;\n",
								"\t\t\tuniform sampler2D    Material_Texture2D_%d;\n"
								"\t\t\tuniform SamplerState Material_Texture2D_%dSampler;\n" );
		}
	}
	for( int i = 0; i < MaxTextures; i++ )
	{
		bool Used = ( ActualCubeTexturesUsed[ i ] == 1 );
		if( Used )
		{
			AddTexDecalaration( Cursor, TargetString, i, VSStr, GeneratedShader, "Material_TextureCube_%dSampler", "samplerMaterial_TextureCube_%d",
								"TEXTURECUBE(     Material_TextureCube_%d );\n"
								"SAMPLER(  samplerMaterial_TextureCube_%d );\n",
								//"float4 Material_TextureCube_%d_TexelSize;\n"
								//"float4 Material_TextureCube_%d_ST;\n",
								"\t\t\tuniform samplerCUBE  Material_TextureCube_%d;\n"
								"\t\t\tuniform SamplerState Material_TextureCube_%dSampler;\n" );
		}
	}	
	for( int i = 0; i < MaxTextures; i++ )
	{
		bool Used = ( ActualTextureArraysUsed[ i ] == 1 );
		if( Used )
		{
			AddTexDecalaration( Cursor, TargetString, i, VSStr, GeneratedShader, "Material_Texture2DArray_%dSampler", "samplerMaterial_Texture2DArray_%d",
								"TEXTURE2D_ARRAY( Material_Texture2DArray_%d );\n"
								"SAMPLER(  samplerMaterial_Texture2DArray_%d );\n",
								//"float4 Material_Texture2DArray_%d_TexelSize;\n"
								//"float4 Material_Texture2DArray_%d_ST;\n",
								"\t\t\tuniform sampler2DArray    Material_Texture2DArray_%d;\n"
								"\t\t\tuniform SamplerState Material_Texture2DArray_%dSampler;\n" );
		}
	}
	for( int i = 0; i < MaxTextures; i++ )
	{
		bool Used = ( ActualCubeArraysUsed[ i ] == 1 );
		if( Used )
		{
			AddTexDecalaration( Cursor, TargetString, i, VSStr, GeneratedShader, "Material_TextureCubeArray_%dSampler", "samplerMaterial_TextureCubeArray_%d",
								"TEXTURECUBE_ARRAY( Material_TextureCubeArray_%d );\n"
								"SAMPLER(    samplerMaterial_TextureCubeArray_%d );\n",
								//"float4 Material_TextureCubeArray_%d_TexelSize;\n"
								//"float4 Material_TextureCubeArray_%d_ST;\n",
								"\t\t\tuniform samplerCUBEArray  Material_TextureCubeArray_%d;\n"
								"\t\t\tuniform SamplerState Material_TextureCubeArray_%dSampler;\n" );
		}
	}
	for( int i = 0; i < MaxTextures; i++ )
	{
		bool Used = ( Actual3DTexturesUsed[ i ] == 1 );
		if( Used )
		{
			AddTexDecalaration( Cursor, TargetString, i, VSStr, GeneratedShader, "Material_VolumeTexture_%dSampler", "samplerMaterial_VolumeTexture_%d",
								"TEXTURE3D(       Material_VolumeTexture_%d );\n"
								"SAMPLER(  samplerMaterial_VolumeTexture_%d );\n",
								//"float4 Material_VolumeTexture_%d_TexelSize;\n"
								//"float4 Material_VolumeTexture_%d_ST;\n",
								"\t\t\tuniform sampler3D    Material_VolumeTexture_%d;\n"
								"\t\t\tuniform SamplerState Material_VolumeTexture_%dSampler;\n" );
		}
	}
	for( int i = 0; i < MaxTextures; i++ )
	{
		bool Used = ( ActualPhysicalTexturesUsed[ i ] == 1 );
		if( Used )
		{
			AddTexDecalaration( Cursor, TargetString, i, VSStr, GeneratedShader, "Material_VirtualTexturePhysical_%dSampler", "samplerMaterial_VirtualTexturePhysical_%d",
								"TEXTURE2D(       Material_VirtualTexturePhysical_%d );\n"
								"SAMPLER(  samplerMaterial_VirtualTexturePhysical_%d );\n",
								//"float4 Material_VirtualTexturePhysical_%d_TexelSize;\n"
								//"float4 Material_VirtualTexturePhysical_%d_ST;\n",
								"\t\t\tuniform sampler2D    Material_VirtualTexturePhysical_%d;\n"
								"\t\t\tuniform SamplerState Material_VirtualTexturePhysical_%dSampler;\n" );
		}
	}
}

MaterialBinding::MaterialBinding()
{
	UnityMat = new UnityMaterial();
	GUnityScene->Materials.push_back( UnityMat );
}
FString MaterialBinding::GenerateName()
{
	FString MatName = MaterialInterface->GetName();
	
	UMaterialInstanceDynamic* MID = Cast<UMaterialInstanceDynamic>( MaterialInterface );
	if( MID )
	{
		MatName = FString::Printf( TEXT( "%s_%d" ), *MatName, MaterialInterface->GetUniqueID() );
		FString ParentName = MID->Parent->GetName();
		FString FinalName = ParentName + TEXT("(" ) + MatName + TEXT(")" );
		UnityMat->Name = ToANSIString( *FinalName );
		return FinalName;
	}
	else
	{
		UnityMat->Name = TCHAR_TO_ANSI( *MatName );
		return MatName;
	}
}
bool IsTextureNormalMap( UMaterial* Mat, UTexture *Tex )
{
	TArray<UMaterialExpression*> OutExpressions = GetExpressions( Mat );
	
	for( int i = 0; i < OutExpressions.Num(); i++ )
	{
		UMaterialExpression* Exp = OutExpressions[ i ];
		UMaterialExpressionTextureSample* SampleExpression = Cast< UMaterialExpressionTextureSample>( Exp );
		if( SampleExpression )
		{
			if( SampleExpression->Texture == Tex )
			{
				if( SampleExpression->SamplerType == SAMPLERTYPE_Normal )
					return true;
				else
					return false;
				//if( SampleExpression->SamplerType == SAMPLERTYPE_Color )
			}
		}
	}

	return false;
}
bool IsTextureNormalMap( UMaterialInstance* MaterialInstance, UTexture* Tex )
{
	UMaterial* BaseMaterial = MaterialInstance->GetBaseMaterial();
	bool IsNormalMap = false;
	TArray<FMaterialParameterInfo> OutParameterInfo;
	TArray<FGuid> OutParameterIds;
	MaterialInstance->GetAllTextureParameterInfo( OutParameterInfo, OutParameterIds );
	for( int i = 0; i < OutParameterInfo.Num(); i++ )
	{
		FMaterialParameterInfo& Info = OutParameterInfo[ i ];

		UTexture* OutValue = nullptr;
		if( MaterialInstance->GetTextureParameterValue( Info, OutValue ) && OutValue )
		{
			if( OutValue == Tex )
			{
				UTexture* DefaultTexture = nullptr;
				if( BaseMaterial->GetTextureParameterDefaultValue( Info, DefaultTexture ) && DefaultTexture )
				{
					IsNormalMap = IsTextureNormalMap( BaseMaterial, DefaultTexture );
					return IsNormalMap;
				}
			}
		}
	}

	return false;
}
void GetMaterialTextures( UMaterialInterface* UnrealMat, TArray<UTexture*>& OutTextures, TArray<FString>& TextureParamNames )
{	
	#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION > 20) || ENGINE_MAJOR_VERSION == 5
	const FMaterialResource* MaterialResource = UnrealMat->GetMaterialResource( GlobalFeatureLevel, GlobalQualityLevel );
	if( MaterialResource )
	{
		const FUniformExpressionSet& UniformExpressions = MaterialResource->GetUniformExpressions();
		int32 Count = (uint32)EMaterialTextureParameterType::Count;
		for( int32 TypeIndex = 0; TypeIndex < Count; TypeIndex++ )
		{
			int NumTextures = UniformExpressions.GetNumTextures( (EMaterialTextureParameterType)TypeIndex );
			for( int32 TextureIndex = 0; TextureIndex < NumTextures; TextureIndex++ )
			{
				// Evaluate the expression in terms of this material instance.
				UTexture* Texture = NULL;
				if ( IsInGameThread() )
					UniformExpressions.GetGameThreadTextureValue( (EMaterialTextureParameterType)TypeIndex, TextureIndex, UnrealMat, *MaterialResource, Texture, true );
				else
				{
					FMaterialRenderContext DummyContext( UnrealMat->GetRenderProxy(), *MaterialResource, nullptr);
					UniformExpressions.GetTextureValue( (EMaterialTextureParameterType)TypeIndex, TextureIndex, DummyContext, *MaterialResource, (const UTexture*&)Texture );
				}

				if( !Texture )
				{
					//Edge case when material instance texture is overriden but is null and UE uses the base texture in this case
					UniformExpressions.GetGameThreadTextureValue( (EMaterialTextureParameterType)TypeIndex, TextureIndex, UnrealMat->GetBaseMaterial(), *MaterialResource, Texture, true);
				}
				OutTextures.Add( Texture );
				FMaterialTextureParameterInfo Param = UniformExpressions.GetTextureParameter( (EMaterialTextureParameterType)TypeIndex, TextureIndex );
				#if ENGINE_MINOR_VERSION >= 26 || ENGINE_MAJOR_VERSION >= 5
					FString ParamName = Param.ParameterInfo.Name.ToString();
				#else
					FString ParamName = Param.ParameterName;
				#endif
				if( ParamName.Equals( TEXT("None") ) && Texture)
				{
					ParamName = Texture->GetName();
				}
				TextureParamNames.Add( ParamName );
			}
		}
	}
	else
	{
		TArray< TArray<int32> > TextureIndices;
		UnrealMat->GetUsedTexturesAndIndices( OutTextures, TextureIndices, GlobalQualityLevel, GlobalFeatureLevel );
	}
	#else
	const FMaterialResource* MaterialResource = UnrealMat->GetMaterialResource( GlobalFeatureLevel, GlobalQualityLevel );
	if( MaterialResource )
	{
		FMaterialShaderMap* MaterialShaderMap = MaterialResource->GetGameThreadShaderMap();
		const FUniformExpressionSet& UniformExpressions = MaterialShaderMap->GetUniformExpressionSet();
		FUniformExpressionSet_Override* UniformExpressions_Override = (FUniformExpressionSet_Override*)&UniformExpressions;

		auto Uniform2DTextureExpressions = UniformExpressions_Override->GetUniform2DTextureExpressions();
		auto UniformCubeTextureExpressions = UniformExpressions_Override->GetUniformCubeTextureExpressions();
		auto UniformVolumeTextureExpressions = UniformExpressions_Override->GetUniformVolumeTextureExpressions();
		
		FMaterialRenderContext DummyContext( UnrealMat->GetRenderProxy( false ), *MaterialResource, nullptr );

		for( int i = 0; i < Uniform2DTextureExpressions.Num(); i++)
		{
			FMaterialUniformExpressionTexture* TextureExpression = Uniform2DTextureExpressions[ i ].GetReference();
			const UTexture* Texture = NULL;
			ESamplerSourceMode OutSamplerSource;
			TextureExpression->GetTextureValue( DummyContext, *MaterialResource, Texture, OutSamplerSource );
			if( Texture )
			{
				OutTextures.Add( ( UTexture*)Texture );
				//TextureParamNames.Add( TextureExpression-> );
				//MaterialResource->param
				//FMaterial::GetReferencedTextures
			}
		}
		for( int i = 0; i < UniformCubeTextureExpressions.Num(); i++)
		{
		}
		for( int i = 0; i < UniformVolumeTextureExpressions.Num(); i++ )
		{
		}
		//TArray<TRefCountPtr<FMaterialUniformExpressionTexture> > Uniform2DTextureExpressions;
		//TArray<TRefCountPtr<FMaterialUniformExpressionTexture> > UniformCubeTextureExpressions;
		//TArray<TRefCountPtr<FMaterialUniformExpressionTexture> > UniformVolumeTextureExpressions;
	}
	#endif
}
void CountTextures( MaterialBinding* Mat, TArray<UTexture*>& AllUsedTextures )
{
	UMaterialInterface* UnrealMat = Mat->MaterialInterface;
	TArray<UTexture*> UsedTextures;
	TArray< TArray<int32> > TextureIndices;
	GetMaterialTextures( UnrealMat, UsedTextures, Mat->TextureParamNames );

	for( int i = 0; i < UsedTextures.Num(); i++ )
	{
		if( AllUsedTextures.Find( UsedTextures[ i ] ) == INDEX_NONE )
			AllUsedTextures.Add( UsedTextures[ i ] );
	}

	Mat->TextureParamNames.Reset( 0 );
}
TextureSemantic MaterialPropertyToTextureSemantic( EMaterialProperty MP )
{
	switch( MP )
	{
		case MP_EmissiveColor	: return TS_EmissionMap;
		case MP_Opacity			: return TS_Unknown;
		case MP_OpacityMask		: return TS_Unknown;
		case MP_BaseColor		: return TS_BaseMap;
		case MP_Metallic		: return TS_MetallicGlossMap;
		case MP_Specular		: return TS_MetallicGlossMap;
		case MP_Roughness		: return TS_Unknown;
		case MP_Normal			: return TS_BumpMap;
		case MP_AmbientOcclusion: return TS_OcclusionMap;
		//Unsure about this
		case MP_MaterialAttributes: return TS_BaseMap;

		default: return TS_Unknown;
	}
}
class SemanticArray
{
public:
	TArray<TextureSemantic> Array;
	TextureSemantic Selection = TS_Unknown;
};

void EvaluateSemantics( TArray<SemanticArray>& TextureSemantics, TArray<FString> TextureParamNames )
{

	const char* Keywords[ TS_MaxSemantics ][ 3 ] = {
		{"","",""},
		{"Diffuse","Albedo","Base"},//TS_BaseMap
		{"Normal","Nrm","Bump"},//TS_BumpMap
		{"Detail","",""},//TS_DetailAlbedoMap
		{"Detail","",""},//TS_DetailMask
		{"Detail","",""},//TS_DetailNormalMap
		{"Emission","Emissive",""},//TS_EmissionMap
		{"","",""},//TS_MainTex		
		{"Metal","Gloss",""},//TS_MetallicGlossMap
		{"Occlusion","ORM","AO"},//TS_OcclusionMap
		{"Parallax","",""},//TS_ParallaxMap
		{"","",""},//TS_SpecGlossMap
	};
	for( int i = 1; i < TS_MaxSemantics; i++ )
	{
		TextureSemantic Semantic = (TextureSemantic)i;
		TArray<int> TexturesWithSemantic;
		for( int u = 0; u < TextureSemantics.Num(); u++ )
		{
			for( int t = 0; t < TextureSemantics[ u ].Array.Num(); t++ )
			{
				if( TextureSemantics[ u ].Array[ t ] == Semantic )
				{
					TexturesWithSemantic.Add( u );
				}
			}
		}

		for( int u = 0; u < TexturesWithSemantic.Num(); u++ )
		{
			bool Matches = false;
			for( int k = 0; k < 3; k++ )
			{
				if ( TextureParamNames.Num() > TexturesWithSemantic[ u ] &&
					 TextureParamNames[ TexturesWithSemantic[ u ] ].Contains( Keywords[ Semantic ][ k ] ))
				{
					//keep it
					Matches = true;
					break;
				}
			}
			if( Matches )
				TextureSemantics[ TexturesWithSemantic[ u ] ].Selection = Semantic;
		}
	}

	//The semantics that I know for sure were selected based on their names
	bool DetectedSemantics[ TS_MaxSemantics ] = { false };
	for( int u = 0; u < TextureSemantics.Num(); u++ )
	{
		DetectedSemantics[ TextureSemantics[ u ].Selection ] = true;
	}

	for( int u = 0; u < TextureSemantics.Num(); u++ )
	{
		//If not detected choose the first semantic, but not one that was previously explicitly selected
		SemanticArray& SA = TextureSemantics[ u ];
		if( SA.Selection == TS_Unknown && SA.Array.Num() > 0 )
		{
			for( int s = 0; s < SA.Array.Num(); s++ )
			{
				if( !DetectedSemantics[ SA.Array[ s ] ] )
				{
					SA.Selection = SA.Array[ s ];
					break;
				}
			}
		}
	}
}
//Unreal thinks these are colors so it converted them to SRGB for no reason
float ConvertToOriginalValue( float InVal )
{
	FLinearColor R( InVal, InVal, InVal, InVal );
	FColor Color = R.ToFColor( true );
	float OutVal = (float)Color.R / 255.0f;
	return OutVal;
}
FExpressionInput* GetMaterialAttributesInput( UMaterialExpressionMakeMaterialAttributes* MaterialAttributes, EMaterialProperty Property )
{
	switch( Property )
	{
		case MP_EmissiveColor: return &MaterialAttributes->EmissiveColor;
		case MP_Opacity: return &MaterialAttributes->Opacity;
		case MP_OpacityMask: return &MaterialAttributes->OpacityMask;
		default:
		case MP_BaseColor: return &MaterialAttributes->BaseColor;
		case MP_Metallic: return &MaterialAttributes->Metallic;
		case MP_Specular: return &MaterialAttributes->Specular;
		case MP_Roughness: return &MaterialAttributes->Roughness;
		case MP_Normal: return &MaterialAttributes->Normal;
		case MP_AmbientOcclusion: return &MaterialAttributes->AmbientOcclusion;
	}
}

#if ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION < 26
namespace ERHIShadingPath
{
	enum Type : int
	{
		Deferred,
		Forward,
		Mobile,
		Num
	};
}
#endif
bool GetExpressionsInPropertyChain( UMaterial* Material, EMaterialProperty InProperty,
											   TArray<UMaterialExpression*>& OutExpressions, struct FStaticParameterSet* InStaticParameterSet,
											   ERHIFeatureLevel::Type InFeatureLevel, EMaterialQualityLevel::Type InQuality, ERHIShadingPath::Type InShadingPath, bool SearchFunctions )
{
#if ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION < 26
	bool RetrievedExpressions = Material->GetExpressionsInPropertyChain( InProperty, OutExpressions, InStaticParameterSet, InFeatureLevel, InQuality );
#elif ENGINE_MAJOR_VERSION == 4 || (ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION <= 1 )
	bool RetrievedExpressions = Material->GetExpressionsInPropertyChain( InProperty, OutExpressions, InStaticParameterSet, InFeatureLevel, InQuality, InShadingPath );
#else
	bool RetrievedExpressions = Material->GetExpressionsInPropertyChain( InProperty, OutExpressions, InStaticParameterSet, InFeatureLevel, InQuality, InShadingPath, SearchFunctions );
#endif
	return RetrievedExpressions;
}
class UMaterial2 : public UMaterial
{
public:
	bool RecursiveGetExpressionChainPublic( UMaterialExpression* InExpression, TArray<FExpressionInput*>& InOutProcessedInputs,
													TArray<UMaterialExpression*>& OutExpressions, struct FStaticParameterSet* InStaticParameterSet,
													ERHIFeatureLevel::Type InFeatureLevel = ERHIFeatureLevel::Num,
													EMaterialQualityLevel::Type InQuality = EMaterialQualityLevel::Num,
													ERHIShadingPath::Type InShadingPath = ERHIShadingPath::Num,
													EShaderFrequency InShaderFrequency = SF_NumFrequencies,
													EMaterialProperty InProperty = MP_MAX,
													const bool bInRecurseIntoMaterialFunctions = false )
	{
	#if ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION < 26
		return RecursiveGetExpressionChain(
			InExpression,
			InOutProcessedInputs,
			OutExpressions, InStaticParameterSet,
			InFeatureLevel,
			InQuality );
	#elif ENGINE_MAJOR_VERSION == 4 || (ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION <= 1 )
		return RecursiveGetExpressionChain(
			InExpression,
			InOutProcessedInputs,
			OutExpressions, InStaticParameterSet,
			InFeatureLevel,
			InQuality,
			InShadingPath,
			InShaderFrequency );
	#else
		return RecursiveGetExpressionChain(
			InExpression,
			InOutProcessedInputs,
			OutExpressions, InStaticParameterSet,
			InFeatureLevel,
			InQuality,
			InShadingPath,
			InShaderFrequency,
			InProperty,
			bInRecurseIntoMaterialFunctions );
	#endif
	}
};
void ExportMaterialTextures( MaterialBinding *Mat, TArray<UTexture*>& AllUsedTextures, int InitialTotalTextures )
{
	UMaterialInterface *UnrealMat = Mat->MaterialInterface;

	TArray<UTexture*> UsedTextures;
	TArray<SemanticArray> TextureSemantics;
	GetMaterialTextures( UnrealMat, UsedTextures, Mat->TextureParamNames );

	for( int i = 0; i < UsedTextures.Num(); i++ )
	{
		SemanticArray EmptyArray;
		TextureSemantics.Add( EmptyArray );
	}

	EMaterialProperty PropertiesToTrace[10] =
	{
		MP_EmissiveColor ,
		MP_Opacity ,
		MP_OpacityMask ,
		MP_BaseColor ,
		MP_Metallic ,
		MP_Specular ,
		MP_Roughness ,
		MP_Normal ,
		MP_AmbientOcclusion,		
	};
	auto BaseMaterial = UnrealMat->GetBaseMaterial();
	UMaterialInstance* MatInst = Cast<UMaterialInstance>( UnrealMat );
	
	{
		int NumProps = sizeof( PropertiesToTrace ) / sizeof(PropertiesToTrace[ 0 ]);
		for( int32 MPIdx = 0; MPIdx < NumProps; MPIdx++ )
		{
			EMaterialProperty MaterialProp = PropertiesToTrace[ MPIdx ];
			TArray<UMaterialExpression*> MPRefdExpressions;
			FStaticParameterSet* InStaticParameterSet = nullptr;
			FStaticParameterSet ParameterSet;
			if( MatInst )
			{
				ParameterSet = MatInst->GetStaticParameters();
				InStaticParameterSet = &ParameterSet;
			}
			ERHIFeatureLevel::Type InFeatureLevel = ERHIFeatureLevel::Num;
			EMaterialQualityLevel::Type InQuality = EMaterialQualityLevel::Num;
			ERHIShadingPath::Type InShadingPath = ERHIShadingPath::Num;

			bool RetrievedExpressions = false;
			if( BaseMaterial->bUseMaterialAttributes )
			{
				FExpressionInput* Input = BaseMaterial->GetExpressionInputForProperty( MP_MaterialAttributes );
				if( !Input )
					continue;
				UMaterialExpressionMakeMaterialAttributes* MaterialAttributes = Cast< UMaterialExpressionMakeMaterialAttributes>( Input->Expression );
				if( MaterialAttributes )
				{
					FExpressionInput* MAInput = GetMaterialAttributesInput( MaterialAttributes, MaterialProp );
					if( MAInput->Expression )
					{
						TArray<FExpressionInput*> ProcessedInputs;
						ProcessedInputs.Add( MAInput );
						EShaderFrequency ShaderFrequency = SF_NumFrequencies;
						UMaterial2* BaseMaterial2 = (UMaterial2*)BaseMaterial;
						RetrievedExpressions = BaseMaterial2->RecursiveGetExpressionChainPublic( MAInput->Expression, ProcessedInputs, MPRefdExpressions, InStaticParameterSet, InFeatureLevel, InQuality, InShadingPath, ShaderFrequency, MaterialProp, true );
					}
				}
			}
			else
				RetrievedExpressions = GetExpressionsInPropertyChain( BaseMaterial, MaterialProp, MPRefdExpressions, InStaticParameterSet, InFeatureLevel, InQuality, InShadingPath, true );

			if ( RetrievedExpressions )
			{
				for( int i = 0; i < MPRefdExpressions.Num(); i++ )
				{
					UMaterialExpression* Exp = MPRefdExpressions[ i ];
					UMaterialExpressionTextureBase* TexBase = Cast< UMaterialExpressionTextureBase>( Exp );
					if( TexBase )
					{
						UTextureCube* IsCubeTex = Cast< UTextureCube>( TexBase->Texture );
						UVolumeTexture* IsVolumeTex = Cast<UVolumeTexture>( TexBase->Texture );
						//Ignore Cube/3D Textures since it will error out the FBX/standard materials
						if( IsCubeTex || IsVolumeTex )
							continue;

						UMaterialExpressionTextureSampleParameter2D* SampleParam2D = Cast< UMaterialExpressionTextureSampleParameter2D>( Exp );
						int ReferencedIndex = -1;
						if( SampleParam2D )
						{
							for( int t = 0; t < UsedTextures.Num(); t++ )
							{
								if( SampleParam2D->ParameterName.ToString().Compare( Mat->TextureParamNames[ t ] ) == 0 )
								{
									ReferencedIndex = t;
								}
							}
						}
						else
						{
							for( int t = 0; t < UsedTextures.Num(); t++ )
							{
								if( TexBase->Texture == UsedTextures[ t ] )
								{
									ReferencedIndex = t;
								}
							}
						}
						if( ReferencedIndex != -1 )
						{
							TextureSemantic Semantic = MaterialPropertyToTextureSemantic( MaterialProp );
							TextureSemantics[ ReferencedIndex ].Array.Add( Semantic );
						}
					}
				}
			}
		}
	}

	EvaluateSemantics( TextureSemantics, Mat->TextureParamNames );
	
	UMaterialInstance* MaterialInstance = Cast<UMaterialInstance>( UnrealMat );

	UTexture* OutTex = nullptr;
	float OutVal = 0.0f;
	bool OutBoolVal = false;
	FGuid OutParameterId;
	FLinearColor Color;
	if( MaterialInstance )
	{
		if( MaterialInstance->GetScalarParameterValue( TEXT( "OpacityConst" ), OutVal, true ) )
		{
			Mat->UnityMat->BaseColorMultiplier.A = OutVal;
		}
		if( MaterialInstance->GetTextureParameterValue( TEXT( "OpacityMaskTexture" ), OutTex, true ))// ||
			//MaterialInstance->GetStaticSwitchParameterValue( TEXT( "UseOpacityMask" ), OutBoolVal, OutParameterId, true )
		{
			//Make it take the texture alpha, not the one from constant color
			Mat->UnityMat->BaseColorMultiplier.A = 1.0f;
			Mat->UnityMat->HasOpacityMask = 1;
		}
		if( MaterialInstance->GetScalarParameterValue( TEXT( "RoughnessConst" ), OutVal, true ) )
		{
			float OriginalRoughness = ConvertToOriginalValue( OutVal );
			Mat->UnityMat->SmoothnessMultiplier = 1.0f - OriginalRoughness;
		}
		if( MaterialInstance->GetScalarParameterValue( TEXT( "MetallicConst" ), OutVal, true ) )
		{
			Mat->UnityMat->MetallicValue = ConvertToOriginalValue( OutVal );
		}
		if( MaterialInstance->GetVectorParameterValue( TEXT( "BaseColorConst" ), Color, true ) )
		{
			Mat->UnityMat->BaseColorMultiplier.R = Color.R;
			Mat->UnityMat->BaseColorMultiplier.G = Color.G;
			Mat->UnityMat->BaseColorMultiplier.B = Color.B;
		}
		if( MaterialInstance->GetVectorParameterValue( TEXT( "EmissiveColorConst" ), Color, true ) )
		{
			Mat->UnityMat->EmissionColor = Color;
			Mat->UnityMat->EnableEmission = true;
		}
		else if( MaterialInstance->GetTextureParameterValue( TEXT( "EmissiveColorTexture" ), OutTex, true ) )
		{
			Mat->UnityMat->EmissionColor = FLinearColor( 1, 1, 1, 1 );
			Mat->UnityMat->EnableEmission = true;
		}
		if( MaterialInstance->IsTwoSided() )
		{
			Mat->UnityMat->CullMode = 0;
		}
		else
			Mat->UnityMat->CullMode = 2;
	}

	int NumCubes = 0;
	int Num2DArrays = 0;
	int Num3D = 0;
	int NumVirtual = 0;
	for( int i = 0; i < UsedTextures.Num(); i++ )
	{
		UTexture* Tex = UsedTextures[ i ];

		if( Tex )
		{
			bool IsNormalMap = false;
			if( MaterialInstance )
			{
				IsNormalMap = IsTextureNormalMap( MaterialInstance, Tex );
			}
			else
				IsNormalMap = IsTextureNormalMap( BaseMaterial, Tex );

			AllUsedTextures.Remove( Tex );
			int CurrentCount = InitialTotalTextures - AllUsedTextures.Num();
			//UE_LOG( LogTemp, Log, TEXT( "Exporting Texture %s (%d/%d)" ), *Tex->GetName(), CurrentCount, InitialTotalTextures );
			TextureBinding* Binding = UETextureExporter::Export( Tex );

			Binding->IsNormalMap = IsNormalMap;
			if( !Binding->UnityTex )
			{
				Binding->UnityTex = new UnityTexture;
				FString TexturePath = GenerateTexturePath( Tex );
				FString ResourcePath = GenerateTexturePath( Tex, true );
				Binding->UnityTex->File = ToANSIString( *TexturePath );
				Binding->UnityTex->ResourcePath = ToANSIString( *ResourcePath );
				Binding->UnityTex->GenerateGUID();
				UTextureCube* IsCube = Cast<UTextureCube>( Tex );
				if( IsCube )
				{
					Binding->UnityTex->Shape = UTS_Cube;
					Binding->UnityTex->SpecificIndex = NumCubes;
					NumCubes++;
				}
				#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION > 20) || ENGINE_MAJOR_VERSION == 5
				UTexture2DArray* Tex2DArray = Cast< UTexture2DArray>( Tex );
				if( Tex2DArray )
				{
					Binding->UnityTex->Shape = UTS_2DArray;
					Binding->UnityTex->SpecificIndex = Num2DArrays;
					Num2DArrays++;
				}
				#endif
				UVolumeTexture* IsVolume = Cast<UVolumeTexture>( Tex );
				if( IsVolume )
				{
					Binding->UnityTex->Shape = UTS_3D;
					Binding->UnityTex->SpecificIndex = Num3D;
					Num3D++;
				}
				#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION > 20) || ENGINE_MAJOR_VERSION == 5
				if( Tex->VirtualTextureStreaming == 1 && GetDefault<URendererSettings>()->bVirtualTextures )
				{
					Binding->UnityTex->IsVirtual = true;
					Binding->UnityTex->SpecificIndex = NumVirtual;
					NumVirtual++;
				}
				#endif
				Binding->UnityTex->Semantic = TextureSemantics[ i ].Selection;
			}
			Mat->UnityMat->Textures.push_back( Binding->UnityTex );
		}
		else
			Mat->UnityMat->Textures.push_back( nullptr );
	}	
}

void FDebugViewModeMaterialProxy_AddShader( UMaterialInterface* InMaterialInterface, EMaterialQualityLevel::Type QualityLevel, ERHIFeatureLevel::Type FeatureLevel, bool bSynchronousCompilation, EMaterialShaderMapUsage::Type InUsage )
{
	if( !InMaterialInterface ) return;

	const FMaterial* Material = InMaterialInterface->GetMaterialResource( FeatureLevel );
	if( !Material ) 
		return;
}
UMaterialInstanceDynamic* ShaderErrorMID = nullptr;
UMaterialInterface* MaterialParentForShaderError = nullptr;
UTexture2D* ShaderErrorTexture2D = nullptr;
FMaterialRenderProxy* GetRenderProxy( UMaterialInterface* Material)
{
	#if ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION < 26
		return Material->GetRenderProxy( false );
	#else
		return Material->GetRenderProxy();
	#endif
}
void GetMaterialShaderSource( MaterialBinding *Mat, bool IsOnGamethread )
{
	UMaterialInterface *M = Mat->MaterialInterface;
	bool WantsGameThread = false;
	UMaterialInstance *MatInstance = dynamic_cast<UMaterialInstance*>( M );
	if( MatInstance )
	{
		if( !MatInstance->Parent )
		{
			UObject* LoadedObject = StaticLoadObject( UMaterialInterface::StaticClass(), nullptr, TEXT( "/Engine/EngineMaterials/DefaultMaterial" ) );
			UMaterialInterface* DefaultMaterial = Cast<UMaterialInterface>( LoadedObject );
			if ( DefaultMaterial )
				MatInstance->Parent = DefaultMaterial;
		}
		WantsGameThread = true;
	}

	bool ExtractShaderSource = (WantsGameThread == IsOnGamethread);
	#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >= 2
		ExtractShaderSource = IsOnGamethread;
	#endif
	if( ExtractShaderSource )
	{
		Mat->MaterialResource = M->GetMaterialResource( GlobalFeatureLevel );
		if( !Mat->MaterialResource )
		{
			UE_LOG( LogTemp, Error, TEXT( "[UTU] Warning! Material %s has Parent=null is probably ?" ), *M->GetName() );
			return;
		}

		Mat->RenderProxy = GetRenderProxy( M );
		Mat->MaterialResource->GetMaterialExpressionSource( Mat->ShaderSource );

		//Set our special material if shader couldn't compile so we know which Material/MI is at fault in Unreal
		if( Mat->ShaderSource.Len() == 0 )
		{
			//Create a new one so if there's multiple uncompilable materials, don't overwrite them !
			auto NewMID = UMaterialInstanceDynamic::Create( MaterialParentForShaderError, nullptr );
			NewMID->SetTextureParameterValue( TEXT( "Texture" ), ShaderErrorTexture2D );
			NewMID->AddToRoot();
			FString NewName = FString::Printf( TEXT( "%s_Didnt_Compile" ), *M->GetName() );
			NewMID->Rename( *NewName );

			Mat->MaterialInterface = NewMID;

			Mat->MaterialResource = Mat->MaterialInterface->GetMaterialResource( GlobalFeatureLevel );
			Mat->RenderProxy = GetRenderProxy( Mat->MaterialInterface );
			Mat->MaterialResource->GetMaterialExpressionSource( Mat->ShaderSource );

			TArray<UTexture*> UsedTextures;
			GetMaterialTextures( Mat->MaterialInterface, UsedTextures, Mat->TextureParamNames );
			for( int i = 0; i < UsedTextures.Num(); i++ )
			{
				auto Binding = UETextureExporter::Export( UsedTextures[ i ] );
				if( !Binding->UnityTex )
				{
					UnityTexture* UnityTex = new UnityTexture;
					FString TexturePath = GenerateTexturePath( UsedTextures[ i ] );
					UnityTex->File = ToANSIString( *TexturePath );
					UnityTex->GenerateGUID();
					Binding->UnityTex = UnityTex;
				}
				Mat->UnityMat->Textures.push_back( Binding->UnityTex );
			}			
		}

		auto ReferencedTextures = Mat->MaterialResource->GetReferencedTextures();
	}
}

std::string GetLine( std::string String, int position )
{
	int LineStart = String.rfind( '\n', position );
	int LineEnd = String.find( '\n', position );
	if( LineStart == LineEnd )
		return "";
	if( LineStart != -1 && LineEnd != -1 )
	{
		return String.substr( LineStart + 1, LineEnd - LineStart - 1 );
	}
	else
		return "";
}

int GetNumTexcoords( std::string UnrealHLSL )
{
	int pos = UnrealHLSL.find( "#define NUM_TEX_COORD_INTERPOLATORS" );
	if( pos != -1 )
	{
		std::string Line = GetLine( UnrealHLSL, pos );
		if( Line.length() > 0 )
		{
			int NumTexcoords = 0;
			if( sscanf( Line.c_str(), "#define NUM_TEX_COORD_INTERPOLATORS %d", &NumTexcoords ) == 1 )
			{
				return NumTexcoords;
			}
		}
	}

	return 0;
}
int GetNumTexcoordsVertex( std::string UnrealHLSL )
{
	int pos = UnrealHLSL.find( "#define NUM_MATERIAL_TEXCOORDS_VERTEX" );
	if( pos != -1 )
	{
		std::string Line = GetLine( UnrealHLSL, pos );
		if( Line.length() > 0 )
		{
			int NumTexcoords = 0;
			if( sscanf( Line.c_str(), "#define NUM_MATERIAL_TEXCOORDS_VERTEX %d", &NumTexcoords ) == 1 )
			{
				return NumTexcoords;
			}
		}
	}

	return 0;
}

int GetEndBraceOffset( std::string AllCode, int StartPos )
{
	int ExpStart = AllCode.rfind( '\n', StartPos );
	int FirstBrace = AllCode.find( '{', ExpStart );

	int Depth = 0;
	const char* str = AllCode.c_str();
	for( int i = FirstBrace + 1; i < AllCode.length(); i++ )
	{
		if( AllCode[ i ] == '{' )
		{
			Depth++;
		}
		if( AllCode[ i ] == '}' )
		{
			Depth--;
		}
		if( Depth < 0 )
		{			
			return i;
		}
	}

	UE_LOG( LogTemp, Error, TEXT( "[UTU] ERROR! GetEndBraceOffset didn't found the end of the function, wtf ?" ) );

	return ExpStart;
}
//Convert HLSL Samples to CG
void ReplaceHLSLSampleCall( std::string & Exp, const char* strToFind, const char* ReplacementFunc )
{
	int FindLen = strlen( strToFind );

	int pos = -1;
	do
	{
		pos = Exp.find( strToFind );
		if( pos != -1 )
		{
			std::string TexName;
			int TexBegin = -1;
			for( int i = pos - 1; i > 0; i-- )
			{
				char c = Exp[ i ];
				if( c == ' ' || c == '\t' || c == '\n' || c == ',' || c == '(' || c == ')' || c == '{' || c == '}' )
				{
					TexName = Exp.substr( i + 1, pos - i - 1 );
					TexBegin = i + 1;
					break;
				}
			}
			if( TexBegin == -1 )
			{
				UE_LOG( LogTemp, Error, TEXT( "[UTU] ERROR! ProcessCustomExpression couldn't detect TexBegin !" ) );
				return;
			}

			std::string Replacement = ReplacementFunc;
			Replacement += TexName;
			Replacement += ", ";
			Exp.replace( TexBegin, TexName.length() + FindLen, Replacement.c_str() );
		}
	} while( pos != -1 );
}
void ProcessCustomExpression( std::string& Exp, bool IsVS )
{
	ReplaceHLSLSampleCall( Exp, ".SampleGrad(", "Texture2DSampleGrad( ");
	ReplaceHLSLSampleCall( Exp, ".Sample(", "Texture2DSample( ");
	ReplaceHLSLSampleCall( Exp, ".SampleLevel(", "Texture2DSampleLevel( ");
	ReplaceHLSLSampleCall( Exp, ".SampleBias(", "Texture2DSampleBias( " );

	if( IsVS )
		StringReplacement( Exp, "Texture2DSample(", "Texture2DSampleForVS(" );

	StringReplacement( Exp, "Material.", "Material_" );
	StringReplacement( Exp, "const", " " );

	StringReplacement( Exp, "View.BufferSizeAndInvSize", "View_BufferSizeAndInvSize" );
	StringReplacement( Exp, "View.MaterialTextureBilinearWrapedSampler",  "View_MaterialTextureBilinearWrapedSampler" );
	StringReplacement( Exp, "View.MaterialTextureBilinearClampedSampler", "View_MaterialTextureBilinearClampedSampler" );
	StringReplacement( Exp, "View.SharedBilinearClampedSampler",		  "View_MaterialTextureBilinearClampedSampler" );

	StringReplacement( Exp, "while", "LOOP\nwhile" );
}
bool ReplaceVertexParametersWithPixelParameters( std::string& Code )
{
	const char* FindStr = "FMaterialVertexParameters";
	const char* ReplaceStr = "FMaterialPixelParameters";
	int ParamPos = Code.find( FindStr );
	if( ParamPos != -1 )
	{
		Code.replace( ParamPos, strlen( FindStr ), ReplaceStr );
		return true;
	}
	else
		return false;
}
void AddCustomExpressions( std::string & MaterialCode, std::string AllCode, bool IsVS = false )
{
	int Index = 0;
	char Text[ 64 ];
	size_t pos = 0;
	do
	{
		snprintf( Text, sizeof( Text ), "CustomExpression%d", Index );
		pos = AllCode.find( Text );
		if ( pos != -1 )
		{
			int ExpStart = AllCode.rfind( '\n', pos );
			int EndBrace = GetEndBraceOffset( AllCode, pos );

			std::string ExpFunction = AllCode.substr( ExpStart, EndBrace + 1 - ExpStart );

			//ReplaceVertexParametersWithPixelParameters( ExpFunction );
			ProcessCustomExpression( ExpFunction, IsVS );

			std::string MaterialCodeWithExpressions = ExpFunction;
			MaterialCodeWithExpressions += '\n';
			MaterialCodeWithExpressions += MaterialCode;
			MaterialCode = MaterialCodeWithExpressions;
		}
		Index++;
	}
	while ( pos != -1 );
}
void ExecuteStringReplacements( std::string& ShaderCode )
{
	StringReplacement( ShaderCode, "Material.Texture", "Material_Texture" );
	StringReplacement( ShaderCode, "Material.VolumeTexture", "Material_VolumeTexture" );
	StringReplacement( ShaderCode, "Material.VirtualTexturePhysical", "Material_VirtualTexturePhysical" );
	StringReplacement( ShaderCode, "Material.Wrap_WorldGroupSettings", "Material_Wrap_WorldGroupSettings" );
	StringReplacement( ShaderCode, "Material.Clamp_WorldGroupSettings", "Material_Clamp_WorldGroupSettings" );
	
	StringReplacement( ShaderCode, "Material_VectorExpressions", "Material.VectorExpressions" );
	StringReplacement( ShaderCode, "Material_ScalarExpressions", "Material.ScalarExpressions" );

	StringReplacement( ShaderCode, "VIRTUALTEXTURE_PAGETABLE_", "/*VIRTUALTEXTURE_PAGETABLE_*/" );
	
	if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_URP ||
		CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
	{
		StringReplacement( ShaderCode, "View.MaterialTextureBilinearWrapedSampler",  "View_MaterialTextureBilinearWrapedSampler" );
		StringReplacement( ShaderCode, "View.MaterialTextureBilinearClampedSampler", "View_MaterialTextureBilinearClampedSampler" );
		StringReplacement( ShaderCode, "View.SharedBilinearClampedSampler",			 "View_MaterialTextureBilinearClampedSampler" );
	}
}
std::string GetMaterialCollectionString( const UMaterialParameterCollection* Collection, int CollectionIndex)
{
	int NumVectorsForScalars = ( Collection->ScalarParameters.Num() + 3 ) / 4;
	int TotalVectors = NumVectorsForScalars + Collection->VectorParameters.Num();

	FLinearColor* ScalarVectors = new FLinearColor[ NumVectorsForScalars ];
	std::string ValuesStr;
	std::string* ParamNames = new std::string[ NumVectorsForScalars * 4 ];
	for( int i = 0; i < Collection->ScalarParameters.Num(); i++ )
	{
		FCollectionScalarParameter Param = Collection->ScalarParameters[ i ];
		float* FloatArray = (float*)ScalarVectors;
		FloatArray[ i ] = Param.DefaultValue;
		ParamNames[ i ] = ToANSIString( *Param.ParameterName.ToString());
	}
	for( int i = 0; i < NumVectorsForScalars; i++ )
	{
		char Line[ 1024 ] = "";
		ScalarVectors[ i ] = RemoveNans( ScalarVectors[ i ] );
		snprintf( Line, sizeof( Line ), "\tMaterialCollection%d.Vectors[%d] = float4(%f,%f,%f,%f);//%s,%s,%s,%s\n", CollectionIndex, i, ScalarVectors[i].R, ScalarVectors[ i ].G, ScalarVectors[ i ].B, ScalarVectors[ i ].A,
				   ParamNames[ i * 4 + 0].c_str(), ParamNames[ i * 4 + 1 ].c_str(), ParamNames[ i * 4 + 2 ].c_str(), ParamNames[ i * 4 + 3 ].c_str() );
		ValuesStr += Line;
	}
	for( int i = 0; i < Collection->VectorParameters.Num(); i++ )
	{
		FCollectionVectorParameter Param = Collection->VectorParameters[ i ];
		FLinearColor V = Param.DefaultValue;
		char Line[ 1024 ] = "";
		std::string str = ToANSIString( *Param.ParameterName.ToString() );
		snprintf( Line, sizeof( Line ), "\tMaterialCollection%d.Vectors[%d] = float4(%f,%f,%f,%f);//%s\n", CollectionIndex, NumVectorsForScalars + i, V.R, V.G, V.B, V.A, str.c_str() );
		ValuesStr += Line;
	}

	FString CollectionName = Collection->GetName();
	auto CollectionNameStr = ToANSIString( *CollectionName );
	char Text[ 1024 ] = "";
	snprintf( Text, sizeof( Text ), "struct MaterialCollection%dType\n"
		"{\n"
		"\tfloat4 Vectors[%d];\n"
		"};\n"
		"//%s\n"
		"MaterialCollection%dType MaterialCollection%d;\n"
		"void Initialize_MaterialCollection%d()\n"
		"{\n", CollectionIndex, TotalVectors, CollectionNameStr.c_str(), CollectionIndex, CollectionIndex, CollectionIndex);
	std::string Ret = Text;
	Ret += ValuesStr;

	Ret += "}\n";

	delete[] ScalarVectors;
	delete[] ParamNames;
	return Ret;
}
void UncommentLine( std::string & ShaderString, const char *Marker )
{
	while( 1 )
	{
		size_t Pos = ShaderString.find( Marker );
		if( Pos != ShaderString.npos )
			ShaderString.replace( Pos, strlen( Marker ), "" );//uncomment it
		else
			break;
	}
}
void RemoveComment( std::string& ShaderString, const char* Marker )
{
	while( 1 )
	{
		size_t Pos = ShaderString.find( Marker );
		if( Pos != ShaderString.npos )
			ShaderString.replace( Pos, 2, "" );//remove just "//"
		else
			break;
	}
}
int CommentLine( std::string& ShaderString, const char* Marker )
{
	int Offset = 0;
	int ReturnPos = -1;
	while( 1 )
	{
		size_t Pos = ShaderString.find( Marker, Offset );
		if( Pos != ShaderString.npos )
		{
			ShaderString.insert( Pos, "//" );//add comment
			ReturnPos = Pos;
			Offset = Pos + 3;
		}
		else
			break;
	}

	return ReturnPos;
}
std::vector<std::string> GetLines( std::string String, int position, int NumLines )
{
	std::vector<std::string> Lines;

	int FirstLineStart = String.rfind( '\n', position );
	int Cursor = FirstLineStart + 1;
	for( int i = 0; i < NumLines; i++ )
	{
		std::string Line = GetLine( String, Cursor );
		Cursor += Line.length() + 2;
		Lines.push_back( Line );
	}

	return Lines;
}
void FindAndAddInterpolator( const char* Identifier, std::string HLSL, std::string& GeneratedShader, int InterpStart, int& NextLineMarker )
{
	int DefineCursor = HLSL.find( Identifier, InterpStart );
	if( DefineCursor != -1 )
	{
		std::string Line = GetLine( HLSL, DefineCursor );
		Line += "\n";
		GeneratedShader.insert( NextLineMarker, Line );
		NextLineMarker += Line.length();
	}
}
void ProcessVertexInterpolators( std::string HLSL, std::string & GeneratedShader )
{
	int NumInterpolators = -1;
	int InterpStart = HLSL.find( "NUM_CUSTOM_VERTEX_INTERPOLATORS" );
	if( InterpStart > 0 )
	{
		std::string Line = GetLine( HLSL, InterpStart );
		if( Line.length() > 0 )
		{			
			sscanf( Line.c_str(), "#define NUM_CUSTOM_VERTEX_INTERPOLATORS %d", &NumInterpolators);
		}
	}

	if( NumInterpolators > 0 )
	{
		const char* NUM_CUSTOM_VERTEX_INTERPOLATORS = "NUM_CUSTOM_VERTEX_INTERPOLATORS";
		int NumInterpolatorsCursor = GeneratedShader.find( NUM_CUSTOM_VERTEX_INTERPOLATORS );
		if( NumInterpolatorsCursor == -1 )
			return;

		char Text[ 256 ];
		snprintf( Text, sizeof( Text ), "%d", NumInterpolators );
		GeneratedShader.replace( NumInterpolatorsCursor + strlen( NUM_CUSTOM_VERTEX_INTERPOLATORS ) + 1, strlen( Text ), Text );
		int NextLineMarker = GeneratedShader.find( '\n', NumInterpolatorsCursor );
		NextLineMarker++;

		for( int i = 0; i < NumInterpolators; i++ )
		{
			snprintf( Text, sizeof( Text ), "#define VERTEX_INTERPOLATOR_%d_TEXCOORDS_X", i );
			FindAndAddInterpolator( Text, HLSL, GeneratedShader, InterpStart, NextLineMarker );
			snprintf( Text, sizeof( Text ), "#define VERTEX_INTERPOLATOR_%d_TEXCOORDS_Y", i );
			FindAndAddInterpolator( Text, HLSL, GeneratedShader, InterpStart, NextLineMarker );
			snprintf( Text, sizeof( Text ), "#define VERTEX_INTERPOLATOR_%d_TEXCOORDS_Z", i );
			FindAndAddInterpolator( Text, HLSL, GeneratedShader, InterpStart, NextLineMarker );
			snprintf( Text, sizeof( Text ), "#define VERTEX_INTERPOLATOR_%d_TEXCOORDS_W", i );
			FindAndAddInterpolator( Text, HLSL, GeneratedShader, InterpStart, NextLineMarker );
		}		
	}
}
void ReplaceShaderName( std::string & GeneratedShader, const char * InsertMarker, std::string MatNameStr )
{
	int Pos = GeneratedShader.find( InsertMarker );
	GeneratedShader.replace( Pos, strlen( InsertMarker ), MatNameStr.c_str() );
}
TArray<UMaterialExpression*> GetExpressions( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >= 1
	TArray<UMaterialExpression*> Expressions;
	if( !Material )
		return Expressions;
	TConstArrayView<TObjectPtr<UMaterialExpression>> ConstExpressions = Material->GetExpressions();
	Expressions.Reserve( ConstExpressions.Num() );
	for( int i = 0; i < ConstExpressions.Num(); i++ )
	{
		Expressions.Add( ConstExpressions[ i ] );
	}
	return Expressions;
#else
	return Material->Expressions;
#endif
}
const TArray<UMaterialExpression*> GetFunctionExpressions( UMaterialFunctionInterface* MaterialFunction)
{
	#if ENGINE_MAJOR_VERSION >= 5
		TArray<UMaterialExpression*> Ret;

		#if ENGINE_MINOR_VERSION >= 1
			TConstArrayView<TObjectPtr<UMaterialExpression>> FunctionExpressions = MaterialFunction->GetExpressions();

			for( int i = 0; i < FunctionExpressions.Num(); i++ )
			{
				Ret.Add( FunctionExpressions[ i ] );
			}
		#else
			const TArray<TObjectPtr<UMaterialExpression>>* FunctionExpressions = MaterialFunction->GetFunctionExpressions();
		
			for( int i = 0; i < FunctionExpressions->Num(); i++ )
			{
				Ret.Add( ( *FunctionExpressions )[ i ] );
			}
		#endif
		return Ret;
	#else
		return *MaterialFunction->GetFunctionExpressions();
	#endif
}

void GatherExpressionsFromMaterialLayers( UMaterialInstance* MaterialInstance, TArray<UMaterialExpression*>& OutExpressions )
{
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 0
	FMaterialLayersFunctions OutLayers;
	MaterialInstance->GetMaterialLayers( OutLayers );
	for( int i = 0; i < OutLayers.Layers.Num(); i++ )
	{
		UMaterialFunctionInterface* MaterialFunctionInterface = OutLayers.Layers[ i ];
		if( MaterialFunctionInterface )
		{
			TArray<UMaterialExpression*> FunctionExpressions = GetFunctionExpressions( MaterialFunctionInterface );

			for( int u = 0; u < FunctionExpressions.Num(); u++ )
			{
				auto Exp = FunctionExpressions[ u ];
				OutExpressions.Add( Exp );
			}
		}
	}
	for( int i = 0; i < OutLayers.Blends.Num(); i++ )
	{
		UMaterialFunctionInterface* MaterialFunctionInterface = OutLayers.Blends[ i ];
		if( MaterialFunctionInterface )
		{
			TArray<UMaterialExpression*> FunctionExpressions = GetFunctionExpressions( MaterialFunctionInterface );

			for( int u = 0; u < FunctionExpressions.Num(); u++ )
			{
				auto Exp = FunctionExpressions[ u ];
				OutExpressions.Add( Exp );
			}
		}
	}
#endif
}
TArray<UMaterialExpression*> GetMaterialExpressionsIncludingFunctions( UMaterialInterface* Mat )
{
	TArray<UMaterialExpression*> OutExpressions = GetExpressions( Mat->GetBaseMaterial() );
	for( int i = 0; i < OutExpressions.Num(); i++ )
	{
		UMaterialExpression* Exp = OutExpressions[ i ];

		UMaterialExpressionMaterialFunctionCall* ExpMFC = dynamic_cast<UMaterialExpressionMaterialFunctionCall*>( Exp );
		if( ExpMFC && ExpMFC->MaterialFunction )
		{
			TArray<UMaterialExpression*> FunctionExpressions = GetFunctionExpressions( ExpMFC->MaterialFunction );

			for( int u = 0; u < FunctionExpressions.Num(); u++ )
			{
				Exp = FunctionExpressions[ u ];
				OutExpressions.Add( Exp );
			}
			continue;
		}
	}
	UMaterialInstance* MaterialInstance = Cast<UMaterialInstance>( Mat );
	if( MaterialInstance )
	{
		GatherExpressionsFromMaterialLayers( MaterialInstance, OutExpressions );
	}

	return OutExpressions;
}
bool ExportVS = true;
std::string ExtractFunction( const char* CSource, const char *Marker )
{
	const char* ptr = strstr( CSource, Marker );
	if( ptr )
	{
		int CropStart = (int64_t)ptr - (int64_t)CSource;
		int EndBrace = GetEndBraceOffset( CSource, CropStart );
		int CropEnd = EndBrace;

		int CropSize = CropEnd - CropStart + 1;
		if( CropSize < 0 )
		{
			return "";
		}
		char* StringContents = new char[ CropSize ];
		StringContents[ CropSize ] = 0;
		memcpy( StringContents, ptr, CropSize );
		std::string RetStr = StringContents;
		RetStr += "\n";

		return RetStr;
	}
	else
		return "";
}
const char* PixelToVertexParameters =
"\n"
"	FMaterialVertexParameters Parameters = (FMaterialVertexParameters)0;\n"
"	Parameters.TangentToWorld = PixelParameters.TangentToWorld;\n"
"	Parameters.WorldPosition = PixelParameters.AbsoluteWorldPosition;\n"
"	Parameters.VertexColor = PixelParameters.VertexColor;\n"
"#if NUM_MATERIAL_TEXCOORDS_VERTEX > 0\n"
"	int m = min( NUM_MATERIAL_TEXCOORDS_VERTEX, NUM_TEX_COORD_INTERPOLATORS );\n"
"	for( int i = 0; i < m; i++ )\n"
"	{\n"
"		Parameters.TexCoords[i] = PixelParameters.TexCoords[i];\n"
"	}\n"
"#endif\n"
"	Parameters.PrimitiveId = PixelParameters.PrimitiveId;\n";
void SetupCustomizedUVs( std::string& CustomizedUVs )
{
	if( CustomizedUVs.length() == 0 )
		return;

	CustomizedUVs = std::string("\n") + CustomizedUVs;

	const char* Marker = "FMaterialVertexParameters Parameters";
	int MarkerPos = CustomizedUVs.find( Marker );
	
	const char* PixelParameters = "FMaterialPixelParameters PixelParameters";
	CustomizedUVs.replace( MarkerPos, strlen( Marker ), PixelParameters );
	
	int FirstBraceStart = CustomizedUVs.find( "{" );
	CustomizedUVs.insert( FirstBraceStart + 1, PixelToVertexParameters );

	ExecuteStringReplacements( CustomizedUVs );
}
void SetupTexcoordInterpolators( std::string& ShaderSourceANSI, std::string& GeneratedShader )
{
	int NumTexcoords = GetNumTexcoords( ShaderSourceANSI );
	const char* NumTexcoordsMarker = "NUM_TEX_COORD_INTERPOLATORS";
	char NumTexcoordsStr[ 16 ];
	snprintf( NumTexcoordsStr, sizeof( NumTexcoordsStr ), "%d", NumTexcoords );
	int Pos = GeneratedShader.find( NumTexcoordsMarker );
	if( Pos != -1 )
		GeneratedShader.replace( Pos + strlen( NumTexcoordsMarker ) + 1, strlen( NumTexcoordsStr ), NumTexcoordsStr );
}
void SetupVertexTexcoordInterpolators( std::string& ShaderSourceANSI, std::string& GeneratedShader )
{
	int NumTexcoords = GetNumTexcoordsVertex( ShaderSourceANSI );
	const char* NumTexcoordsMarker = "NUM_MATERIAL_TEXCOORDS_VERTEX";
	char NumTexcoordsStr[ 16 ];
	snprintf( NumTexcoordsStr, sizeof( NumTexcoordsStr ), "%d", NumTexcoords );
	int Pos = GeneratedShader.find( NumTexcoordsMarker );
	if ( Pos != -1 )
		GeneratedShader.replace( Pos + strlen( NumTexcoordsMarker ) + 1, strlen( NumTexcoordsStr ), NumTexcoordsStr );	
}
void AddExpressionsFromMaterialFunctions( TArray<UMaterialExpression*>& OutExpressions )
{
	for( int i = 0; i < OutExpressions.Num(); i++ )
	{
		UMaterialExpression* Exp = OutExpressions[ i ];

		UMaterialExpressionMaterialFunctionCall* ExpMFC = dynamic_cast<UMaterialExpressionMaterialFunctionCall*>( Exp );
		if( ExpMFC && ExpMFC->MaterialFunction )
		{
			TArray<UMaterialExpression*> FunctionExpressions = GetFunctionExpressions( ExpMFC->MaterialFunction );

			int Added = 0;
			for( int u = 0; u < FunctionExpressions.Num(); u++ )
			{
				Exp = FunctionExpressions[ u ];
				//Add them in order exactly where FunctionCall was
				//Avoid adding function calls recursively
				if( OutExpressions.Find( Exp ) == INDEX_NONE )
				{
					OutExpressions.Insert( Exp, i + Added );
					Added++;
				}
			}
			continue;
		}
	}
}
void GetMaterialCollectionIndices( UMaterialInterface* UnrealMat, TArray< UMaterialParameterCollection* >& Collections )
{	
	EMaterialProperty Properties[] =
	{
		MP_Normal,
		MP_EmissiveColor,
		MP_DiffuseColor,
		MP_SpecularColor,
		MP_BaseColor,
		MP_Metallic,
		MP_Specular,
		MP_Roughness,
		#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 26) || ENGINE_MAJOR_VERSION == 5
		MP_Anisotropy,
		#endif
		MP_Opacity,
		MP_OpacityMask,
		#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 26) || ENGINE_MAJOR_VERSION == 5
		MP_Tangent,
		#endif
		MP_WorldPositionOffset,
		#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 26) || ENGINE_MAJOR_VERSION == 5
		MP_ShadingModel,
		#endif
		#if ENGINE_MAJOR_VERSION >= 5
			MP_FrontMaterial,
		#endif
		MP_SubsurfaceColor,
		MP_CustomData0,
		MP_CustomData1,
		MP_AmbientOcclusion,
		MP_Refraction,

		MP_PixelDepthOffset
	};

	auto BaseMaterial = UnrealMat->GetBaseMaterial();
	UMaterialInstance* MatInst = Cast<UMaterialInstance>( UnrealMat );

	int ArraySize = sizeof( Properties ) / sizeof( Properties[ 0 ] );
	for( int32 MPIdx = 0; MPIdx < ArraySize; MPIdx++ )
	{
		EMaterialProperty MaterialProp = Properties[ MPIdx ];
		TArray<UMaterialExpression*> MPRefdExpressions;
		FStaticParameterSet* InStaticParameterSet = nullptr;
		FStaticParameterSet ParameterSet;
		ERHIFeatureLevel::Type InFeatureLevel = ERHIFeatureLevel::Num;
		EMaterialQualityLevel::Type InQuality = EMaterialQualityLevel::Num;
		ERHIShadingPath::Type InShadingPath = ERHIShadingPath::Num;

		if( MatInst )
		{
			ParameterSet = MatInst->GetStaticParameters();
			InStaticParameterSet = &ParameterSet;
		}
		#if ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION < 26
		if( BaseMaterial->GetExpressionsInPropertyChain( MaterialProp, MPRefdExpressions, InStaticParameterSet, InFeatureLevel, InQuality ) == true )
		#else
		if( BaseMaterial->GetExpressionsInPropertyChain( MaterialProp, MPRefdExpressions, InStaticParameterSet, InFeatureLevel, InQuality, InShadingPath ) == true )
		#endif
		{
			AddExpressionsFromMaterialFunctions( MPRefdExpressions );
			for( int i = 0; i < MPRefdExpressions.Num(); i++ )
			{
				UMaterialExpression* Exp = MPRefdExpressions[ i ];
				UMaterialExpressionCollectionParameter* ExpCollectionParameter = Cast<UMaterialExpressionCollectionParameter>( Exp );

				if( ExpCollectionParameter )
				{
					if( Collections.Find( ExpCollectionParameter->Collection ) == INDEX_NONE )
					{
						Collections.Add( ExpCollectionParameter->Collection );
					}
				}
			}
		}
	}	
}
const char* TangentToWorldAxisFlip =
	"\n"
	"\t//WorldAligned texturing & others use normals & stuff that think Z is up\n"
	"\tParameters.TangentToWorld[0] = Parameters.TangentToWorld[0].xzy;\n"
	"\tParameters.TangentToWorld[1] = Parameters.TangentToWorld[1].xzy;\n"
	"\tParameters.TangentToWorld[2] = Parameters.TangentToWorld[2].xzy;\n";

FExpressionInput* GetMaterialAttributes( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->MaterialAttributes;
#else
	return &Material->OpacityMask;
#endif
}
FScalarMaterialInput* GetOpacity( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->Opacity;
#else
	return &Material->Opacity;
#endif
}
FScalarMaterialInput* GetOpacityMask( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->OpacityMask;
#else
	return &Material->OpacityMask;
#endif
}
FColorMaterialInput* GetBaseColor( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->BaseColor;
#else
	return &Material->BaseColor;
#endif
}
FColorMaterialInput* GetEmissiveColor( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->EmissiveColor;
#else
	return &Material->EmissiveColor;
#endif
}
FExpressionInput* GetNormal( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->Normal;
#else
	return &Material->Normal;
#endif
}
FExpressionInput* GetMetallic( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->Metallic;
#else
	return &Material->Metallic;
#endif
}
FExpressionInput* GetRoughness( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->Roughness;
#else
	return &Material->Roughness;
#endif
}
FExpressionInput* GetSpecular( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->Specular;
#else
	return &Material->Specular;
#endif
}
FExpressionInput* GetAnisotropy( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->Anisotropy;
#elif (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION > 20) || ENGINE_MAJOR_VERSION == 5
	return &Material->Anisotropy;
#else
	return nullptr;
#endif
}
FExpressionInput* GetTangent( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->Tangent;
#elif (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION > 20) || ENGINE_MAJOR_VERSION == 5
	return &Material->Tangent;
#else
	return nullptr;
#endif
}
FExpressionInput* GetWorldPositionOffset( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->WorldPositionOffset;
#else
	return &Material->WorldPositionOffset;
#endif
}
FExpressionInput* GetSubsurfaceColor( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->SubsurfaceColor;
#else
	return &Material->SubsurfaceColor;
#endif
}
FExpressionInput* GetClearCoat( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->ClearCoat;
#else
	return &Material->ClearCoat;
#endif
}
FExpressionInput* GetClearCoatRoughness( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->ClearCoatRoughness;
#else
	return &Material->ClearCoatRoughness;
#endif
}
FExpressionInput* GetAmbientOcclusion( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->AmbientOcclusion;
#else
	return &Material->AmbientOcclusion;
#endif
}
FExpressionInput* GetRefraction( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->Refraction;
#else
	return &Material->Refraction;
#endif
}
FExpressionInput* GetPixelDepthOffset( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->PixelDepthOffset;
#else
	return &Material->PixelDepthOffset;
#endif
}
FExpressionInput* GetShadingModelFromMaterialExpression( UMaterial* Material )
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->ShadingModelFromMaterialExpression;
#else
	#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 26) || ENGINE_MAJOR_VERSION == 5
		return &Material->ShadingModelFromMaterialExpression;
	#else
		return nullptr;
	#endif
#endif
}
FExpressionInput* GetCustomizedUVs( UMaterial* Material, int i)
{
#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >=1
	return &Material->GetEditorOnlyData()->CustomizedUVs[i];
#else
	return &Material->CustomizedUVs[i];
#endif
}
bool FixStrataStuff( std::string& GeneratedShader )
{
	//Strata Stuff
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 1
#else
	return false;
#endif

	int StrataTypePos = GeneratedShader.find( "FStrataData " );
	if( StrataTypePos == -1 )
		return false;
	
	std::string Line = GetLine( GeneratedShader, StrataTypePos );
	char StrataVarName[ 256 ] = "";
	if( sscanf( Line.c_str(), "\tFStrataData %s =", StrataVarName ) != 1 )
		return false;

	CommentLine( GeneratedShader, "PixelMaterialInputs.FrontMaterial =" );
	//int NextLinePos = GeneratedShader.find( "\n", FrontMaterialPos );
	char StrataToMaterialInputs[ 256 ] = "";
	sprintf( StrataToMaterialInputs, "\n\tStrataToMaterialInputs( PixelMaterialInputs, %s );\n", StrataVarName );

	int MaterialEndPos = GeneratedShader.find( "//PixelMaterialInputs.FrontMaterial =" );
	if( MaterialEndPos == -1 )
		return false;

	GeneratedShader.insert( MaterialEndPos, StrataToMaterialInputs );

	return true;
}
void SetupShadingModel( std::string& GraphShader, EMaterialShadingModel ShadingModel )
{
	if( ShadingModel == MSM_Unlit )
	{
		if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_URP )
		{
			StringReplacement( GraphShader, "#define SHADERPASS SHADERPASS_FORWARD", "#define SHADERPASS SHADERPASS_UNLIT" );
			StringReplacement( GraphShader, "PBRForwardPass.hlsl", "UnlitPass.hlsl" );
			StringReplacement( GraphShader, "UniversalMaterialType\" = \"Lit", "UniversalMaterialType\" = \"Unlit" );
			//In Shadergraph/unlit mode basecolor is the only output, and in UE in unlit only emissive is written
			StringReplacement( GraphShader, "surface.BaseColor = BaseColor", "surface.BaseColor = Out.Emission" );
		}
	}
}
TArray<FString> MaterialNames;
FString EnsureUniqueMatName( FString MatName )
{
	int Instances = 0;
	for( int i = 0; i < MaterialNames.Num(); i++ )
	{
		if( MaterialNames[ i ].Compare( MatName, ESearchCase::IgnoreCase ) == 0 )
		{
			Instances++;
		}
	}
	
	MaterialNames.Add( MatName );

	if( Instances == 0 )
	{
		return MatName;
	}
	else
	{
		FString Ret = FString::Printf( TEXT( "%s_%d" ), *MatName, Instances );
		return Ret;
	}
}
bool HasOnlyShadingModel( UMaterial* Mat, EMaterialShadingModel ShadingModel )
{
#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION < 26)
	return Mat->GetShadingModel() == ShadingModel;
#else
	return Mat->GetShadingModels().HasOnlyShadingModel( ShadingModel );
#endif
}
void ProcessMaterial_RenderThread( MaterialBinding *Mat, const char *ProxyShaderString, const char* GraphShaderString )
{
	#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >= 2
		//Shader source is always extracted on gamethread for 5.2+
	#else
		GetMaterialShaderSource( Mat, false );
	#endif


	bool UsesAlphaTest = false;
	bool IsTransparent = false;

	auto OpacityMaskExp = GetOpacityMask( Mat->BaseMaterial )->Expression;
	
	auto AttributesExp = GetMaterialAttributes( Mat->BaseMaterial)->Expression;
	if ( AttributesExp )
	{
		UMaterialExpressionMakeMaterialAttributes *MakeMaterialAttributes = dynamic_cast<UMaterialExpressionMakeMaterialAttributes*>( AttributesExp );
		if ( MakeMaterialAttributes )
		{
			OpacityMaskExp = MakeMaterialAttributes->OpacityMask.Expression;
		}		
	}
	
	EBlendMode BlendMode = Mat->BaseMaterial->BlendMode;
	if( Mat->MaterialInstance )
		BlendMode = Mat->MaterialInstance->GetBlendMode();

	if ( BlendMode == BLEND_Masked )
		UsesAlphaTest = true;
	if( BlendMode == BLEND_Translucent || BlendMode == BLEND_Additive || BlendMode == BLEND_Modulate )
		IsTransparent = true;

	EMaterialShadingModel ShadingModel = MSM_DefaultLit;
	
	if( HasOnlyShadingModel( Mat->BaseMaterial, MSM_Unlit ))
	{
		ShadingModel = MSM_Unlit;
	}

	std::string MaterialCollectionDefinitions;
	TArray<UMaterialExpression*> OutExpressions = GetExpressions( Mat->BaseMaterial );
	TArray<UMaterialParameterCollection*> Collections;
	TArray<bool> CollectionsInitializations;
	if( Mat->MaterialInstance )
	{
		GatherExpressionsFromMaterialLayers( Mat->MaterialInstance, OutExpressions );
	}
	GetMaterialCollectionIndices( Mat->BaseMaterial, Collections );
	for( int i = 0; i < Collections.Num(); i++ )
		CollectionsInitializations.Add( false );

	for( int i = 0; i < OutExpressions.Num(); i++ )
	{
		UMaterialExpression* Exp = OutExpressions[ i ];

		UMaterialExpressionMaterialFunctionCall* ExpMFC = dynamic_cast<UMaterialExpressionMaterialFunctionCall*>( Exp );
		if( ExpMFC && ExpMFC->MaterialFunction )
		{
			TArray<UMaterialExpression*> FunctionExpressions = GetFunctionExpressions( ExpMFC->MaterialFunction );

			for( int u = 0; u < FunctionExpressions.Num(); u++ )
			{
				Exp = FunctionExpressions[ u ];
				OutExpressions.Add( Exp );
			}
			continue;
		}
		UMaterialExpressionCollectionParameter* ExpCollectionParameter = Cast<UMaterialExpressionCollectionParameter>( Exp );

		if( ExpCollectionParameter && ExpCollectionParameter->Collection )
		{
			int Index = Collections.Find( ExpCollectionParameter->Collection );
			bool WriteDefinition = false;
			if( Index == INDEX_NONE )
			{
				Index = Collections.Num();
				Collections.Add( ExpCollectionParameter->Collection );				
				WriteDefinition = true;
				CollectionsInitializations.Add( true );
			}
			else if( !CollectionsInitializations[ Index ] )
			{
				CollectionsInitializations[ Index ] = true;
				WriteDefinition = true;
			}
			if ( WriteDefinition )
			{
				const UMaterialParameterCollection* Collection = ExpCollectionParameter->Collection;
				std::string MatCollectionDef = GetMaterialCollectionString( Collection, Index );
				MaterialCollectionDefinitions += MatCollectionDef;
			}
		}
	}

	UMaterialInterface *M = Mat->MaterialInterface;

	if ( Mat->ShaderSource.Len() > 0 )
	{
		FString MatName = Mat->GenerateName();
		MatName = TCHAR_TO_ANSI( *MatName );
		FixUnicodeCharacters( MatName );
		MatName = EnsureUniqueMatName( MatName );

		//Don't write shaders if using standard material
		if( UTUSettings->Shaders == ShadersType::ST_STANDARD_SHADERS )
			return;

		int Len = MatName.Len();
		if ( Len > 0 )
		{
			FString ShaderFileName;
			FString ShaderExtension = GetShaderExtension();
			FString ShaderResourcePath = FString::Printf( TEXT( "Shaders/%s%s" ), *MatName, *ShaderExtension );
			ShaderFileName = GetAssetsFolder() + ShaderResourcePath;
			
			FString UnrealHLSLFile = GetOutputFile( TEXT("Shaders/"), MatName, TEXT(".hlsl") );

			FString ShaderOutDir = GetAssetsFolder();
			ShaderOutDir += TEXT("Shaders/");
			VerifyOrCreateDirectory( ShaderOutDir );

			if( UTUSettings->Engine == EngineType::GODOT )
			{
			#ifdef ENABLE_GODOT_EXPORT
				Mat->UnityMat->Shader->ResourcePath = ToANSIString( *ShaderResourcePath );
				GenerateShaderForGodot( Mat, ShaderFileName );
			#endif
				return;
			}

			FString ShaderSourceW = Mat->ShaderSource;
			std::string ShaderSourceANSI = ToANSIString( *ShaderSourceW );
			const char *CSource = ShaderSourceANSI.c_str();

			//Debug original UE HLSL in case of issues
			bool DebugUnrealHLSL = false;
			if ( DebugUnrealHLSL )
				SaveFile( ToANSIString( *UnrealHLSLFile ).c_str(), (uint32* )CSource, strlen( CSource ) );
			const char *ptr = strstr( CSource, "void CalcPixelMaterialInputs" );
			if ( ptr )
			{
				int CropStart = ( int64_t )ptr - ( int64_t )CSource;
				const char *EndPtr = strstr( ptr, "}" );
				if ( !EndPtr )
					return;
				int CropEnd = ( int64_t )EndPtr - ( int64_t )CSource;

				int CropSize = CropEnd - CropStart + 1;
				if ( CropSize < 0 )
				{
					return;
				}
				char *CalcPixelMaterialInputsStr = new char[ CropSize ];
				CalcPixelMaterialInputsStr[ CropSize ] = 0;
				memcpy( CalcPixelMaterialInputsStr, ptr, CropSize );

				std::string CalcPixelMaterialInputsFinal = CalcPixelMaterialInputsStr;

				//Fix Normal related calculations
				int BracketStart = CalcPixelMaterialInputsFinal.find( "{" );
				CalcPixelMaterialInputsFinal.insert( BracketStart + 1, "\n\tfloat3 WorldNormalCopy = Parameters.WorldNormal;\n" );
				if( UTUSettings->TangentToWorldLocation == TangentToWorldLocationType::TTWL_BEFORE_NORMAL_CALCULATION )
					CalcPixelMaterialInputsFinal.insert( BracketStart + 1, TangentToWorldAxisFlip );

				const char *AfterNormalsMarker = "// Now the rest of the inputs";
				int AfterNormalCodeStart = CalcPixelMaterialInputsFinal.find( AfterNormalsMarker );

				if( AfterNormalCodeStart != -1 )
				{
					if ( UTUSettings->TangentToWorldLocation == TangentToWorldLocationType::TTWL_AFTER_NORMAL_CALCULATION )
						CalcPixelMaterialInputsFinal.insert( AfterNormalCodeStart + strlen(AfterNormalsMarker), TangentToWorldAxisFlip );
					//Attempt to change from a Z up computation to a Y up
					StringReplacement( CalcPixelMaterialInputsFinal, "dot(Parameters.WorldNormal,normalize(MaterialFloat3(0.00000000,0.00000000,1.00000000)))",
									   "dot(Parameters.WorldNormal,normalize(MaterialFloat3(0.00000000,1.00000000,0.00000000)))", AfterNormalCodeStart );
					if ( UTUSettings->TangentToWorldLocation != TangentToWorldLocationType::TTWL_KEEP_UNITY_VECTORS_NO_WORLDNORMALCOPY )
						StringReplacement( CalcPixelMaterialInputsFinal, "Parameters.WorldNormal", "WorldNormalCopy", AfterNormalCodeStart );
					
				}
				else
					UE_LOG( LogTemp, Error, TEXT( "[UTU] ERROR! AfterNormalCodeStart wasn't found !" ));
				//<-

				ExecuteStringReplacements( CalcPixelMaterialInputsFinal );
				
				std::string GeneratedShader = ProxyShaderString;
				std::string GraphShaderStr;
				if ( GraphShaderString )
					GraphShaderStr = GraphShaderString;

				const char *InsertMarker = "M_Chair";
				std::string MatNameStr = ToANSIString( *MatName );

				if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_URP || CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
				{
					ReplaceShaderName( GraphShaderStr, InsertMarker, MatNameStr );
				}
				else
				{
					ReplaceShaderName( GeneratedShader, InsertMarker, MatNameStr );
				}

				SetupTexcoordInterpolators( ShaderSourceANSI, GeneratedShader );
				SetupVertexTexcoordInterpolators( ShaderSourceANSI, GeneratedShader );
				int Pos = -1;

				//Need to add alpha here if opacity/opacity mask is used ! + render que transparent
				//#pragma surface surf Standard

				//opacity = blending
				//opacity mask = alpha test
				
				if( Mat->MaterialInterface->IsTwoSided() )
				{
					std::string* TargetCode = &GeneratedShader;
					if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_URP || CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
						TargetCode = &GraphShaderStr;

					if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
					{
						StringReplacement( *TargetCode, "[HideInInspector]_CullMode(\"Float\", Float) = 2", "[HideInInspector]_CullMode(\"Float\", Float) = 0" );
						StringReplacement( *TargetCode, "[HideInInspector]_CullModeForward(\"Float\", Float) = 2", "[HideInInspector]_CullModeForward(\"Float\", Float) = 0" );
						StringReplacement( *TargetCode, "[HideInInspector][ToggleUI]_DoubleSidedEnable(\"Boolean\", Float) = 0", "[HideInInspector][ToggleUI]_DoubleSidedEnable(\"Boolean\", Float) = 1" );
					}
					else
					{
						const char* CullingMarker = "//Cull Off";

						while( 1 )
						{
							Pos = TargetCode->find( CullingMarker );
							if( Pos != TargetCode->npos )
								TargetCode->replace( Pos, 2, "" );//uncomment it
							else
								break;
						}
					}
				}

				std::string* TransparencyFixTarget = &GeneratedShader;
				if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_URP || CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
				{
					TransparencyFixTarget = &GraphShaderStr;
				}
				if( IsTransparent )
				{
					UncommentLine( *TransparencyFixTarget, "//BLEND_ON" );

					if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
					{
						StringReplacement( GraphShaderStr, "_SurfaceType(\"Float\", Float) = 0", "_SurfaceType(\"Float\", Float ) = 1" );
					}
				}
				else
				{
					UncommentLine( *TransparencyFixTarget, "//BLEND_OFF" );
				}
				if( BlendMode == BLEND_Additive )
				{
					UncommentLine( *TransparencyFixTarget, "//BLEND_ADDITIVE" );
				}

				#if ENGINE_MAJOR_VERSION >= 5
					RemoveComment( GeneratedShader, "//#define UE5" );
				#else
					CommentLine( GeneratedShader, "#include \"LargeWorldCoordinates.hlsl\"" );
				#endif

				if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_URP)
				{
					RemoveComment( GeneratedShader, "//#define URP" );
				}
				else if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
				{
					RemoveComment( GeneratedShader, "//#define HDRP" );
				}
				if ( UsesAlphaTest )
				{
					const char *OpacitMaskMarker = "if( PixelMaterialInputs.OpacityMask";
					Pos = GeneratedShader.find( OpacitMaskMarker );
					GeneratedShader.replace( Pos - 2, 2, "" );//uncomment it
				}				

				int NumVectorExpressions = 0;
				int NumScalarExpressions = 0;
				std::string ExpressionsData = GenerateInitializeExpressions( Mat, NumVectorExpressions, NumScalarExpressions );
				
				NumVectorExpressions = FMath::Max( NumVectorExpressions, 1 );
				NumScalarExpressions = FMath::Max( NumScalarExpressions, 1 );
				
				int NumScalarVectors = ( NumScalarExpressions + 3 ) / 4;
				
				GeneratedShader = AddNumberInString( GeneratedShader, "VectorExpressions[", NumVectorExpressions );
				GeneratedShader = AddNumberInString( GeneratedShader, "ScalarExpressions[", NumScalarVectors );
				#if ENGINE_MAJOR_VERSION >= 5
					StringReplacement( GeneratedShader, "VectorExpressions[", "PreshaderBuffer[" );
				#endif

				InsertMarker = "MaterialStruct Material;";
				Pos = GeneratedShader.find( InsertMarker );
				Pos += strlen( InsertMarker );

				GeneratedShader.insert( Pos + 1, ExpressionsData );				
				Pos += ExpressionsData.length();

				if( MaterialCollectionDefinitions.length() > 0 )
				{
					GeneratedShader.insert( Pos, MaterialCollectionDefinitions );
					Pos += MaterialCollectionDefinitions.length();

					int Offset = 0;
					while( 1 )//Do this so we initialize the data in VS and PS
					{
						InsertMarker = "InitializeExpressions();";
						int InitPos = GeneratedShader.find( InsertMarker, Offset );
						if( InitPos == -1 )
							break;
						InitPos += strlen( InsertMarker );

						std::string MaterialCollectionInits;
						for( int i = 0; i < Collections.Num(); i++ )
						{
							char Text[ 1024 ] = "";
							snprintf( Text, sizeof( Text ), "\n\tInitialize_MaterialCollection%d();\n", i );
							MaterialCollectionInits += Text;
						}

						GeneratedShader.insert( InitPos, MaterialCollectionInits );
						Offset = InitPos + MaterialCollectionInits.length();
						//Pos = Offset;
					}
				}

				if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_URP )
				{
					StringReplacement( GraphShaderStr, "ProxyURP", MatNameStr.c_str() );
				}
				else if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
				{
					StringReplacement( GraphShaderStr, "ProxyHDRP", MatNameStr.c_str() );
				}
				
				#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 2
					const char* VSMarker = "float3 GetMaterialWorldPositionOffsetRaw(";
				#elif ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION == 0
					const char* VSMarker = "WPO_PRECISE(float3) GetMaterialWorldPositionOffset(";
				#else
					const char* VSMarker = "float3 GetMaterialWorldPositionOffset(";
				#endif

				std::string VSStr = ExtractFunction( CSource, VSMarker );

				#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 2
					StringReplacement( VSStr, "GetMaterialWorldPositionOffsetRaw", "GetMaterialWorldPositionOffset" );
				#endif
				ExecuteStringReplacements( VSStr );
				
				int VTPackedPageTableUniformPS = DetectMaxVariableSize( CalcPixelMaterialInputsFinal, "VTPackedPageTableUniform" );
				int VTPackedUniformPS = DetectMaxVariableSize( CalcPixelMaterialInputsFinal, "VTPackedUniform" );
				int VTPackedPageTableUniformVS = DetectMaxVariableSize( VSStr, "VTPackedPageTableUniform" );				
				int VTPackedUniformVS = DetectMaxVariableSize( VSStr, "VTPackedUniform" );

				int VTPackedPageTableUniformSize = FMath::Max( VTPackedPageTableUniformPS, VTPackedPageTableUniformVS ) + 1;
				int VTPackedUniformSize = FMath::Max( VTPackedUniformPS, VTPackedUniformVS ) + 1;
				int BeforeLength = GeneratedShader.length();
				GeneratedShader = AddNumberInString( GeneratedShader, "VTPackedPageTableUniform[", VTPackedPageTableUniformSize * 2 );
				GeneratedShader = AddNumberInString( GeneratedShader, "VTPackedUniform[", VTPackedUniformSize );

				if( GeneratedShader.length() > BeforeLength )
				{
					//Adjust pixel shader insertion point
					int Diff = GeneratedShader.length() - BeforeLength;
					Pos += Diff;
				}

				std::string CustomizedUVs;
				if( Mat->BaseMaterial->NumCustomizedUVs > 0 )
				{
					CustomizedUVs = ExtractFunction( CSource, "void GetMaterialCustomizedUVs" );
					SetupCustomizedUVs( CustomizedUVs );
				}
				
				size_t posPS = CalcPixelMaterialInputsFinal.find( "CustomExpression" );
				size_t posVS = VSStr.find( "CustomExpression" );
				if( posPS != -1 || posVS != -1 )
				{
					if( ExportVS && CVarRenderPipeline.GetValueOnAnyThread() != (int)RenderPipeline::RP_BUILTIN )
					{
						AddCustomExpressions( VSStr, CSource, true );
						if( CustomizedUVs.length() > 0 )
						{
							VSStr += CustomizedUVs;
						}
					}
					else
					{
						AddCustomExpressions( CalcPixelMaterialInputsFinal, CSource );
						if( CustomizedUVs.length() > 0 )
						{
							CalcPixelMaterialInputsFinal += CustomizedUVs;
						}
					}
				}
				else
				{
					if ( CustomizedUVs.length() > 0 )
						GeneratedShader.insert( Pos, CustomizedUVs );
				}

				GeneratedShader.insert( Pos, CalcPixelMaterialInputsFinal );

				GeneratePropertyFields( GeneratedShader, Mat, GraphShaderStr, VSStr );

				ProcessVertexInterpolators( ShaderSourceANSI, GeneratedShader );

				if( ExportVS && CVarRenderPipeline.GetValueOnAnyThread() != (int)RenderPipeline::RP_BUILTIN )
				{
					int Offset = GeneratedShader.find( "void CalcPixelMaterialInputs" );
					if( Offset != -1 )
					{
						GeneratedShader.insert( Offset, VSStr );
						#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION == 0
							GeneratedShader.insert( Offset, "\n#define WPO_PRECISE(T) T\n" );
						#endif
					}

					
					RemoveComment( GraphShaderStr, "//float3 WPO = PrepareAndGetWPO" );
					CommentLine( GraphShaderStr, "float3 WPO = float3( 0, 0, 0 );" );
				}
				else
				{
					CommentLine( GeneratedShader, "Offset = GetMaterialWorldPositionOffset" );
				}
				if( CustomizedUVs.length() > 0 )
				{
					RemoveComment( GeneratedShader, "//#define HAS_CUSTOMIZED_UVS" );
				}

				bool IsStrataMaterial = FixStrataStuff( GeneratedShader );
				if( Mat->BaseMaterial->bTangentSpaceNormal == 0 || IsStrataMaterial )
				{
					StringReplacement( GeneratedShader, "HAS_WORLDSPACE_NORMAL 0", "HAS_WORLDSPACE_NORMAL 1" );
				}

				SetupShadingModel( GraphShaderStr, ShadingModel );

				std::string ShaderFileNameANSI = ToANSIString( *ShaderFileName );

				if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_URP || CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
				{
					SaveFile( ShaderFileNameANSI.c_str(), (void*)GraphShaderStr.c_str(), GraphShaderStr.length() );
					std::string MatNameHLSL = MatNameStr;
					FString MatNameHLSLWide = ToWideString( MatNameHLSL ).c_str();
					FString MatHLSLWide = GetOutputFile( TEXT("Shaders/" ), MatNameHLSLWide, TEXT(".hlsl" ));

					std::string MatHLSLWideStr = ToANSIString( *MatHLSLWide );
					SaveFile( MatHLSLWideStr.c_str(), (void*)GeneratedShader.c_str(), GeneratedShader.length() );
				}
				else
					SaveFile( ShaderFileNameANSI.c_str(), (void* )GeneratedShader.c_str(), GeneratedShader.length() );
				Mat->UnityMat->Shader->FileName = ShaderFileNameANSI;

				Mat->UnityMat->Shader->GenerateGUID();
				std::string ShaderMetaContents = GenerateShaderMeta( Mat->UnityMat->Shader->GUID );
				std::string ShaderMetaFile = ShaderFileNameANSI;
				ShaderMetaFile += ".meta";
				SaveFile( ShaderMetaFile.c_str(), (void*)ShaderMetaContents.c_str(), ShaderMetaContents.length() );

				
				Mat->UnityMat->Shader->Contents = GeneratedShader;
			}			
		}		
	}	
}

std::vector< MeshBinding* > MeshList;


MeshBinding* GetMeshBinding( UnityMesh* Mesh )
{
	for( int i = 0; i < MeshList.size(); i++ )
	{
		if( MeshList[ i ]->TheUnityMesh == Mesh )
			return MeshList[ i ];
	}

	return nullptr;
}
const FStaticMeshRenderData* GetRenderData( const UStaticMesh* StaticMesh )
{
	if( !StaticMesh )
		return nullptr;
	#if ENGINE_MINOR_VERSION >= 27 || ENGINE_MAJOR_VERSION >= 5
		const FStaticMeshRenderData* MeshRenderData = StaticMesh->GetRenderData();
	#else
		const FStaticMeshRenderData* MeshRenderData = StaticMesh->RenderData.Get();
	#endif

	return MeshRenderData;
}
UBodySetup* GetBodySetup( const UStaticMesh* StaticMesh )
{
	#if ENGINE_MINOR_VERSION >= 27 || ENGINE_MAJOR_VERSION >= 5
		UBodySetup* BodySetup = StaticMesh->GetBodySetup();
	#else
		UBodySetup* BodySetup = StaticMesh->BodySetup;
	#endif

	return BodySetup;
}
const USkeleton* GetSkeleton( const USkeletalMesh* SkeletalMesh )
{
	#if ENGINE_MINOR_VERSION >= 27 || ENGINE_MAJOR_VERSION >= 5
		const USkeleton* Skeleton = SkeletalMesh->GetSkeleton();
	#else
		const USkeleton* Skeleton = SkeletalMesh->Skeleton;
	#endif

	return Skeleton;
}
TArray<UMorphTarget*> GetMorphTargets( const USkeletalMesh* SkeletalMesh )
{
	#if ENGINE_MINOR_VERSION >= 27 || ENGINE_MAJOR_VERSION >= 5
		TArray<UMorphTarget*> MorphTargets = SkeletalMesh->GetMorphTargets();
	#else
		TArray<UMorphTarget*> MorphTargets = SkeletalMesh->MorphTargets;
	#endif

	return MorphTargets;
}
const TArray<FSkeletalMaterial>& GetMaterials( const USkeletalMesh* SkeletalMesh )
{
	#if ENGINE_MINOR_VERSION >= 27 || ENGINE_MAJOR_VERSION >= 5
		const TArray<FSkeletalMaterial>& Materials = SkeletalMesh->GetMaterials();
	#else
		const TArray<FSkeletalMaterial>& Materials = SkeletalMesh->Materials;
	#endif

	return Materials;
}
bool RequiresNewMeshDueToVertexColors( UPrimitiveComponent* MeshComp, int LOD )
{
	auto StaticMeshComp = Cast< UStaticMeshComponent>( MeshComp );
	if (!StaticMeshComp )
		return false;
	if( UTUSettings->ExportVertexColors )
	{
		if( StaticMeshComp->LODData.Num() > LOD )
		{
			if( StaticMeshComp->LODData[ LOD ].OverrideVertexColors )
			{
				return true;
			}
		}
	}

	return false;
}
UnityMesh * GetUnityMesh( const UStaticMesh *UnrealStaticMesh, USkeletalMesh* SkeletalMesh,
						  const char *Name, int LOD, UPrimitiveComponent* MeshComp )
{
	for( int i = 0; i < MeshList.size(); i++ )
	{
		MeshBinding* M = MeshList[ i ];
		bool HasSameLOD = ( M->LOD == LOD );
		if( CVarFBXPerActor.GetValueOnAnyThread() )
			HasSameLOD = true;
		bool SameComponent = true;
		//If true, it has a unique mesh for vertex colors
		if( MeshComp )
		{
			SameComponent = ( MeshComp == M->MeshComp );
		}
		bool SameMesh = true;
		if( SkeletalMesh )
		{
			SameMesh = ( M->UnrealSkeletalMesh == SkeletalMesh );
		}
		else
		{
			SameMesh = (M->UnrealStaticMesh == UnrealStaticMesh && M->TheUnityMesh->Name.compare( Name ) == 0);
		}
		if( SameMesh && HasSameLOD && SameComponent )
		{
			return M->TheUnityMesh;
		}
	}

	MeshBinding *NewMeshBinding = new MeshBinding;
	NewMeshBinding->TheUnityMesh = new UnityMesh;
	NewMeshBinding->TheUnityMesh->Name = Name;
	NewMeshBinding->LOD = LOD;
	NewMeshBinding->UnrealStaticMesh = ( UStaticMesh*)UnrealStaticMesh;
	NewMeshBinding->UnrealSkeletalMesh = SkeletalMesh;
	
	if( UnrealStaticMesh )
	{
		const FStaticMeshRenderData* MeshRenderData = GetRenderData( (UStaticMesh*)UnrealStaticMesh );
		NewMeshBinding->TotalLods = MeshRenderData->LODResources.Num();
	}
	else if( SkeletalMesh )
	{
		NewMeshBinding->TotalLods = SkeletalMesh->GetResourceForRendering()->LODRenderData.Num();
	}

	if( !UTUSettings->ExportLODs )
	{
		NewMeshBinding->TotalLods = 1;
	}

	NewMeshBinding->MeshComp = MeshComp;

	//Generate Mesh File output
	FString MeshFile;

	if( CVarUseOriginalPaths.GetValueOnAnyThread() == 1 )
	{
		if ( NewMeshBinding->UnrealStaticMesh )
			MeshFile += GetAssetPathFolder( NewMeshBinding->UnrealStaticMesh );
		else if( NewMeshBinding->UnrealSkeletalMesh )
			MeshFile += GetAssetPathFolder( NewMeshBinding->UnrealSkeletalMesh );
	}
	else
	{
		MeshFile += TEXT("Meshes/");
	}

	FString NameWide = ToWideString( Name ).c_str();
    MeshFile += NameWide;
	if( MeshComp && RequiresNewMeshDueToVertexColors( MeshComp, LOD ) )
	{
		char Text[ 32 ];
		snprintf( Text, sizeof( Text ), "@%p", MeshComp );
		FString TextWide = ToWideString( Text ).c_str();
		MeshFile += TextWide;
	}
	
	MeshFile += GetMeshExtension();

	NewMeshBinding->TheUnityMesh->ResourcePath = ToANSIString( *MeshFile );
	MeshFile = GetAssetsFolder() + MeshFile;
	CreateAllDirectories( MeshFile );
	NewMeshBinding->TheUnityMesh->File = ToANSIString( *MeshFile );

	MeshList.push_back( NewMeshBinding );
	return NewMeshBinding->TheUnityMesh;
}
FString GenerateAnimationFilePath( const UAnimSequence* Anim )
{
	FString Path = GetAssetsFolder();

	if( CVarUseOriginalPaths.GetValueOnAnyThread() == 1 )
	{		
		Path += GetAssetPathFolder( Anim );
	}
	else
	{
		Path += TEXT( "Meshes/" );
	}

	CreateAllDirectories( Path );
	Path += *Anim->GetName();

	Path += GetMeshExtension();

	return Path;
}
void ProcessSkeletalMesh( USkeletalMeshComponent *SkeletalMeshComponent )
{
	MaterialBinding **MaterialsUsed = nullptr;
	TArray<UMaterialInterface*> Materials = SkeletalMeshComponent->GetMaterials();

	MaterialsUsed = new MaterialBinding*[ Materials.Num()];
	for( int i = 0; i < Materials.Num(); i++ )
		MaterialsUsed[ i ] = nullptr;
	
	UObject* LoadedObject = StaticLoadObject( UMaterialInterface::StaticClass(), nullptr, TEXT( "/Engine/EngineMaterials/DefaultMaterial" ) );
	UMaterialInterface* DefaultMaterial = Cast<UMaterialInterface>( LoadedObject );
	if( Materials.Num() > 0 )
	{
		for( int i = 0; i < Materials.Num(); i++ )
		{
			MaterialsUsed[ i ] = nullptr;
			UMaterialInterface *MaterialInterface = Materials[ i ];
			if( !MaterialInterface )
			{
				Materials[ i ] = DefaultMaterial;
			}

			MaterialsUsed[ i ] = ProcessMaterialReference( MaterialInterface );
		}
	}
}
void MoveComponentsToNewGO( GameObject* GO )
{
	GameObject* NewGameObject = new GameObject;
	
	for( int i = 0; i < GO->Components.size(); i++ )
	{
		UnityComponent* Comp = GO->Components[ i ];
		
		{
			NewGameObject->Components.push_back( Comp );
			Comp->Owner = NewGameObject;

			GO->Components.erase( GO->Components.begin() + i );
			i--;
		}
	}
	
	{
		MeshRenderer* MR = ( MeshRenderer * )NewGameObject->GetComponent( CT_MESHRENDERER );
		if ( MR )
			NewGameObject->Name = MR->Name;

		GO->AddChild( NewGameObject );
		GO->OwnerScene->Add( NewGameObject );
	}	
}
MaterialBinding** GetMaterialsUsed( UStaticMeshComponent* StaticMeshComp, USkeletalMeshComponent* SkeletalMeshComponent,
									bool GetComponentMaterials, int& NumMaterials );
bool BaseMeshHasDuplicateMaterials( MaterialBinding** MeshMaterials, int MaxMeshMaterials )
{
	for( int i = 0; i < MaxMeshMaterials - 1; i++ )
		for( int u = i + 1; u < MaxMeshMaterials; u++ )
		{
			if( MeshMaterials[ i ]->UnityMat == MeshMaterials[ u ]->UnityMat )
			{
				return true;
			}
		}

	return false;
}
void CreateBoneGameObjects( UnityMesh* Mesh, USkeletalMesh* UnrealSkeletalMesh, GameObject* ParentGO )
{
	#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 27) || ENGINE_MAJOR_VERSION == 5
		const FReferenceSkeleton& RefSkeleton = UnrealSkeletalMesh->GetRefSkeleton();
	#else
		const FReferenceSkeleton& RefSkeleton = UnrealSkeletalMesh->RefSkeleton;
	#endif
	

	if( RefSkeleton.GetRawBoneNum() == 0 )
	{
		return;
	}

	int NumBones = RefSkeleton.GetRawBoneNum();
	GameObject** BoneGameObjects = new GameObject*[ NumBones ];
	//Get all names

	for( int32 BoneIndex = 0; BoneIndex < NumBones; ++BoneIndex )
	{
		const FMeshBoneInfo& CurrentBone = RefSkeleton.GetRefBoneInfo()[ BoneIndex ];
		FTransform& BoneTransform = (FTransform&)RefSkeleton.GetRefBonePose()[ BoneIndex ];

		std::string NewBoneName = ToANSIString( *CurrentBone.ExportName );
		Mesh->BoneNames.push_back( NewBoneName );

		BoneGameObjects[ BoneIndex ] = new GameObject();
		BoneGameObjects[ BoneIndex ]->Name = NewBoneName;

		TransformComponent* TC = ( TransformComponent*)BoneGameObjects[ BoneIndex ]->GetComponent( CT_TRANSFORM );
		ConvertTransformForBones( BoneTransform, TC, BoneIndex == 0 );

		if( BoneIndex )
		{
			BoneGameObjects[ CurrentBone.ParentIndex ]->AddChild( BoneGameObjects[ BoneIndex ] );
		}
		else
			ParentGO->AddChild( BoneGameObjects[ BoneIndex ] );
	}
}
bool AreMaterialsUnique( TArray<UMaterialInterface*> Materials )
{
	for( int i = 0; i < Materials.Num() - 1; i++ )
	{
		for( int u = i + 1; u < Materials.Num(); u++ )
		{
			if( Materials[ i ] == Materials[ u ] )
				return false;
		}
	}

	return true;
}
bool HasUniqueMaterials( UStaticMeshComponent* StaticMeshComp )
{
	TArray<UMaterialInterface*> Materials = StaticMeshComp->GetMaterials();
	return AreMaterialsUnique( Materials );
}
TArray<UActorComponent*> AllComponentsInScene;
UStaticMeshComponent* FindComponentWithUniqueMaterials( UStaticMeshComponent* StaticMeshComp )
{
	for( int i = 0; i< AllComponentsInScene.Num(); i++ )
	{
		UStaticMeshComponent* Comp = Cast<UStaticMeshComponent>( AllComponentsInScene[i] );
		if( Comp && StaticMeshComp && Comp->GetStaticMesh() == StaticMeshComp->GetStaticMesh() &&
			Comp->GetOwner() != nullptr && Comp->GetClass() == UStaticMeshComponent::StaticClass() )
		{
			TArray<UMaterialInterface*> Materials = Comp->GetMaterials();
			if( AreMaterialsUnique( Materials ) )
			{
				return Comp;
			}
		}
	}

	return nullptr;
}
USkeletalMesh* GetSkeletalMesh( USkinnedMeshComponent* SMC )
{
	#if ENGINE_MAJOR_VERSION == 4 || (ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION < 2 )
		return SMC->SkeletalMesh;
	#elif ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 2
		USkeletalMeshComponent* SkeletalMeshComp = Cast<USkeletalMeshComponent>( SMC );
		if( SkeletalMeshComp )
			return SkeletalMeshComp->GetSkeletalMeshAsset();
		else
			return nullptr;
	#endif
}
UAnimSequence* GetAnimationSequence( USkeletalMeshComponent* SkeletalMeshComp )
{
	UAnimSequence* AnimSequence = Cast<UAnimSequence>( SkeletalMeshComp->AnimationData.AnimToPlay );
	if( !AnimSequence )
	{
		UAnimationAsset* AnimationAsset = nullptr;
		if ( SkeletalMeshComp->GetSingleNodeInstance() )
			AnimationAsset = SkeletalMeshComp->GetSingleNodeInstance()->GetAnimationAsset();
		AnimSequence = Cast<UAnimSequence>( AnimationAsset );
	}
	return AnimSequence;
}
Renderer* ExportLOD( UStaticMeshComponent* StaticMeshComp, USkeletalMeshComponent* SkeletalMeshComp,
					 GameObject* ComponentGO, AActor* Actor, int LOD, int TotalLODs )
{
	const UStaticMesh* StaticMesh = nullptr;
	const FStaticMeshLODResources* LODResources = nullptr;
	if( StaticMeshComp )
	{
		StaticMesh = StaticMeshComp->GetStaticMesh();
		LODResources = &GetRenderData( StaticMesh )->LODResources[ LOD ];
	}
	USkeletalMesh* SkeletalMesh = nullptr;
	FSkeletalMeshLODRenderData* SkeletalLODRenderData = nullptr;
	if( SkeletalMeshComp )
	{
		SkeletalMesh = GetSkeletalMesh( SkeletalMeshComp );
		SkeletalLODRenderData = &SkeletalMesh->GetResourceForRendering()->LODRenderData[LOD];
	}

	FString OriginalMeshName;
	FString SourceFile;
	if( StaticMeshComp )
	{
		OriginalMeshName = StaticMesh->GetName();
		SourceFile = StaticMesh->GetName();		
	}
	else if( SkeletalMeshComp )
	{
		OriginalMeshName = SkeletalMesh->GetName();
		SourceFile = SkeletalMesh->GetName();
	}

	OriginalMeshName = FixUnicodeCharacters( OriginalMeshName );
	SourceFile = FixUnicodeCharacters( SourceFile );

	if( SourceFile.Len() == 0 )
	{
		SourceFile = Actor->GetName();
	}

	if( SourceFile.Len() > 0 && LOD > 0 && !CVarFBXPerActor.GetValueOnAnyThread() )
	{
		SourceFile = FString::Printf( TEXT( "%s_LOD%d" ), *SourceFile, LOD );
	}

	std::string Name;
	Name = ToANSIString( *SourceFile );

	UStaticMeshComponent* CompareComp = nullptr;

	if( RequiresNewMeshDueToVertexColors( StaticMeshComp, LOD ) )
	{
		ComponentGO->CanBePrefab = false;
		if( ComponentGO->Parent )
			ComponentGO->Parent->CanBePrefab = false;
		CompareComp = StaticMeshComp;
	}

	UnityMesh* NewMesh = GetUnityMesh( StaticMesh, SkeletalMesh, Name.c_str(), LOD, CompareComp);
	MeshBinding* Binding = GetMeshBinding( NewMesh );
	if( Binding )
	{
		if( StaticMeshComp )
		{
			Binding->OwnerActor = StaticMeshComp->GetOwner();
			TArray<UMaterialInterface*> Materials = StaticMeshComp->GetMaterials();
			if( !AreMaterialsUnique( Materials ) )
			{
				//Choose an actor with different materials so material slots don't get merged in Unity
				auto SomeOtherComponent = FindComponentWithUniqueMaterials( StaticMeshComp );
				if( SomeOtherComponent )
					Binding->OwnerActor = SomeOtherComponent->GetOwner();
			}
		}
		else if( SkeletalMeshComp )
		{
			Binding->OwnerActor = SkeletalMeshComp->GetOwner();
			if( SkeletalMeshComp->GetAnimationMode() == EAnimationMode::AnimationSingleNode )
			{
				Binding->AnimSequence = GetAnimationSequence( SkeletalMeshComp );
			}
		}
	}

	int MaxMeshMaterials = 0;
	MaterialBinding** MeshMaterials = GetMaterialsUsed( StaticMeshComp, SkeletalMeshComp, false, MaxMeshMaterials );

	if( NewMesh->Sections.size() == 0 )
	{
		if( LODResources )
		{
			for( int i = 0; i < LODResources->Sections.Num(); i++ )
			{
				FStaticMeshSection Section = LODResources->Sections[ i ];
				MeshSection* NewMeshSection = new MeshSection;
				NewMeshSection->MaterialIndex = Section.MaterialIndex;
				NewMeshSection->IndexOffset = Section.FirstIndex;
				NewMeshSection->NumIndices = Section.NumTriangles * 3;

				NewMesh->Sections.push_back( NewMeshSection );
			}
		}
		else if( SkeletalLODRenderData )
		{
			for( int i = 0; i < SkeletalLODRenderData->RenderSections.Num(); i++ )
			{
				FSkelMeshRenderSection* Section = &SkeletalLODRenderData->RenderSections[ i ];
				MeshSection* NewMeshSection = new MeshSection;
				NewMeshSection->MaterialIndex = Section->MaterialIndex;
				NewMeshSection->IndexOffset = Section->BaseIndex;
				NewMeshSection->NumIndices = Section->NumTriangles * 3;

				NewMesh->Sections.push_back( NewMeshSection );
			}
		}
		
		if( CVarFBXPerActor.GetValueOnAnyThread() == 0 )
		{
			int NumVertices = LODResources->VertexBuffers.PositionVertexBuffer.GetNumVertices();
			int NumTexcoordChannels = LODResources->VertexBuffers.StaticMeshVertexBuffer.GetNumTexCoords();
			int NumIndices = LODResources->IndexBuffer.GetNumIndices();

			uint32* Indices = new uint32[ NumIndices ];
			FVector* Vertices = new FVector[ NumVertices ];
			FVector* Normals = new FVector[ NumVertices ];
			FVector4* Tangents = new FVector4[ NumVertices ];
			FVector2D* Texcoords = new FVector2D[ NumVertices ];
			FVector2D* Texcoords1 = nullptr;
			if( NumTexcoordChannels > 1 )
				Texcoords1 = new FVector2D[ NumVertices ];
			FColor* Colors = nullptr;

			if( NumIndices > 0 )
			{
				FIndexArrayView ArrayView = LODResources->IndexBuffer.GetArrayView();

				for( int i = 0; i < NumIndices; i++ )
				{
					uint32 Index32 = ArrayView[ i ];
					Indices[ i ] = Index32;

					if( LODResources->IndexBuffer.Is32Bit() )
					{

					}
				}

				TotalTriangles += NumIndices / 3;
			}
			else
				TotalTriangles += NumVertices / 3;

			for( int i = 0; i < LODResources->Sections.Num(); i++ )
			{
				FStaticMeshSection Section = LODResources->Sections[ i ];
				int MatIndex = Section.MaterialIndex;
				int VertexStart = Section.MinVertexIndex;
				int VertexEnd = Section.MaxVertexIndex;
				int IndexStart = Section.FirstIndex;
				int NumTriangles = Section.NumTriangles;
			}

			TArray<FColor> ColorArray;
			TArray<FPaintedVertex> PaintedVertices;

			if( UTUSettings->ExportVertexColors )
			{
				if( StaticMeshComp->LODData.Num() > LOD )
				{
					if( StaticMeshComp->LODData[ LOD ].OverrideVertexColors )
					{
						StaticMeshComp->LODData[ LOD ].OverrideVertexColors->GetVertexColors( ColorArray );
					}
				}

				if( ColorArray.Num() == 0 )
				{
					LODResources->VertexBuffers.ColorVertexBuffer.GetVertexColors( ColorArray );
				}
				if( ColorArray.Num() > 0 && ColorArray.Num() == NumVertices )
				{
					Colors = new FColor[ ColorArray.Num() ];
				}
			}
			for( int i = 0; i < NumVertices; i++ )
			{
				FVector Pos = (FVector)LODResources->VertexBuffers.PositionVertexBuffer.VertexPosition( i );
				//Scale down from Unreal's cm units to Unity's m
				Pos /= 100.0f;

				FRotator Rotator = FRotator::MakeFromEuler( FVector( 90, 0, 0 ) );

				if( CVarAssetsWithYUp.GetValueOnAnyThread() == 1 )
				{
					Pos = Rotator.RotateVector( Pos );
				}
				if( CVarUsePostImportTool.GetValueOnAnyThread() == 0 )
				{
					Pos.X *= -1;
				}

				Vertices[ i ] = Pos;
			}

			NewMesh->Vertices = Vertices;
			NewMesh->Normals = Normals;
			NewMesh->Tangents = Tangents;
			NewMesh->Texcoords = Texcoords;
			NewMesh->Texcoords1 = Texcoords1;
			NewMesh->Colors = Colors;
			NewMesh->AllIndices = Indices;
			NewMesh->NumVertices = NumVertices;
			NewMesh->NumIndices = NumIndices;
		}

		for( int i = 0; i < MaxMeshMaterials; i++ )
		{
			if( MeshMaterials[ i ] )
				NewMesh->Materials.push_back( MeshMaterials[ i ]->UnityMat );
			else
				NewMesh->Materials.push_back( nullptr );
		}
	}
		
	FString  LodNameStr = OriginalMeshName;
	if( TotalLODs > 1 )
		LodNameStr = FString::Printf( TEXT( "%s_LOD%d" ), *OriginalMeshName, LOD );

	std::string LodName = ToANSIString( *LodNameStr );

	MeshRenderer* MR = nullptr;
	MeshFilter* MF = nullptr;
	SkinnedMeshRenderer* SMR = nullptr;

	GameObject* LODGO = new GameObject;
	ComponentGO->AddChild( LODGO );
	ComponentGO->OwnerScene->Add( LODGO );
	
	if( StaticMeshComp )
	{
		MR = (MeshRenderer*)LODGO->AddComponent( CT_MESHRENDERER );
		MF = (MeshFilter*)LODGO->AddComponent( CT_MESHFILTER );
	}
	else if( SkeletalMeshComp )
	{
		SMR = (SkinnedMeshRenderer*)LODGO->AddComponent( CT_SKINNEDMESHRENDERER );
		SMR->LOD = LOD;
		SMR->TotalLods = TotalLODs;
		auto Bounds = GetSkeletalMesh( SkeletalMeshComp )->GetBounds();
		SMR->Center = Bounds.Origin / 100.0f;
		SMR->Extent = Bounds.BoxExtent / 100.0f;
		if ( LOD == 0 )
			CreateBoneGameObjects( NewMesh, Binding->UnrealSkeletalMesh, ComponentGO );
	}

	LODGO->Name = LodName;

	if( MF )
		MF->Mesh = NewMesh;
	else if( SMR )
		SMR->Mesh = NewMesh;

	//Only FBX has different FileID for every LOD
	if( CVarFBXPerActor.GetValueOnAnyThread() == 1 )
	{
		if( MF )
		{
			if( TotalLODs > 1 )
				MF->SubMeshID = 4300000 + LOD * 2;
			else
				MF->SubMeshID = 4300000;
		}
		else if( SMR )
		{
			if( TotalLODs > 1 )
				SMR->SubMeshID = 4300000 + LOD * 2;
			else
				SMR->SubMeshID = 4300000;
		}
	}

	if( MR )
	{
		MR->Name = LodName;
		if( StaticMeshComp )
			MR->CastShadows = StaticMeshComp->CastShadow;
	}
	else if( SMR )
	{
		if( SkeletalMeshComp )
			SMR->CastShadows = SkeletalMeshComp->CastShadow;
	}

	int MaxMaterials = 0;
	MaterialBinding** MaterialsUsed = GetMaterialsUsed( StaticMeshComp, SkeletalMeshComp, true, MaxMaterials );
	//bool HasDuplicateMaterials = BaseMeshHasDuplicateMaterials( MeshMaterials, MaxMeshMaterials );
	//Add materials based on that section's MaterialIndex
	if( LODResources )
	{
		for( int i = 0; i < LODResources->Sections.Num(); i++ )
		{
			FStaticMeshSection Section = LODResources->Sections[ i ];
			if( Section.MaterialIndex >= 0 && Section.MaterialIndex < MaxMaterials )
			{
				MaterialBinding* MatBinding = MaterialsUsed[ Section.MaterialIndex ];
				if( MatBinding )
				{
					MR->AddMaterial( MatBinding->UnityMat, false );// HasDuplicateMaterials );
				}
				else
					MR->AddMaterial( nullptr, false );// HasDuplicateMaterials );
			}
		}
	}
	else if ( SkeletalLODRenderData )
	{
		for( int i = 0; i < SkeletalLODRenderData->RenderSections.Num(); i++ )
		{
			FSkelMeshRenderSection* Section = &SkeletalLODRenderData->RenderSections[ i ];
			if( Section->MaterialIndex >= 0 && Section->MaterialIndex < MaxMaterials )
			{
				MaterialBinding* MatBinding = MaterialsUsed[ Section->MaterialIndex ];
				if( MatBinding )
				{
					SMR->AddMaterial( MatBinding->UnityMat, false );// HasDuplicateMaterials );
				}
				else
					SMR->AddMaterial( nullptr, false );// HasDuplicateMaterials );
			}
		}
	}

	if( MR )
		return MR;
	else// if( SMR )
		return SMR;
}
int GetNumRelevantComponents( AActor* A )
{
	TArray<UActorComponent*> comps;
	A->GetComponents( comps );
	int Num = 0;
	for( int i = 0; i < comps.Num(); i++ )
	{
		UActorComponent* AC = comps[ i ];
		ULightComponent* LightComp = dynamic_cast<ULightComponent*>( AC );
		if( LightComp )
		{
			Num++;
		}
		USkeletalMeshComponent* SkelMeshComp = dynamic_cast<USkeletalMeshComponent*>( AC );
		if( SkelMeshComp )
		{
			Num++;
		}
		USplineMeshComponent* SplineMeshComponent = Cast<USplineMeshComponent>( AC );
		if( SplineMeshComponent )
		{
			
		}
		UStaticMeshComponent* StaticMeshComp = dynamic_cast<UStaticMeshComponent*>( AC );
		if( StaticMeshComp )
		{
			Num++;
		}		
		USphereReflectionCaptureComponent* SphereReflection = Cast<USphereReflectionCaptureComponent>( AC );
		if( SphereReflection )
		{
			Num++;
		}
		UBoxReflectionCaptureComponent* BoxReflection = Cast<UBoxReflectionCaptureComponent>( AC );
		if( BoxReflection )
		{
			Num++;
		}
		UDecalComponent* DecalComponent = Cast<UDecalComponent>( AC );
		if( DecalComponent )
		{			
			Num++;
		}
	}

	return Num;
}
void RotateForYUp( FVector& Vector )
{
	FRotator Rotator = FRotator::MakeFromEuler( FVector( 90, 0, 0 ) );	
	Vector = Rotator.RotateVector( Vector );	
}
void SwitchYWithZ( FVector& Vector )
{
	float Temp = Vector.Y;
	Vector.Y = Vector.Z;
	Vector.Z = Temp;
}
void ConvertScaleForUnity( FVector& Vector )
{
	float Temp = Vector.Y;
	Vector.Y = Vector.Z;
	Vector.Z = Temp;

	Temp = Vector.Z;
	Vector.Z = Vector.X;
	Vector.X = Temp;
}

//Figure out if component or base mesh has unique materials since we need the unique materials variant because unity merges meshes
TArray<UMaterialInterface*> GetMaterialsToBeUsedInFBX( UStaticMeshComponent* StaticMeshComp )
{
	TArray<UMaterialInterface*> Materials = StaticMeshComp->GetMaterials();
	TArray<FStaticMaterial> StaticMaterials = GetStaticMaterials( StaticMeshComp->GetStaticMesh() );
	bool ComponentHasDuplicates = false;
	bool BaseMeshHasDuplicates = false;
	for( int i = 0; i < Materials.Num() - 1; i++ )
	{
		for( int u = i + 1; u < Materials.Num(); u++ )
		{
			if( Materials[ i ] == Materials[ u ] )
				ComponentHasDuplicates = true;
		}
	}
	for( int i = 0; i < StaticMaterials.Num() - 1; i++ )
	{
		for( int u = i + 1; u < StaticMaterials.Num(); u++ )
		{
			if( StaticMaterials[ i ].MaterialInterface == StaticMaterials[ u ].MaterialInterface )
				BaseMeshHasDuplicates = true;
		}
	}
	
	TArray<UMaterialInterface*> OutMaterials;
	int NumMaterials = StaticMeshComp->GetNumMaterials();
	
	for( int i = 0; i < NumMaterials; i++ )
	{
		UMaterialInterface* Mat = nullptr;
		if( StaticMeshComp )
		{
			if( !ComponentHasDuplicates )
				Mat = StaticMeshComp->GetMaterial( i );
			else
				Mat = StaticMeshComp->GetStaticMesh()->GetMaterial( i );
		}
		OutMaterials.Add( Mat );
	}

	return OutMaterials;
}
MaterialBinding** GetMaterialsUsed( UStaticMeshComponent* StaticMeshComp, USkeletalMeshComponent* SkeletalMeshComponent,
									bool GetComponentMaterials, int & NumMaterials )
{
	TArray<UMaterialInterface*> OutMaterials;
	
	if( StaticMeshComp )
		NumMaterials = StaticMeshComp->GetNumMaterials();
	if( SkeletalMeshComponent )
		NumMaterials = SkeletalMeshComponent->GetNumMaterials();
	for( int i = 0; i < NumMaterials; i++ )
	{
		UMaterialInterface* Mat = nullptr;
		if( StaticMeshComp )
		{
			if ( GetComponentMaterials )
				Mat = StaticMeshComp->GetMaterial( i );
			else
				Mat = StaticMeshComp->GetStaticMesh()->GetMaterial( i );
		}
		if( SkeletalMeshComponent )
		{
			if ( GetComponentMaterials )
				Mat = SkeletalMeshComponent->GetMaterial( i );
			else
				Mat = GetMaterials( GetSkeletalMesh( SkeletalMeshComponent ) )[i].MaterialInterface;
		}
		OutMaterials.Add( Mat );
	}
	NumMaterials = OutMaterials.Num();
	//Save a mesh with unique materials so they don't get merged in unity
	if( !GetComponentMaterials && !AreMaterialsUnique( OutMaterials ) )
	{
		for( int i = 0; i < AllComponentsInScene.Num(); i++ )
		{
			UStaticMeshComponent* Comp = Cast<UStaticMeshComponent>( AllComponentsInScene[ i ] );
			if( Comp && StaticMeshComp && Comp->GetStaticMesh() == StaticMeshComp->GetStaticMesh() )
			{
				TArray<UMaterialInterface*> Materials = Comp->GetMaterials();
				if( AreMaterialsUnique( Materials ) )
				{
					OutMaterials = Materials;
					break;
				}
			}
		}
	}

	MaterialBinding** MaterialsUsed = nullptr;
	MaterialsUsed = new MaterialBinding* [ NumMaterials ];
	for( int i = 0; i < NumMaterials; i++ )
		MaterialsUsed[ i ] = nullptr;

	UObject* LoadedObject = StaticLoadObject( UMaterialInterface::StaticClass(), nullptr, TEXT( "/Engine/EngineMaterials/DefaultMaterial" ) );
	UMaterialInterface* DefaultMaterial = Cast<UMaterialInterface>( LoadedObject );
	if( OutMaterials.Num() > 0 )
	{
		for( int i = 0; i < OutMaterials.Num(); i++ )
		{
			MaterialsUsed[ i ] = nullptr;
			if( !OutMaterials[ i ] )
			{
				OutMaterials[ i ] = DefaultMaterial;
			}
			MaterialsUsed[ i ] = ProcessMaterialReference( OutMaterials[ i ] );
		}
	}

	return MaterialsUsed;
}
FBoxSphereBounds GetBounds( const USkeletalMesh* SkeletalMesh )
{
	#if ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION < 26
		return ( (USkeletalMesh*)SkeletalMesh)->GetBounds();
	#else
		return SkeletalMesh->GetBounds();
	#endif
}
void ProcessMeshComponent( AActor* Actor, UStaticMeshComponent* StaticMeshComp, USkeletalMeshComponent* SkeletalMeshComponent, GameObject* ActorGO )
{
	const UStaticMesh* StaticMesh = nullptr;
	const USkeletalMesh* SkeletalMesh = nullptr;
	bool IsVisible = false;
	if( StaticMeshComp )
	{
		StaticMesh = StaticMeshComp->GetStaticMesh();
		//ShouldRender is more specific and includes visible layers, export what's actually shown in the editor
		IsVisible = StaticMeshComp->ShouldRender();//IsVisible()
	}
	if( SkeletalMeshComponent )
	{
		SkeletalMesh = GetSkeletalMesh( SkeletalMeshComponent );
		IsVisible = SkeletalMeshComponent->ShouldRender();
	}

	if( (StaticMeshComp && !StaticMesh ) || (SkeletalMeshComponent && !SkeletalMesh) || !IsVisible )
		return;

	if( !ExportMeshes )
		return;

	GameObject* ComponentGO = nullptr;
	int RelevantComponents = GetNumRelevantComponents( Actor );
	if( RelevantComponents <= 1 )
	{
		ComponentGO = ActorGO;
		ActorGO->CanBePrefab = true;
	}
	else
	{
		ComponentGO = new GameObject;
		ActorGO->AddChild( ComponentGO );
		ActorGO->OwnerScene->Add( ComponentGO );
	}
	FString CompNameStr = "";
	if( StaticMeshComp )
		CompNameStr = StaticMeshComp->GetName();
	if( SkeletalMeshComponent )
		CompNameStr = SkeletalMeshComponent->GetName();

	std::string CompName = ToANSIString( *CompNameStr );
	if( RelevantComponents > 1 )
		ComponentGO->Name = CompName;

	TransformComponent* ActorTransformComp = (TransformComponent*)ActorGO->GetComponent( CT_TRANSFORM );
	ActorTransformComp->Reset();

	TransformComponent* ComponentTransform = (TransformComponent*)ComponentGO->GetComponent( CT_TRANSFORM );

	FTransform ComponentTrans;
	if ( StaticMeshComp )
		ComponentTrans = StaticMeshComp->GetComponentTransform();
	if( SkeletalMeshComponent )
		ComponentTrans = SkeletalMeshComponent->GetComponentTransform();
	ConvertTransform( ComponentTrans, ComponentTransform, false );// true );

	const FStaticMeshRenderData* MeshRenderData = nullptr;
	FSkeletalMeshRenderData* SkeletalMeshRenderData = nullptr;
	int NumLods = 0;
	if( StaticMesh )
	{
		MeshRenderData = GetRenderData( (UStaticMesh*)StaticMesh );
		NumLods = MeshRenderData->LODResources.Num();
	}
	if( SkeletalMesh )
	{
		SkeletalMeshRenderData = SkeletalMesh->GetResourceForRendering();
		NumLods = SkeletalMeshRenderData->LODRenderData.Num();
	}

	if( !UTUSettings->ExportLODs )
	{
		NumLods = 1;
	}

	LodGroup* ComponentLodGroup = nullptr;
	if( NumLods > 1 && ( MeshRenderData  || SkeletalMeshRenderData ) )
	{
		ComponentLodGroup = (LodGroup*)ComponentGO->AddComponent( CT_LODGROUP );
	}

	UBodySetup* BodySetup = nullptr;
	if ( StaticMesh )
		BodySetup = GetBodySetup( StaticMesh );

	MeshCollider* NewMeshCollider = nullptr;
	if( BodySetup )
	{
		int ConvexHulls = BodySetup->AggGeom.ConvexElems.Num();
		int Spheres = BodySetup->AggGeom.SphereElems.Num();
		int Boxes = BodySetup->AggGeom.BoxElems.Num();
		int Capsules = BodySetup->AggGeom.SphylElems.Num();
		int TaperedCapsules = BodySetup->AggGeom.TaperedCapsuleElems.Num();
		int TotalShapes = ConvexHulls + Spheres + Boxes + Capsules + TaperedCapsules;

		if( TotalShapes > 0 )
		{
			FRotator RotatorForUnity = FRotator::MakeFromEuler( FVector( 90, 90, 0 ) );
			char Text[ 128 ];
			for( int i = 0; i < Boxes; i++ )
			{
				FKBoxElem& Box = BodySetup->AggGeom.BoxElems[ i ];

				GameObject* PrimitiveGO = ComponentGO;
				FVector Euler = Box.Rotation.Euler();
				bool NeedsTransform = false;

				FVector Center = Box.Center / 100.0f;

				Center = RotatorForUnity.RotateVector( Center );
				FVector SizeNoTransform = FVector( Box.X / 100.0f, Box.Y / 100.0f, Box.Z / 100.0f );
				SizeNoTransform = RotatorForUnity.RotateVector( SizeNoTransform );

				if( !Euler.IsNearlyZero() )
				{
					PrimitiveGO = new GameObject();
					ComponentGO->AddChild( PrimitiveGO );
					snprintf( Text, sizeof( Text ), "Box%d", i );
					PrimitiveGO->Name = Text;
					TransformComponent* TC = (TransformComponent*)PrimitiveGO->GetComponent( CT_TRANSFORM );

					FVector DefaultRotation = RotatorForUnity.Euler();
					FVector BoxEuler = Box.Rotation.Euler();
					FVector FinalEuler = DefaultRotation + FVector( BoxEuler.X, -BoxEuler.Z, BoxEuler.Y );
					auto FinalRotation = FRotator::MakeFromEuler( FinalEuler );

					TC->Set( Center, FinalRotation.Quaternion(), FVector( 1, 1, 1 ) );

					NeedsTransform = true;
				}

				BoxCollider* NewBoxCollider = (BoxCollider*)PrimitiveGO->AddComponent( CT_BOXCOLLIDER );
				NewBoxCollider->Size = FVector( Box.X / 100.0f, Box.Y / 100.0f, Box.Z / 100.0f );
				if( !NeedsTransform )
				{
					NewBoxCollider->Center = Center;
					ConvertScaleForUnity( NewBoxCollider->Size );
				}
				else
				{
					RotateForYUp( NewBoxCollider->Size );
					SwitchYWithZ( NewBoxCollider->Size );
				}
			}
			for( int i = 0; i < Spheres; i++ )
			{
				FKSphereElem& Sphere = BodySetup->AggGeom.SphereElems[ i ];

				SphereCollider* NewSphereCollider = (SphereCollider*)ComponentGO->AddComponent( CT_SPHERECOLLIDER );

				FVector Center = Sphere.Center / 100;
				Center = RotatorForUnity.RotateVector( Center );
				NewSphereCollider->Center = Center;
				NewSphereCollider->Radius = Sphere.Radius / 100.0f;
				//RotateForYUp( NewSphereCollider->Center );
			}
			for( int i = 0; i < Capsules; i++ )
			{
				FKSphylElem& Capsule = BodySetup->AggGeom.SphylElems[ i ];

				bool NeedsTransform = false;
				GameObject* PrimitiveGO = ComponentGO;
				FVector Center = Capsule.Center / 100.0f;
				FVector Euler = Capsule.Rotation.Euler();
				Center = RotatorForUnity.RotateVector( Center );
				if( !Euler.IsNearlyZero() )
				{
					PrimitiveGO = new GameObject();
					ComponentGO->AddChild( PrimitiveGO );
					snprintf( Text, sizeof( Text ), "Capsule%d", i );
					PrimitiveGO->Name = Text;
					TransformComponent* TC = (TransformComponent*)PrimitiveGO->GetComponent( CT_TRANSFORM );

					//FVector DefaultRotation = RotatorForUnity.Euler();
					FVector CapsuleEuler = Capsule.Rotation.Euler();
					FVector FinalEuler = FVector( CapsuleEuler.Z, CapsuleEuler.Y, -CapsuleEuler.X );// +FVector( 0, 270, 0 );
					//FinalEuler = FVector( FinalEuler.X, FinalEuler.Z, FinalEuler.Y );
					auto FinalRotation = FRotator::MakeFromEuler( FinalEuler );

					TC->Set( Center, FinalRotation.Quaternion(), FVector( 1, 1, 1 ) );

					NeedsTransform = true;
				}

				CapsuleCollider* NewCapsuleCollider = (CapsuleCollider*)PrimitiveGO->AddComponent( CT_CAPSULECOLLIDER );

				NewCapsuleCollider->Radius = Capsule.Radius / 100.0f;
				//Unity starts height at 0, Unreal starts with height=radius
				NewCapsuleCollider->Height = Capsule.Length / 100.0f + NewCapsuleCollider->Radius;
				NewCapsuleCollider->Direction = 1;

				if( !NeedsTransform )
				{
					NewCapsuleCollider->Center = Capsule.Center / 100.0f;
					RotateForYUp( NewCapsuleCollider->Center );
				}
			}
			if( ConvexHulls > 0 )
			{
				NewMeshCollider = (MeshCollider*)ComponentGO->AddComponent( CT_MESHCOLLIDER );
			}
		}
	}

	if( (MeshRenderData || SkeletalMeshRenderData ) && NumLods > 0 )
	{
		for( int i = 0; i < NumLods; i++ )
		{
			Renderer* LODMeshRenderer = ExportLOD( StaticMeshComp, SkeletalMeshComponent, ComponentGO, Actor, i, NumLods );
			if( ComponentLodGroup )
			{
				LOD* NewLOD = new LOD;
				if( i == NumLods - 1 )
				{
					if ( ComponentLodGroup->Lods.size() >= 1 )
					{
						NewLOD->screenRelativeTransitionHeight = ComponentLodGroup->Lods[ ComponentLodGroup->Lods.size() - 1]->screenRelativeTransitionHeight / 2.0f;
						NewLOD->screenRelativeTransitionHeight = FMath::Min( NewLOD->screenRelativeTransitionHeight, 0.05f );
					}
					else
						NewLOD->screenRelativeTransitionHeight = 0.01f;
				}
				else
				{
					float ScreenSize = 1.0;
					if ( MeshRenderData && i + 1 < MAX_STATIC_MESH_LODS )//Fix for a reported crash
						ScreenSize = MeshRenderData->ScreenSize[ i + 1 ].Default;
					NewLOD->screenRelativeTransitionHeight = FMath::Min( ScreenSize, 1.0f );
				}
				NewLOD->renderers.push_back( LODMeshRenderer );
				ComponentLodGroup->Lods.push_back( NewLOD );
				if( StaticMesh )
				{
					ComponentLodGroup->Size = StaticMesh->GetBounds().SphereRadius / 100.0f * 2;
					ComponentLodGroup->LocalReferencePoint = StaticMesh->GetBounds().Origin / 100.0f;
				}
				else if ( SkeletalMesh )
				{
					auto Bounds = GetBounds( SkeletalMesh );
					ComponentLodGroup->Size = Bounds.SphereRadius / 100.0f * 2;
					ComponentLodGroup->LocalReferencePoint = Bounds.Origin / 100.0f;
				}

				FRotator Rotator = FRotator::MakeFromEuler( FVector( 90, 90, 0 ) );//Rotate for Y Up
				ComponentLodGroup->LocalReferencePoint = Rotator.RotateVector( ComponentLodGroup->LocalReferencePoint );
			}
			if( NewMeshCollider && !NewMeshCollider->Mesh )
			{
				auto MF = (MeshFilter*)LODMeshRenderer->Owner->GetComponent( CT_MESHFILTER );
				if( MF && MF->Mesh )
				{					
					NewMeshCollider->Mesh = MF->Mesh;
					//It's always the last mesh
					if( NumLods > 1 )
						NewMeshCollider->SubMeshID = 4300000 + NumLods * 2;
					else
						NewMeshCollider->SubMeshID = 4300002 + NumLods * 2;

					MF->Mesh->HasConvexHulls = true;
					MF->Mesh->ConvexHullMeshID = NewMeshCollider->SubMeshID;
				}
			}

			if( !UTUSettings->ExportLODs )
				break;
		}
		
	}
}
UnityLightType GetUnityLightComponentType( ELightComponentType Type )
{
	if( UTUSettings->Engine == EngineType::UNITY )
	{
		switch( Type )
		{
			case LightType_Directional:return LT_DIRECTIONAL;
			default:
			case LightType_Point:return LT_POINT;
			case LightType_Spot: return LT_SPOT;
			case LightType_Rect: return LT_AREA;
		}
	}
	else //if ( UTUSettings->Engine == EngineType::GODOT )
	{
		switch( Type )
		{
			case LightType_Directional:return LT_DIRECTIONAL;
			default:
			case LightType_Rect :
			case LightType_Point:return LT_POINT;
			case LightType_Spot: return LT_SPOT;
		}
	}
}
float ConvertSpotAngle( float OuterConeAngle )
{
	float MaxUEAngle = 80;
	float MaxUnityAngle = 179;

	float AngleRatio = OuterConeAngle / MaxUEAngle;
	return AngleRatio * MaxUnityAngle;
}
void ConvertTransform( FTransform Trans, TransformComponent* Transform, bool IsRelative, bool HasDecals )
{
	FVector OriginalTranslation = Trans.GetTranslation();
	OriginalTranslation /= 100.0f;

	FVector Translation = OriginalTranslation;

	FQuat Quat = Trans.GetRotation();
	if( CVarFBXPerActor.GetValueOnAnyThread() == 1 )
	{
		if( UTUSettings->Engine == EngineType::UNITY )
		{
			FRotator Rotator = FRotator::MakeFromEuler( FVector( -90, 0, 90 ) );//fixes FBX preview angle
			Quat = Quat * Rotator.Quaternion();
		}
		else
		{
			FRotator Rotator = FRotator::MakeFromEuler( FVector( -90, 0, 0 ) );
			Quat = Quat * Rotator.Quaternion();
		}

		if( HasDecals )
		{
			FRotator DecalRotator = FRotator::MakeFromEuler( FVector( 0, 0, 90 ) );
			Quat = Quat * DecalRotator.Quaternion();
		}
	}
	else if( CVarAssetsWithYUp.GetValueOnAnyThread() == 1 )
	{
		FRotator Rotator = FRotator::MakeFromEuler( FVector( -90, 0, 0 ) );//works with OBJ
		Quat = Quat * Rotator.Quaternion();
	}
	FVector Scale = Trans.GetScale3D();

	if( CVarFBXPerActor.GetValueOnAnyThread() == 1 )
	{
		float Temp = 0;
		
		Temp = Scale.Y;
		Scale.Y = Scale.Z;
		Scale.Z = Temp;

		if( UTUSettings->Engine == EngineType::UNITY )
		{
			Temp = Scale.Z;
			Scale.Z = Scale.X;
			Scale.X = Temp;
		}

		if( HasDecals )
		{
			Temp = Scale.X;
			Scale.X = Scale.Y;
			Scale.Y = Temp;
		}
	}
	else if( CVarAssetsWithYUp.GetValueOnAnyThread() == 1 )
	{
		float Temp = Scale.Y;
		Scale.Y = Scale.Z;
		Scale.Z = Temp;
	}
	

	Transform->LocalPosition[ 0 ] = Translation.X;
	Transform->LocalPosition[ 1 ] = Translation.Y;
	Transform->LocalPosition[ 2 ] = Translation.Z;

	Transform->LocalRotation[ 0 ] = Quat.X;
	Transform->LocalRotation[ 1 ] = Quat.Y;
	Transform->LocalRotation[ 2 ] = Quat.Z;
	Transform->LocalRotation[ 3 ] = Quat.W;

	Transform->LocalScale[ 0 ] = Scale.X;
	Transform->LocalScale[ 1 ] = Scale.Y;
	Transform->LocalScale[ 2 ] = Scale.Z;

	if( IsRelative )
	{
		Transform->LocalPosition[ 0 ] *= -1;
	}
}

FVector SplineRotation( 90, 270, 0 );
float ClampTo1( float Val )
{
	if( Val > 1 )
		Val = 1.0f;
	
	return Val;
}
bool ActorHasDecals( AActor* A )
{
	TArray<UActorComponent*> comps;
	A->GetComponents( comps );
	for( int i = 0; i < comps.Num(); i++ )
	{
		UActorComponent* AC = comps[ i ];
		UDecalComponent* Decal = Cast<UDecalComponent>( AC );
		if( Decal )
		{
			return true;
		}
	}

	return false;
}
void ProcessActor( AActor *A, UnityScene* S)
{
	if ( !A )
		return;	

	TArray<UActorComponent*> comps;
	A->GetComponents( comps );

	FTransform Trans = A->GetTransform();	

	std::string ActorName = ToANSIString( *A->GetActorLabel() );
	
	GameObject *GO = new GameObject();
	S->Add( GO );

	GO->Name = ActorName;
	
	FQuat Quat = Trans.GetRotation();
	TransformComponent* Transform = (TransformComponent*)GO->GetComponent( CT_TRANSFORM );

	bool HasDecals = ActorHasDecals( A );
	ConvertTransform( Trans, Transform, false, HasDecals );
	for ( int i = 0; i < comps.Num(); i++ )
	{
		UActorComponent *AC = comps[ i ];
		ULightComponent *LightComp = dynamic_cast<ULightComponent*>( AC );
		if ( LightComp )
		{
			LightComponent* NewLightComponent = new LightComponent;
			
			TransformComponent* LightTransform = Transform;
			if( comps.Num() > 1 )
			{
				Transform->Reset();
				GameObject* ChildGO = new GameObject;
				ChildGO->Name = ToANSIString( *LightComp->GetName() );
				ChildGO->Components.push_back( NewLightComponent );
				NewLightComponent->Owner = ChildGO;
				LightTransform = (TransformComponent*)ChildGO->GetComponent( CT_TRANSFORM );
				
				FTransform ComponentTrans = LightComp->GetComponentTransform();
				ConvertTransform( ComponentTrans, LightTransform, false );

				GO->AddChild( ChildGO );
				GO->OwnerScene->Add( ChildGO );
			}
			else
			{
				NewLightComponent->Owner = GO;
				GO->Components.push_back( NewLightComponent );
			}
			AdditionalLightData* LightData = nullptr;
			if( UTUSettings->ScriptableRenderPipeline == RenderPipeline::RP_HDRP)// ||
				//UTUSettings->ScriptableRenderPipeline == RenderPipeline::RP_URP )
			{
				LightData = ( AdditionalLightData*)NewLightComponent->Owner->AddComponent( CT_ADDITIONAL_LIGHT_DATA );
				LightData->Light = NewLightComponent;
			}

			FQuat FixQuat( FVector( 0, 1, 0 ), PI / 2 );
			FQuat FinalQuat = Quat * FixQuat;
			LightTransform->LocalRotation[ 0 ] = FinalQuat.X;
			LightTransform->LocalRotation[ 1 ] = FinalQuat.Y;
			LightTransform->LocalRotation[ 2 ] = FinalQuat.Z;
			LightTransform->LocalRotation[ 3 ] = FinalQuat.W;

			ELightComponentType Type = LightComp->GetLightType();
			if( UTUSettings->Engine == EngineType::UNITY )
				TranslateLightDataForUnity( LightComp, NewLightComponent, LightData );
			#ifdef ENABLE_GODOT_EXPORT
			else if( UTUSettings->Engine == EngineType::GODOT)
				TranslateLightDataForGodot( LightComp, NewLightComponent );
			#endif

			NewLightComponent->Color = LightComp->LightColor;
			NewLightComponent->Type = GetUnityLightComponentType( Type );			
			NewLightComponent->Shadows = LightComp->CastShadows;			
			NewLightComponent->Enabled = LightComp->bAffectsWorld;
		}
		UCameraComponent* CameraComp = dynamic_cast<UCameraComponent*>( AC );
		if( CameraComp )
		{
			//if( UTUSettings->ScriptableRenderPipeline == RenderPipeline::RP_URP )
			//{
			//	LightData = (AdditionalLightData*)NewLightComponent->Owner->AddComponent( CT_ADDITIONAL_CAMERA_DATA );
			//	//LightData->Camera = NewLightComponent;
			//}
		}
		UInstancedStaticMeshComponent* InstancedMeshComp = Cast<UInstancedStaticMeshComponent>( AC );
		//Continue because I already spawned the instances as individual actors
		if( InstancedMeshComp )
			continue;
		USkeletalMeshComponent *SkelMeshComp = dynamic_cast<USkeletalMeshComponent*>( AC );		
		if ( SkelMeshComp )
		{
			ProcessMeshComponent( A, nullptr, SkelMeshComp, GO );
		}		
		USplineMeshComponent* SplineMeshComponent = Cast<USplineMeshComponent>( AC );
		if( SplineMeshComponent )
		{
			//auto Pos = SplineMeshComponent->SplineParams.StartPos;
			//FVector SplineExtents = SplineMeshComponent->SplineParams.EndPos - SplineMeshComponent->SplineParams.StartPos;			
			//UStaticMesh* StaticMesh = SplineMeshComponent->GetStaticMesh();
			//if( StaticMesh )
			//{
			//	auto MeshBounds = StaticMesh->GetBounds();
			//	FVector MeshSizes = MeshBounds.BoxExtent * 2;
			//	if( FMath::IsNearlyZero( SplineExtents.X, 1.0f ) )
			//		SplineExtents.X = MeshSizes.X;
			//	if( FMath::IsNearlyZero( SplineExtents.Y, 1.0f ) )
			//		SplineExtents.Y = MeshSizes.Y;
			//	if( FMath::IsNearlyZero( SplineExtents.Z, 1.0f ) )
			//		SplineExtents.Z = MeshSizes.Z;
			//
			//	//Scale based on Z up, needs fixing
			//	FVector Scale = SplineExtents / MeshSizes;
			//	//auto Average = (SplineMeshComponent->SplineParams.StartPos + SplineMeshComponent->SplineParams.EndPos)/2;
			//
			//	FTransform& CompTransform = (FTransform&)SplineMeshComponent->GetComponentToWorld();
			//	CompTransform.SetLocation( Pos );
			//	//rotate from UE to Unity space
			//	FRotator Rotator = FRotator::MakeFromEuler( SplineRotation );
			//	CompTransform.SetRotation( FQuat( Rotator ));
			//	CompTransform.SetScale3D( Scale );
			//}
		}
		UStaticMeshComponent *StaticMeshComp = dynamic_cast<UStaticMeshComponent*>( AC );
		if ( StaticMeshComp )
		{	
			ProcessMeshComponent( A, StaticMeshComp, nullptr, GO );
		}
		USplineComponent* SplineComponent = Cast<USplineComponent>( AC );
		if( SplineComponent )
		{
			int32 Points = SplineComponent->GetNumberOfSplinePoints();
		}
		USphereReflectionCaptureComponent* SphereReflection = Cast<USphereReflectionCaptureComponent>( AC );
		if( SphereReflection )
		{
			float Influence = SphereReflection->InfluenceRadius / 100.0f;
			ReflectionProbeComponent* NewReflectionProbeComponent = ( ReflectionProbeComponent*)GO->AddComponent( CT_REFLECTIONPROBE );
			NewReflectionProbeComponent->Intensity = 1.0f;// SphereReflection->Brightness;
			NewReflectionProbeComponent->Size = FVector( Influence, Influence, Influence );
		}
		UBoxReflectionCaptureComponent* BoxReflection = Cast<UBoxReflectionCaptureComponent>( AC );
		if( BoxReflection )
		{
			FTransform BoxTransform = BoxReflection->GetComponentTransform();
			ReflectionProbeComponent* NewReflectionProbeComponent = (ReflectionProbeComponent*)GO->AddComponent( CT_REFLECTIONPROBE );
			NewReflectionProbeComponent->Intensity = 1.0f;// BoxReflection->Brightness;
			//Also convert to cm
			NewReflectionProbeComponent->Size = BoxTransform.GetScale3D() / 100.0f;
		}
		UDecalComponent* Decal = Cast<UDecalComponent>( AC );
		if( Decal && ( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_URP ||
					   CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP ) )
		{
			DecalComponent* NewDecalComponent = (DecalComponent*)GO->AddComponent( CT_DECAL );

			UMaterialInterface* DecalMat = Decal->GetDecalMaterial();
			if( DecalMat )
			{
				MaterialBinding* Binding = ProcessMaterialReference( DecalMat );
				NewDecalComponent->Material = Binding->UnityMat;
				NewDecalComponent->Material->DecalDrawOrder = Decal->SortOrder;
				NewDecalComponent->Size = Decal->DecalSize;
				NewDecalComponent->Size /= 100.0f;
				if ( UTUSettings->Engine == EngineType::UNITY )
					NewDecalComponent->Size *= 2.0f;
				NewDecalComponent->DrawOrder = Decal->SortOrder;
				ConvertScaleForUnity( NewDecalComponent->Size );
				//TODO depending on rotation Size.X needs to be swapped with Size.Y
				
				if( UTUSettings->Engine == EngineType::UNITY )
				{
					float Temp = NewDecalComponent->Size.X;
					NewDecalComponent->Size.X = NewDecalComponent->Size.Y;
					NewDecalComponent->Size.Y = Temp;
				}
				else if( UTUSettings->Engine == EngineType::GODOT )
				{
					float Temp = NewDecalComponent->Size.Y;
					NewDecalComponent->Size.Y = NewDecalComponent->Size.Z;
					NewDecalComponent->Size.Z = Temp;

					Temp = NewDecalComponent->Size.X;
					NewDecalComponent->Size.X = NewDecalComponent->Size.Z;
					NewDecalComponent->Size.Z = Temp;
				}
			}
		}
	}

	S->EvaluatePrefab( GO );
}

bool VerifyOrCreateDirectory( const FString& TestDir )
{
	//Directory Exists?
	if ( !FPlatformFileManager::Get().GetPlatformFile().DirectoryExists( *TestDir ) )
	{
		FPlatformFileManager::Get().GetPlatformFile().CreateDirectory( *TestDir );

		if ( !FPlatformFileManager::Get().GetPlatformFile().DirectoryExists( *TestDir ) )
		{
			return false;
		}
	}
	return true;
}

bool SaveFile( const char *File, void *data, int64_t size )
{
	FILE *f = nullptr;
	if( File && strcmp( File, "" ) != 0 )
		f = fopen( File, "wb" );

	if( !f )
		return false;

	fwrite( data, sizeof( char ), (int)size, f );
	fclose( f );
	return true;
}
int64_t GetFileSize( const char *FileName )
{
	if( !FileName || !FileName[ 0 ] )
		return -1;
	int64_t size = 0;
	FILE* f = nullptr;
	f = fopen( FileName, "rb" );
	if( !f )
		return -1;

	fseek( f, 0, SEEK_END );
	size = ftell( f );

	if( size == -1 )
	{
		//RELog( "The file may be over 2GB, use _ftelli64 !" );
		size = _ftelli64( f );

	}
	fclose( f );
	return size;
}
int64_t LoadFile( const char *File, uint8** data )
{
	if( !File || !data || File[ 0 ] == 0 )
		return -1;

	int64_t size = 0;
	size = GetFileSize( File );

	FILE *f = nullptr;
	f = fopen( File, "rb" );
	if( !f )
	{
		int Ret = -1;	
		return Ret;
	}

	//Add '0' character (if presumed to be acting like a string)
	//might impply allocation errors ?
	*data = new uint8[ (size_t)size + 1 ];
	if( !( *data ) )
	{
		//RELog( "LoadFile Allocation Error" );
		return -1;
	}
	( *data )[ size ] = 0;//last character should be 0 in case it's a string

	size_t BytesRead = fread( *data, sizeof( uint8 ), size, f );
	fclose( f );
	if( BytesRead == 0 )
	{
		BytesRead = 0;
	}
	return BytesRead;
}

#include <atomic>

UWorld *CurrentWorld = nullptr;

std::atomic<int> ProcessingState;
void RenderThreadExport()
{
	ProcessAllMaterials();

	ProcessingState = 1;
}

class RenderThreadTaskInitializer
{
public:
	void QueCommand(  bool UseSync = false )
	{
		if( UseSync )
		{
			RenderThreadExport();
		}
		else
		{
			RenderThreadTaskInitializer* This = this;
			ENQUEUE_RENDER_COMMAND( Command_RenderThreadExport )(
				[This]( FRHICommandListImmediate& RHICmdList )
			{
				RenderThreadExport();
			} );
		}
	}
};
class UICallback
{
public:
	virtual void AddToolbarExtension()
	{

	}
};
RenderThreadTaskInitializer *RTTI = new RenderThreadTaskInitializer;

#endif

UnityScene* AllocateScene()
{
	return new UnityScene;
}

#include "Editor/UnrealEd/Private/FbxExporter.h"
#include "Editor/UnrealEd/Classes/Exporters/FbxExportOption.h"
#include "Misc/FeedbackContext.h"
#include "Camera/CameraActor.h"
#include "Camera/CameraComponent.h"
#include "Engine/Light.h"
#include "Runtime/Engine/Classes/Materials/MaterialExpressionVectorParameter.h"
#include "Runtime/Engine/Classes/Materials/MaterialExpressionConstant3Vector.h"
#include "Runtime/Engine/Classes/Materials/MaterialExpressionConstant2Vector.h"
#include "Runtime/Engine/Public/Rendering/SkeletalMeshModel.h"
#include "Runtime/CoreUObject/Public/UObject/Metadata.h"

using namespace UnFbx;
using namespace fbxsdk;

FbxManager* SdkManager = nullptr;
FbxAnimStack* AnimStack = nullptr;
FbxAnimLayer* AnimLayer = nullptr;
FbxCamera* DefaultCamera = nullptr;
//FbxScene* TheScene = nullptr;
bool bSceneGlobalTimeLineSet = false;
bool bKeepHierarchy = true;

TMap<FString, int32> FbxNodeNameToIndexMap;
TMap<const AActor*, FbxNode*> FbxActors;
TMap<const USkeletalMeshComponent*, FbxNode*> FbxSkeletonRoots;
TMap<const UMaterialInterface*, FbxSurfaceMaterial*> FbxMaterials;
TMap<const UStaticMesh*, FbxMesh*> FbxMeshes;
TMap<const UStaticMesh*, FbxMesh*> FbxCollisionMeshes;
FFbxDataConverter Converter;
void DetermineVertsToWeld( TArray<int32>& VertRemap, TArray<int32>& UniqueVerts, const FStaticMeshLODResources& RenderMesh )
{
	const int32 VertexCount = RenderMesh.VertexBuffers.StaticMeshVertexBuffer.GetNumVertices();

	// Maps unreal verts to reduced list of verts 
	VertRemap.Empty( VertexCount );
	VertRemap.AddUninitialized( VertexCount );

	// List of Unreal Verts to keep
	UniqueVerts.Empty( VertexCount );

	// Combine matching verts using hashed search to maintain good performance
	TMap<FVector, int32> HashedVerts;
	for( int32 a = 0; a < VertexCount; a++ )
	{
		const FVector& PositionA = (FVector&)RenderMesh.VertexBuffers.PositionVertexBuffer.VertexPosition( a );
		const int32* FoundIndex = HashedVerts.Find( PositionA );
		if( !FoundIndex )
		{
			int32 NewIndex = UniqueVerts.Add( a );
			VertRemap[ a ] = NewIndex;
			HashedVerts.Add( PositionA, NewIndex );
		}
		else
		{
			VertRemap[ a ] = *FoundIndex;
		}
	}
}
void DetermineUVsToWeld( TArray<int32>& VertRemap, TArray<int32>& UniqueVerts, const FStaticMeshVertexBuffer& VertexBuffer, int32 TexCoordSourceIndex )
{
	const int32 VertexCount = VertexBuffer.GetNumVertices();

	// Maps unreal verts to reduced list of verts
	VertRemap.Empty( VertexCount );
	VertRemap.AddUninitialized( VertexCount );

	// List of Unreal Verts to keep
	UniqueVerts.Empty( VertexCount );

	// Combine matching verts using hashed search to maintain good performance
	#if ENGINE_MAJOR_VERSION == 4
		TMap<FVector2D, int32> HashedVerts;
	#else
		TMap<FVector2f, int32> HashedVerts;
	#endif
	for( int32 Vertex = 0; Vertex < VertexCount; Vertex++ )
	{
		#if ENGINE_MAJOR_VERSION == 4
			const FVector2D& PositionA = VertexBuffer.GetVertexUV( Vertex, TexCoordSourceIndex );
		#else
			const FVector2f& PositionA = VertexBuffer.GetVertexUV( Vertex, TexCoordSourceIndex );
		#endif
		const int32* FoundIndex = HashedVerts.Find( PositionA );
		if( !FoundIndex )
		{
			int32 NewIndex = UniqueVerts.Add( Vertex );
			VertRemap[ Vertex ] = NewIndex;
			HashedVerts.Add( PositionA, NewIndex );
		}
		else
		{
			VertRemap[ Vertex ] = *FoundIndex;
		}
	}
}
FbxDouble3 SetMaterialComponent( FColorMaterialInput& MatInput, bool ToLinear )
{
	FColor RGBColor;
	FLinearColor LinearColor;
	bool LinearSet = false;

	if( MatInput.Expression )
	{
		if( Cast<UMaterialExpressionConstant>( MatInput.Expression ) )
		{
			UMaterialExpressionConstant* Expr = Cast<UMaterialExpressionConstant>( MatInput.Expression );
			RGBColor = FColor( Expr->R );
		}
		else if( Cast<UMaterialExpressionVectorParameter>( MatInput.Expression ) )
		{
			UMaterialExpressionVectorParameter* Expr = Cast<UMaterialExpressionVectorParameter>( MatInput.Expression );
			LinearColor = Expr->DefaultValue;
			LinearSet = true;
			//Linear to sRGB color space conversion
			RGBColor = Expr->DefaultValue.ToFColor( true );
		}
		else if( Cast<UMaterialExpressionConstant3Vector>( MatInput.Expression ) )
		{
			UMaterialExpressionConstant3Vector* Expr = Cast<UMaterialExpressionConstant3Vector>( MatInput.Expression );
			RGBColor.R = Expr->Constant.R;
			RGBColor.G = Expr->Constant.G;
			RGBColor.B = Expr->Constant.B;
		}
		else if( Cast<UMaterialExpressionConstant4Vector>( MatInput.Expression ) )
		{
			UMaterialExpressionConstant4Vector* Expr = Cast<UMaterialExpressionConstant4Vector>( MatInput.Expression );
			RGBColor.R = Expr->Constant.R;
			RGBColor.G = Expr->Constant.G;
			RGBColor.B = Expr->Constant.B;
			//RGBColor.A = Expr->A;
		}
		else if( Cast<UMaterialExpressionConstant2Vector>( MatInput.Expression ) )
		{
			UMaterialExpressionConstant2Vector* Expr = Cast<UMaterialExpressionConstant2Vector>( MatInput.Expression );
			RGBColor.R = Expr->R;
			RGBColor.G = Expr->G;
			RGBColor.B = 0;
		}
		else
		{
			RGBColor.R = MatInput.Constant.R;
			RGBColor.G = MatInput.Constant.G;
			RGBColor.B = MatInput.Constant.B;
		}
	}
	else
	{
		RGBColor.R = MatInput.Constant.R;
		RGBColor.G = MatInput.Constant.G;
		RGBColor.B = MatInput.Constant.B;
	}

	if( ToLinear )
	{
		if( !LinearSet )
		{
			//sRGB to linear color space conversion
			LinearColor = FLinearColor( RGBColor );
		}
		return FbxDouble3( LinearColor.R, LinearColor.G, LinearColor.B );
	}
	return FbxDouble3( RGBColor.R, RGBColor.G, RGBColor.B );
}
bool FillFbxTextureProperty( const char* PropertyName, const FExpressionInput& MaterialInput, FbxSurfaceMaterial* FbxMaterial, FbxScene* FBXScene )
{
	if( FBXScene == NULL )
	{
		return false;
	}

	FbxProperty FbxColorProperty = FbxMaterial->FindProperty( PropertyName );
	if( FbxColorProperty.IsValid() )
	{
		if( MaterialInput.IsConnected() && MaterialInput.Expression )
		{
			if( MaterialInput.Expression->IsA( UMaterialExpressionTextureSample::StaticClass() ) )
			{
				UMaterialExpressionTextureSample* TextureSample = Cast<UMaterialExpressionTextureSample>( MaterialInput.Expression );
				if( TextureSample && TextureSample->Texture && TextureSample->Texture->AssetImportData )
				{
					FString TextureSourceFullPath = TextureSample->Texture->AssetImportData->GetFirstFilename();
					//Create a fbx property
					FbxFileTexture* lTexture = FbxFileTexture::Create( FBXScene, "EnvSamplerTex" );
					lTexture->SetFileName( TCHAR_TO_UTF8( *TextureSourceFullPath ) );
					lTexture->SetTextureUse( FbxTexture::eStandard );
					lTexture->SetMappingType( FbxTexture::eUV );
					lTexture->ConnectDstProperty( FbxColorProperty );
					return true;
				}
			}
		}
	}
	return false;
}
FbxSurfaceMaterial* CreateDefaultMaterial(FbxScene* FBXScene )
{
	// TODO(sbc): the below cast is needed to avoid clang warning.  The upstream
	// signature in FBX should really use 'const char *'.
	FbxSurfaceMaterial* FbxMaterial = FBXScene->GetMaterial( const_cast<char*>( "Fbx Default Material" ) );

	if( !FbxMaterial )
	{
		FbxMaterial = FbxSurfaceLambert::Create( FBXScene, "Fbx Default Material" );
		( (FbxSurfaceLambert*)FbxMaterial )->Diffuse.Set( FbxDouble3( 0.72, 0.72, 0.72 ) );
	}

	return FbxMaterial;
}
bool SetFBXTextureProperty( FbxSurfaceMaterial* FbxMaterial, FString TextureName, FString TextureSourceFullPath, const char* FbxPropertyName, FbxScene* InScene)
{
	FbxProperty FbxColorProperty = FbxMaterial->FindProperty( FbxPropertyName );
	if( FbxColorProperty.IsValid() )
	{
		if( !TextureSourceFullPath.IsEmpty() )
		{
			//Create a fbx property
			FbxFileTexture* lTexture = FbxFileTexture::Create( InScene, TCHAR_TO_UTF8( *TextureName ) );
			lTexture->SetFileName( TCHAR_TO_UTF8( *TextureSourceFullPath ) );
			lTexture->SetTextureUse( FbxTexture::eStandard );
			lTexture->SetMappingType( FbxTexture::eUV );
			lTexture->ConnectDstProperty( FbxColorProperty );
			return true;
		}
	}
	return false;
};
FbxSurfaceMaterial* ExportMaterial_UTU( UMaterialInterface* MaterialInterface, MaterialBinding* Binding, FbxScene* FBXScene )
{
	if( FBXScene == nullptr || MaterialInterface == nullptr || MaterialInterface->GetMaterial() == nullptr ) return nullptr;

	// Verify that this material has not already been exported:
	if( FbxMaterials.Find( MaterialInterface ) )
	{
		return *FbxMaterials.Find( MaterialInterface );
	}

	// Create the Fbx material
	FbxSurfaceMaterial* FbxMaterial = nullptr;

	UMaterial* Material = MaterialInterface->GetMaterial();
	if( !Material )
	{
		//Nothing to export
		return nullptr;
	}

	// Set the shading model
	if( HasOnlyShadingModel( Material, MSM_DefaultLit ) )
	{
		FbxMaterial = FbxSurfacePhong::Create( FBXScene, TCHAR_TO_UTF8( *MaterialInterface->GetName() ) );
		//((FbxSurfacePhong*)FbxMaterial)->Specular.Set(Material->Specular));
		//((FbxSurfacePhong*)FbxMaterial)->Shininess.Set(Material->SpecularPower.Constant);
	}
	else // if (Material->ShadingModel == MSM_Unlit)
	{
		FbxMaterial = FbxSurfaceLambert::Create( FBXScene, TCHAR_TO_UTF8( *MaterialInterface->GetName() ) );
	}

	for( int i = 0; i < Binding->UnityMat->Textures.size(); i++ )
	{
		UnityTexture* Tex = Binding->UnityMat->Textures[ i ];
		switch( Tex->Semantic )
		{
			case TS_MainTex			:
			case TS_BaseMap			:SetFBXTextureProperty( FbxMaterial, Binding->GenerateName(), Tex->File.c_str(), FbxSurfaceMaterial::sDiffuse, FBXScene ); break;
			case TS_BumpMap			:SetFBXTextureProperty( FbxMaterial, Binding->GenerateName(), Tex->File.c_str(), FbxSurfaceMaterial::sNormalMap, FBXScene ); break;
			//case TS_DetailAlbedoMap	:SetFBXTextureProperty( FbxMaterial, Binding->GenerateName(), Tex->File.c_str(), FbxSurfaceMaterial::sDiffuse, TheScene ); break;
			//case TS_DetailMask		:SetFBXTextureProperty( FbxMaterial, Binding->GenerateName(), Tex->File.c_str(), FbxSurfaceMaterial::sDiffuse, TheScene ); break;
			//case TS_DetailNormalMap	:SetFBXTextureProperty( FbxMaterial, Binding->GenerateName(), Tex->File.c_str(), FbxSurfaceMaterial::sDiffuse, TheScene ); break;
			case TS_EmissionMap		:SetFBXTextureProperty( FbxMaterial, Binding->GenerateName(), Tex->File.c_str(), FbxSurfaceMaterial::sEmissive, FBXScene ); break;
			//case TS_MetallicGlossMap:SetFBXTextureProperty( FbxMaterial, Binding->GenerateName(), Tex->File.c_str(), FbxSurfaceMaterial::sDiffuse, TheScene ); break;
			//case TS_OcclusionMap	:SetFBXTextureProperty( FbxMaterial, Binding->GenerateName(), Tex->File.c_str(), FbxSurfaceMaterial::sDiffuse, TheScene ); break;
			//case TS_ParallaxMap		:SetFBXTextureProperty( FbxMaterial, Binding->GenerateName(), Tex->File.c_str(), FbxSurfaceMaterial::sDiffuse, TheScene ); break;
			//case TS_SpecGlossMap	:SetFBXTextureProperty( FbxMaterial, Binding->GenerateName(), Tex->File.c_str(), FbxSurfaceMaterial::sDiffuse, TheScene ); break;
		}
	}

	FbxMaterials.Add( MaterialInterface, FbxMaterial );

	return FbxMaterial;
}
FbxSurfaceMaterial* ExportMaterial( UMaterialInterface* MaterialInterface, FbxScene* FBXScene)
{
	if( FBXScene == nullptr || MaterialInterface == nullptr || MaterialInterface->GetMaterial() == nullptr ) return nullptr;

	// Verify that this material has not already been exported:
	if( FbxMaterials.Find( MaterialInterface ) )
	{
		return *FbxMaterials.Find( MaterialInterface );
	}

	// Create the Fbx material
	FbxSurfaceMaterial* FbxMaterial = nullptr;

	UMaterial* Material = MaterialInterface->GetMaterial();
	if( !Material )
	{
		//Nothing to export
		return nullptr;
	}

	// Set the shading model
	if( HasOnlyShadingModel( Material, MSM_DefaultLit ) )
	{
		FbxMaterial = FbxSurfacePhong::Create( FBXScene, TCHAR_TO_UTF8( *MaterialInterface->GetName() ) );
		//((FbxSurfacePhong*)FbxMaterial)->Specular.Set(Material->Specular));
		//((FbxSurfacePhong*)FbxMaterial)->Shininess.Set(Material->SpecularPower.Constant);
	}
	else // if (Material->ShadingModel == MSM_Unlit)
	{
		FbxMaterial = FbxSurfaceLambert::Create( FBXScene, TCHAR_TO_UTF8( *MaterialInterface->GetName() ) );
	}


	//Get the base material connected expression parameter name for all the supported fbx material exported properties
	//We only support material input where the connected expression is a parameter of type (constant, scalar, vector, texture, TODO virtual texture)

	FName BaseColorParamName = ( !GetBaseColor(Material)->UseConstant && GetBaseColor( Material )->Expression ) ? GetBaseColor( Material )->Expression->GetParameterName() : NAME_None;
	bool BaseColorParamSet = false;
	FName EmissiveParamName = ( !GetEmissiveColor(Material)->UseConstant && GetEmissiveColor( Material )->Expression ) ? GetEmissiveColor( Material )->Expression->GetParameterName() : NAME_None;
	bool EmissiveParamSet = false;
	FName NormalParamName = GetNormal( Material )->Expression ? GetNormal( Material )->Expression->GetParameterName() : NAME_None;
	bool NormalParamSet = false;
	FName OpacityParamName = ( !GetOpacity(Material )->UseConstant && GetOpacity( Material )->Expression ) ? GetOpacity( Material )->Expression->GetParameterName() : NAME_None;
	bool OpacityParamSet = false;
	FName OpacityMaskParamName = ( !GetOpacityMask( Material )->UseConstant && GetOpacityMask( Material )->Expression ) ? GetOpacityMask( Material )->Expression->GetParameterName() : NAME_None;
	bool OpacityMaskParamSet = false;

	UMaterialInstance* MaterialInstance = Cast<UMaterialInstance>( MaterialInterface );
	EBlendMode BlendMode = MaterialInstance != nullptr && MaterialInstance->BasePropertyOverrides.bOverride_BlendMode ? MaterialInstance->BasePropertyOverrides.BlendMode : Material->BlendMode;

	// Loop through all types of parameters for this base material and add the supported one to the fbx material.
	//The order is important we search Texture, Vector, Scalar.

	TArray<FMaterialParameterInfo> ParameterInfos;
	TArray<FGuid> Guids;
	//Query all base material texture parameters.
	Material->GetAllTextureParameterInfo( ParameterInfos, Guids );
	for( int32 ParameterIdx = 0; ParameterIdx < ParameterInfos.Num(); ParameterIdx++ )
	{
		const FMaterialParameterInfo& ParameterInfo = ParameterInfos[ ParameterIdx ];
		FName ParameterName = ParameterInfo.Name;
		UTexture* Value;
		//Query the material instance parameter overridden value
		if( MaterialInterface->GetTextureParameterValue( ParameterInfo, Value ) && Value && Value->AssetImportData )
		{
			//This lambda extract the source file path and create the fbx file texture node and connect it to the fbx material
			auto SetTextureProperty = [&FbxMaterial, &Value]( const char* FbxPropertyName, FbxScene* InScene )->bool
			{
				FbxProperty FbxColorProperty = FbxMaterial->FindProperty( FbxPropertyName );
				if( FbxColorProperty.IsValid() )
				{
					const FString TextureName = Value->GetName();
					const FString TextureSourceFullPath = Value->AssetImportData->GetFirstFilename();
					if( !TextureSourceFullPath.IsEmpty() )
					{
						//Create a fbx property
						FbxFileTexture* lTexture = FbxFileTexture::Create( InScene, TCHAR_TO_UTF8( *TextureName ) );
						lTexture->SetFileName( TCHAR_TO_UTF8( *TextureSourceFullPath ) );
						lTexture->SetTextureUse( FbxTexture::eStandard );
						lTexture->SetMappingType( FbxTexture::eUV );
						lTexture->ConnectDstProperty( FbxColorProperty );
						return true;
					}
				}
				return false;
			};

			if( BaseColorParamName != NAME_None && ParameterName == BaseColorParamName )
			{
				BaseColorParamSet = SetTextureProperty( FbxSurfaceMaterial::sDiffuse, FBXScene );
			}
			if( EmissiveParamName != NAME_None && ParameterName == EmissiveParamName )
			{
				EmissiveParamSet = SetTextureProperty( FbxSurfaceMaterial::sEmissive, FBXScene );
			}

			if( BlendMode == BLEND_Translucent )
			{
				if( OpacityParamName != NAME_None && ParameterName == OpacityParamName )
				{
					OpacityParamSet = SetTextureProperty( FbxSurfaceMaterial::sTransparentColor, FBXScene );
				}
				if( OpacityMaskParamName != NAME_None && ParameterName == OpacityMaskParamName )
				{
					OpacityMaskParamSet = SetTextureProperty( FbxSurfaceMaterial::sTransparencyFactor, FBXScene );
				}
			}
			else
			{
				//There is no normal input in Blend translucent mode
				if( NormalParamName != NAME_None && ParameterName == NormalParamName )
				{
					NormalParamSet = SetTextureProperty( FbxSurfaceMaterial::sNormalMap, FBXScene );
				}
			}
		}
	}

	Material->GetAllVectorParameterInfo( ParameterInfos, Guids );
	//Query all base material vector parameters.
	for( int32 ParameterIdx = 0; ParameterIdx < ParameterInfos.Num(); ParameterIdx++ )
	{
		const FMaterialParameterInfo& ParameterInfo = ParameterInfos[ ParameterIdx ];
		FName ParameterName = ParameterInfo.Name;
		FLinearColor LinearColor;
		//Query the material instance parameter overridden value
		if( MaterialInterface->GetVectorParameterValue( ParameterInfo, LinearColor ) )
		{
			FbxDouble3 LinearFbxValue( LinearColor.R, LinearColor.G, LinearColor.B );
			if( !BaseColorParamSet && BaseColorParamName != NAME_None && ParameterName == BaseColorParamName )
			{
				( (FbxSurfaceLambert*)FbxMaterial )->Diffuse.Set( LinearFbxValue );
				BaseColorParamSet = true;
			}
			if( !EmissiveParamSet && EmissiveParamName != NAME_None && ParameterName == EmissiveParamName )
			{
				( (FbxSurfaceLambert*)FbxMaterial )->Emissive.Set( LinearFbxValue );
				EmissiveParamSet = true;
			}
		}
	}

	//Query all base material scalar parameters.
	Material->GetAllScalarParameterInfo( ParameterInfos, Guids );
	for( int32 ParameterIdx = 0; ParameterIdx < ParameterInfos.Num(); ParameterIdx++ )
	{
		const FMaterialParameterInfo& ParameterInfo = ParameterInfos[ ParameterIdx ];
		FName ParameterName = ParameterInfo.Name;
		float Value;
		//Query the material instance parameter overridden value
		if( MaterialInterface->GetScalarParameterValue( ParameterInfo, Value ) )
		{
			FbxDouble FbxValue = (FbxDouble)Value;
			FbxDouble3 FbxVector( FbxValue, FbxValue, FbxValue );
			if( !BaseColorParamSet && BaseColorParamName != NAME_None && ParameterName == BaseColorParamName )
			{
				( (FbxSurfaceLambert*)FbxMaterial )->Diffuse.Set( FbxVector );
				BaseColorParamSet = true;
			}
			if( !EmissiveParamSet && EmissiveParamName != NAME_None && ParameterName == EmissiveParamName )
			{
				( (FbxSurfaceLambert*)FbxMaterial )->Emissive.Set( FbxVector );
				EmissiveParamSet = true;
			}
			if( BlendMode == BLEND_Translucent )
			{
				if( !OpacityParamSet && OpacityParamName != NAME_None && ParameterName == OpacityParamName )
				{
					( (FbxSurfaceLambert*)FbxMaterial )->TransparentColor.Set( FbxVector );
					OpacityParamSet = true;
				}

				if( !OpacityMaskParamSet && OpacityMaskParamName != NAME_None && ParameterName == OpacityMaskParamName )
				{
					( (FbxSurfaceLambert*)FbxMaterial )->TransparencyFactor.Set( FbxValue );
					OpacityMaskParamSet = true;
				}
			}
		}
	}

	//TODO: export virtual texture to fbx
	//Query all base material runtime virtual texture parameters.
// 	Material->GetAllRuntimeVirtualTextureParameterInfo(ParameterInfos, Guids);
// 	for (int32 ParameterIdx = 0; ParameterIdx < ParameterInfos.Num(); ParameterIdx++)
// 	{
// 		const FMaterialParameterInfo& ParameterInfo = ParameterInfos[ParameterIdx];
// 		FName ParameterName = ParameterInfo.Name;
// 		URuntimeVirtualTexture* Value;
//		//Query the material instance parameter overridden value
// 		if (MaterialInterface->GetRuntimeVirtualTextureParameterValue(ParameterInfo, Value, bOveriddenOnly))
// 		{
// 		}
// 	}

	//
	//In case there is no material instance override, we extract the value from the base material
	//

	//The OpacityMaskParam set the transparency factor, so set it only if it was not set
	if( !OpacityMaskParamSet )
	{
		( (FbxSurfaceLambert*)FbxMaterial )->TransparencyFactor.Set( GetOpacity(Material)->Constant );
	}

	// Fill in the profile_COMMON effect with the material information.
	//Fill the texture or constant
	if( !BaseColorParamSet )
	{
		if( !FillFbxTextureProperty( FbxSurfaceMaterial::sDiffuse, *GetBaseColor(Material), FbxMaterial, FBXScene ) )
		{
			( (FbxSurfaceLambert*)FbxMaterial )->Diffuse.Set( SetMaterialComponent( *GetBaseColor(Material), true ) );
		}
	}

	if( !EmissiveParamSet )
	{
		if( !FillFbxTextureProperty( FbxSurfaceMaterial::sEmissive, *GetEmissiveColor(Material), FbxMaterial, FBXScene ) )
		{
			( (FbxSurfaceLambert*)FbxMaterial )->Emissive.Set( SetMaterialComponent( *GetEmissiveColor( Material ), true ) );
		}
	}

	//Always set the ambient to zero since we dont have ambient in unreal we want to avoid default value in DCCs
	( (FbxSurfaceLambert*)FbxMaterial )->Ambient.Set( FbxDouble3( 0.0, 0.0, 0.0 ) );

	if( BlendMode == BLEND_Translucent )
	{
		if( !OpacityParamSet )
		{
			if( !FillFbxTextureProperty( FbxSurfaceMaterial::sTransparentColor, *GetOpacity(Material), FbxMaterial, FBXScene ) )
			{
				FbxDouble3 OpacityValue( (FbxDouble)( GetOpacity(Material)->Constant ), (FbxDouble)( GetOpacity(Material)->Constant ), (FbxDouble)( GetOpacity(Material)->Constant ) );
				( (FbxSurfaceLambert*)FbxMaterial )->TransparentColor.Set( OpacityValue );
			}
		}

		if( !OpacityMaskParamSet )
		{
			if( !FillFbxTextureProperty( FbxSurfaceMaterial::sTransparencyFactor, *GetOpacityMask(Material), FbxMaterial, FBXScene ) )
			{
				( (FbxSurfaceLambert*)FbxMaterial )->TransparencyFactor.Set( GetOpacityMask(Material)->Constant );
			}
		}
	}
	else
	{
		//There is no normal input in Blend translucent mode
		if( !NormalParamSet )
		{
			//Set the Normal map only if there is a texture sampler
			FillFbxTextureProperty( FbxSurfaceMaterial::sNormalMap, *GetNormal( Material ), FbxMaterial, FBXScene );
		}
	}

	FbxMaterials.Add( MaterialInterface, FbxMaterial );

	return FbxMaterial;
}

#if PLATFORM_WINDOWS
	#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >= 1
		#define WITH_CHAOS 1
		#define WITH_PHYSX 0
		#define PHYSICS_INTERFACE_PHYSX 0
	#endif
#endif

#if ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION < 26
	#define PHYSICS_INTERFACE_PHYSX 1
	#define WITH_CHAOS 0
#endif

#if WITH_PHYSX && PHYSICS_INTERFACE_PHYSX

#if ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION < 26
	#include "geometry/PxConvexMesh.h"
	using namespace physx;
#else
	#include "PxConvexMesh.h"
#endif
#include "PxVec3.h"
FVector P3ToVector( const PxVec3& PVec )
{
	return FVector( PVec.x, PVec.y, PVec.z );
}
#endif

#if WITH_CHAOS
	#include "Chaos/Convex.h"
#endif
#if (WITH_PHYSX && PHYSICS_INTERFACE_PHYSX) || WITH_CHAOS
class FCollisionFbxExporter
{
public:
	FCollisionFbxExporter( const UStaticMesh* StaticMeshToExport, FbxMesh* ExportMesh, int32 ActualMatIndexToExport )
	{
		BoxPositions[ 0 ] = FVector( -1, -1, +1 );
		BoxPositions[ 1 ] = FVector( -1, +1, +1 );
		BoxPositions[ 2 ] = FVector( +1, +1, +1 );
		BoxPositions[ 3 ] = FVector( +1, -1, +1 );

		BoxFaceRotations[ 0 ] = FRotator( 0, 0, 0 );
		BoxFaceRotations[ 1 ] = FRotator( 90.f, 0, 0 );
		BoxFaceRotations[ 2 ] = FRotator( -90.f, 0, 0 );
		BoxFaceRotations[ 3 ] = FRotator( 0, 0, 90.f );
		BoxFaceRotations[ 4 ] = FRotator( 0, 0, -90.f );
		BoxFaceRotations[ 5 ] = FRotator( 180.f, 0, 0 );

		DrawCollisionSides = 16;

		SpherNumSides = DrawCollisionSides;
		SphereNumRings = DrawCollisionSides / 2;
		SphereNumVerts = ( SpherNumSides + 1 ) * ( SphereNumRings + 1 );

		CapsuleNumSides = DrawCollisionSides;
		CapsuleNumRings = ( DrawCollisionSides / 2 ) + 1;
		CapsuleNumVerts = ( CapsuleNumSides + 1 ) * ( CapsuleNumRings + 1 );

		CurrentVertexOffset = 0;

		StaticMesh = StaticMeshToExport;
		Mesh = ExportMesh;
		ActualMatIndex = ActualMatIndexToExport;
	}

	void ExportCollisions()
	{
		const FKAggregateGeom& AggGeo = GetBodySetup( StaticMesh )->AggGeom;

		int32 VerticeNumber = 0;
		for( const FKConvexElem& ConvexElem : AggGeo.ConvexElems )
		{
			VerticeNumber += GetConvexVerticeNumber( ConvexElem );
		}
		//for( const FKBoxElem& BoxElem : AggGeo.BoxElems )
		//{
		//	VerticeNumber += GetBoxVerticeNumber();
		//}
		//for( const FKSphereElem& SphereElem : AggGeo.SphereElems )
		//{
		//	VerticeNumber += GetSphereVerticeNumber();
		//}
		//for( const FKSphylElem& CapsuleElem : AggGeo.SphylElems )
		//{
		//	VerticeNumber += GetCapsuleVerticeNumber();
		//}

		Mesh->InitControlPoints( VerticeNumber );
		ControlPoints = Mesh->GetControlPoints();
		CurrentVertexOffset = 0;
		//////////////////////////////////////////////////////////////////////////
		// Set all vertex
		for( const FKConvexElem& ConvexElem : AggGeo.ConvexElems )
		{
			AddConvexVertex( ConvexElem );
		}

		//for( const FKBoxElem& BoxElem : AggGeo.BoxElems )
		//{
		//	AddBoxVertex( BoxElem );
		//}
		//
		//for( const FKSphereElem& SphereElem : AggGeo.SphereElems )
		//{
		//	AddSphereVertex( SphereElem );
		//}
		//
		//for( const FKSphylElem& CapsuleElem : AggGeo.SphylElems )
		//{
		//	AddCapsuleVertex( CapsuleElem );
		//}

		// Set the normals on Layer 0.
		FbxLayer* Layer = Mesh->GetLayer( 0 );
		if( Layer == nullptr )
		{
			Mesh->CreateLayer();
			Layer = Mesh->GetLayer( 0 );
		}
		// Create and fill in the per-face-vertex normal data source.
		LayerElementNormal = FbxLayerElementNormal::Create( Mesh, "" );
		LayerElementTangent = FbxLayerElementTangent::Create( Mesh, "" );
		LayerElementBinormal = FbxLayerElementBinormal::Create( Mesh, "" );
		// Set the normals per polygon instead of storing normals on positional control points
		LayerElementNormal->SetMappingMode( FbxLayerElement::eByPolygonVertex );
		LayerElementTangent->SetMappingMode( FbxLayerElement::eByPolygonVertex );
		LayerElementBinormal->SetMappingMode( FbxLayerElement::eByPolygonVertex );
		// Set the normal values for every polygon vertex.
		LayerElementNormal->SetReferenceMode( FbxLayerElement::eDirect );
		LayerElementTangent->SetReferenceMode( FbxLayerElement::eDirect );
		LayerElementBinormal->SetReferenceMode( FbxLayerElement::eDirect );

		//////////////////////////////////////////////////////////////////////////
		//Set the Normals
		for( const FKConvexElem& ConvexElem : AggGeo.ConvexElems )
		{
			AddConvexNormals( ConvexElem );
		}
		//for( const FKBoxElem& BoxElem : AggGeo.BoxElems )
		//{
		//	AddBoxNormal( BoxElem );
		//}

		//int32 SphereIndex = 0;
		//for( const FKSphereElem& SphereElem : AggGeo.SphereElems )
		//{
		//	AddSphereNormals( SphereElem, SphereIndex );
		//	SphereIndex++;
		//}
		//
		//int32 CapsuleIndex = 0;
		//for( const FKSphylElem& CapsuleElem : AggGeo.SphylElems )
		//{
		//	AddCapsuleNormals( CapsuleElem, CapsuleIndex );
		//	CapsuleIndex++;
		//}

		Layer->SetNormals( LayerElementNormal );
		Layer->SetTangents( LayerElementTangent );
		Layer->SetBinormals( LayerElementBinormal );

		//////////////////////////////////////////////////////////////////////////
		// Set polygons
		// Build list of polygon re-used multiple times to lookup Normals, UVs, other per face vertex information
		CurrentVertexOffset = 0; //Reset the current VertexCount
		for( const FKConvexElem& ConvexElem : AggGeo.ConvexElems )
		{
			AddConvexPolygon( ConvexElem );
		}

		//for( const FKBoxElem& BoxElem : AggGeo.BoxElems )
		//{
		//	AddBoxPolygons();
		//}
		//
		//for( const FKSphereElem& SphereElem : AggGeo.SphereElems )
		//{
		//	AddSpherePolygons();
		//}
		//
		//for( const FKSphylElem& CapsuleElem : AggGeo.SphylElems )
		//{
		//	AddCapsulePolygons();
		//}

		//////////////////////////////////////////////////////////////////////////
		//Free the sphere resources
		for( FDynamicMeshVertex* DynamicMeshVertex : SpheresVerts )
		{
			FMemory::Free( DynamicMeshVertex );
		}
		SpheresVerts.Empty();

		//////////////////////////////////////////////////////////////////////////
		//Free the capsule resources
		for( FDynamicMeshVertex* DynamicMeshVertex : CapsuleVerts )
		{
			FMemory::Free( DynamicMeshVertex );
		}
		CapsuleVerts.Empty();
	}

private:
	uint32 GetConvexVerticeNumber( const FKConvexElem& ConvexElem )
	{
	#if WITH_PHYSX && PHYSICS_INTERFACE_PHYSX
		return ConvexElem.GetConvexMesh() != nullptr ? ConvexElem.GetConvexMesh()->getNbVertices() : 0;
	#elif WITH_CHAOS
		return ConvexElem.VertexData.Num();
	#endif
	}

	uint32 GetBoxVerticeNumber() { return 24; }

	uint32 GetSphereVerticeNumber() { return SphereNumVerts; }

	uint32 GetCapsuleVerticeNumber() { return CapsuleNumVerts; }

	void AddConvexVertex( const FKConvexElem& ConvexElem )
	{
	#if WITH_PHYSX && PHYSICS_INTERFACE_PHYSX
		const physx::PxConvexMesh* ConvexMesh = ConvexElem.GetConvexMesh();
		if( ConvexMesh == nullptr )
		{
			return;
		}
		FRotator Rotator = FRotator::MakeFromEuler( FVector( 90, 90, 0 ) );//match mesh rotations
		const PxVec3* VertexArray = ConvexMesh->getVertices();
		for( uint32 PosIndex = 0; PosIndex < ConvexMesh->getNbVertices(); ++PosIndex )
		{
			FVector Position = P3ToVector( VertexArray[ PosIndex ] );
			Position = Rotator.RotateVector( Position );
			ControlPoints[ CurrentVertexOffset + PosIndex ] = FbxVector4( -Position.X, Position.Y, Position.Z );
		}
		CurrentVertexOffset += ConvexMesh->getNbVertices();
	#elif WITH_CHAOS
		const TArray<FVector>& VertexArray = ConvexElem.VertexData;
		FRotator Rotator = FRotator::MakeFromEuler( FVector( 90, 90, 0 ) );//match mesh rotations
		for( int32 PosIndex = 0; PosIndex < VertexArray.Num(); ++PosIndex )
		{
			FVector Position = VertexArray[ PosIndex ];
			Position = Rotator.RotateVector( Position );
			ControlPoints[ CurrentVertexOffset + PosIndex ] = FbxVector4( -Position.X, Position.Y, Position.Z );
		}
		CurrentVertexOffset += VertexArray.Num();
	#endif
	}

	void AddConvexNormals( const FKConvexElem& ConvexElem )
	{
	#if WITH_PHYSX && PHYSICS_INTERFACE_PHYSX
		const physx::PxConvexMesh* ConvexMesh = ConvexElem.GetConvexMesh();
		if( ConvexMesh == nullptr )
		{
			return;
		}
		const PxU8* PIndexBuffer = ConvexMesh->getIndexBuffer();
		int32 PolygonNumber = ConvexMesh->getNbPolygons();
		for( int32 PolyIndex = 0; PolyIndex < PolygonNumber; ++PolyIndex )
		{
			PxHullPolygon PolyData;
			if( !ConvexMesh->getPolygonData( PolyIndex, PolyData ) )
			{
				continue;
			}
			const PxVec3 PPlaneNormal( PolyData.mPlane[ 0 ], PolyData.mPlane[ 1 ], PolyData.mPlane[ 2 ] );
			FVector Normal = P3ToVector( PPlaneNormal.getNormalized() );
			FbxVector4 FbxNormal = FbxVector4( Normal.X, -Normal.Y, Normal.Z );
			// add vertices 
			for( PxU32 j = 0; j < PolyData.mNbVerts; ++j )
			{
				LayerElementNormal->GetDirectArray().Add( FbxNormal );
			}
		}
	#elif WITH_CHAOS
		//Needs a link dependency to Chaos me thinks
		//const auto& ConvexMesh = ConvexElem.GetChaosConvexMesh();
		//if (!ConvexMesh.IsValid())
		//{
		//	return;
		//}
		//const TArray<Chaos::FConvex::FPlaneType>& Faces = ConvexMesh->GetFaces();
		//for (int32 PolyIndex = 0; PolyIndex < Faces.Num(); ++PolyIndex)
		//{
		//	FVector Normal = (FVector)Faces[PolyIndex].Normal().GetSafeNormal();
		//	FbxVector4 FbxNormal = FbxVector4(Normal.X, -Normal.Y, Normal.Z);
		//	// add vertices 
		//	for (int32 j = 0; j < 3; ++j)
		//	{
		//		LayerElementNormal->GetDirectArray().Add(FbxNormal);
		//		LayerElementTangent->GetDirectArray().Add( FbxNormal );
		//		LayerElementBinormal->GetDirectArray().Add( FbxNormal );
		//	}
		//}
	#endif
	}

	void AddConvexPolygon( const FKConvexElem& ConvexElem )
	{
	#if WITH_PHYSX && PHYSICS_INTERFACE_PHYSX
		const physx::PxConvexMesh* ConvexMesh = ConvexElem.GetConvexMesh();
		if( ConvexMesh == nullptr )
		{
			return;
		}
		const PxU8* PIndexBuffer = ConvexMesh->getIndexBuffer();
		int32 PolygonNumber = ConvexMesh->getNbPolygons();
		for( int32 PolyIndex = 0; PolyIndex < PolygonNumber; ++PolyIndex )
		{
			PxHullPolygon PolyData;
			if( !ConvexMesh->getPolygonData( PolyIndex, PolyData ) )
			{
				continue;
			}
			Mesh->BeginPolygon( ActualMatIndex );
			const PxU8* PolyIndices = PIndexBuffer + PolyData.mIndexBase;
			// add vertices 
			//for( PxU32 j = 0; j < PolyData.mNbVerts; ++j )
			for( int j = PolyData.mNbVerts - 1; j >= 0; j-- )
			{
				const uint32 VertIndex = CurrentVertexOffset + PolyIndices[ j ];
				Mesh->AddPolygon( VertIndex );
			}
			Mesh->EndPolygon();
		}
		CurrentVertexOffset += ConvexMesh->getNbVertices();
	#elif WITH_CHAOS
		//const auto& ConvexMesh = ConvexElem.GetChaosConvexMesh();
		//if( !ConvexMesh.IsValid() )
		//{
		//	return;
		//}
		TArray<int32> IndexData( ConvexElem.IndexData );
		if( IndexData.Num() == 0 )
		{
			IndexData = ConvexElem.GetChaosConvexIndices();
		}
		check( IndexData.Num() % 3 == 0 );
		for( int32 VertexIndex = 0; VertexIndex < IndexData.Num(); VertexIndex += 3 )
		{
			Mesh->BeginPolygon( ActualMatIndex );
			Mesh->AddPolygon( CurrentVertexOffset + IndexData[ VertexIndex ] );
			Mesh->AddPolygon( CurrentVertexOffset + IndexData[ VertexIndex + 1 ] );
			Mesh->AddPolygon( CurrentVertexOffset + IndexData[ VertexIndex + 2 ] );
			Mesh->EndPolygon();
		}

		CurrentVertexOffset += ConvexElem.VertexData.Num();
	#endif
	}

	//////////////////////////////////////////////////////////////////////////
	//Box data
	FVector BoxPositions[ 4 ];
	FRotator BoxFaceRotations[ 6 ];


	int32 DrawCollisionSides;
	//////////////////////////////////////////////////////////////////////////
	//Sphere data
	int32 SpherNumSides;
	int32 SphereNumRings;
	int32 SphereNumVerts;
	TArray<FDynamicMeshVertex*> SpheresVerts;

	//////////////////////////////////////////////////////////////////////////
	//Capsule data
	int32 CapsuleNumSides;
	int32 CapsuleNumRings;
	int32 CapsuleNumVerts;
	TArray<FDynamicMeshVertex*> CapsuleVerts;

	//////////////////////////////////////////////////////////////////////////
	//Mesh Data
	uint32 CurrentVertexOffset;

	const UStaticMesh* StaticMesh;
	FbxMesh* Mesh;
	int32 ActualMatIndex;
	FbxVector4* ControlPoints;
	FbxLayerElementNormal* LayerElementNormal;
	FbxLayerElementTangent* LayerElementTangent;
	FbxLayerElementBinormal* LayerElementBinormal;
};
FbxNode* ExportCollisionMesh( FFbxExporter* Exporter, const UStaticMesh* StaticMesh, const TCHAR* MeshName, FbxNode* ParentActor, FbxScene* FBXScene )
{
	const FKAggregateGeom& AggGeo = GetBodySetup( StaticMesh )->AggGeom;
	if( AggGeo.GetElementCount() <= 0 )
	{
		return nullptr;
	}
	//No idea but FbxMeshes doesn't add vertex painted meshes, but returning here misses ConvexHulls for vertex painted objects
	//FbxMesh* Mesh = FbxMeshes.FindRef( StaticMesh );
	//if( !Mesh )
	//{
	//	//We export collision only if the mesh is already exported
	//	return nullptr;
	//}

	//Name the node with the actor name
	FString MeshCollisionName = MeshName;// TEXT( "UCX_" );
	MeshCollisionName += TEXT( "_ConvexHulls" ); //UTF8_TO_TCHAR( ParentActor->GetName() ); //-V595
	FbxNode* FbxActor = FbxNode::Create( FBXScene, TCHAR_TO_UTF8( *MeshCollisionName ) );

	if( ParentActor != nullptr )
	{
		// Collision meshes are added directly to the scene root, so we need to use the global transform instead of the relative one.
		FbxAMatrix& GlobalTransform = ParentActor->EvaluateGlobalTransform();

		const FStaticMeshRenderData* RenderData = GetRenderData( StaticMesh );
		if( RenderData->LODResources.Num() == 1 )
		{
			//This is apparently needed to have 0,0,0 rotation for the collider but only when no LODs
			FbxActor->LclTranslation.Set( GlobalTransform.GetT() );
			FbxActor->LclRotation.Set( GlobalTransform.GetR() );
			FbxActor->LclScaling.Set( GlobalTransform.GetS() );
		}

		if ( ParentActor->GetParent())
			ParentActor->GetParent()->AddChild( FbxActor );
		else
			FBXScene->GetRootNode()->AddChild( FbxActor );
	}

	FbxMesh* CollisionMesh = FbxCollisionMeshes.FindRef( StaticMesh );
	if( !CollisionMesh )
	{
		//Name the mesh attribute with the mesh name
		//MeshCollisionName = TEXT( "UCX_" );
		MeshCollisionName = MeshName;
		MeshCollisionName += TEXT( "_ConvexHulls" );
		CollisionMesh = FbxMesh::Create( FBXScene, TCHAR_TO_UTF8( *MeshCollisionName ) );

		//Export all collision elements in one mesh
		FbxSurfaceMaterial* FbxMaterial = nullptr;
		for( auto iter = FbxMaterials.CreateIterator(); iter; ++iter )
		{
			FbxMaterial = iter->Value;
		}		
		
		int32 ActualMatIndex = FbxActor->AddMaterial( FbxMaterial );
		FCollisionFbxExporter CollisionFbxExporter( StaticMesh, CollisionMesh, ActualMatIndex );
		CollisionFbxExporter.ExportCollisions();
		FbxCollisionMeshes.Add( StaticMesh, CollisionMesh );
	}

	if( CollisionMesh->GetPolygonCount() > 0 )
	{
		//Set the original meshes in case it was already existing
		FbxActor->SetNodeAttribute( CollisionMesh );
	}
	return FbxActor;
}
#endif

#if ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION < 26
class INodeNameAdapter_UTU
{
public:
	virtual ~INodeNameAdapter_UTU() {}
	virtual FString GetActorNodeName( const AActor* InActor ) { return InActor->GetName(); }
	virtual void AddFbxNode( UObject* InObject, fbxsdk::FbxNode* InFbxNode ) {}
	virtual fbxsdk::FbxNode* GetFbxNode( UObject* InObject ) { return nullptr; }
};
#define INodeNameAdapter INodeNameAdapter_UTU
#endif

UFbxExportOption* GetExportOptions( FFbxExporter* Exporter )
{
	#if ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION < 26
		uint8* Pointer = (uint8*)Exporter;
		static int Offset = 24;
		UFbxExportOption* Data = *(UFbxExportOption**)( Pointer + Offset );
		return Data;
	#else
		return Exporter->GetExportOptions();
	#endif
}
FbxNode* ExportStaticMeshToFbx( FFbxExporter* Exporter, const UStaticMesh* StaticMesh, int32 ExportLOD, const TCHAR* MeshName, FbxNode* FbxActor, int32 LightmapUVChannel /*= -1*/, const FColorVertexBuffer* ColorBuffer /*= NULL*/, const TArray<FStaticMaterial>* MaterialOrderOverride /*= NULL*/, const TArray<UMaterialInterface*>* OverrideMaterials /*= NULL*/ ,
								FbxScene* FBXScene )
{
	FbxMesh* Mesh = nullptr;
	if( ( ExportLOD == 0 || ExportLOD == -1 ) && LightmapUVChannel == -1 && ColorBuffer == nullptr && MaterialOrderOverride == nullptr )
	{
		Mesh = FbxMeshes.FindRef( StaticMesh );
	}

	if( !Mesh )
	{
		Mesh = FbxMesh::Create( FBXScene, TCHAR_TO_UTF8( MeshName ) );

		const FStaticMeshLODResources& RenderMesh = StaticMesh->GetLODForExport( ExportLOD );

		// Verify the integrity of the static mesh.
		if( RenderMesh.VertexBuffers.StaticMeshVertexBuffer.GetNumVertices() == 0 )
		{
			return nullptr;
		}

		if( RenderMesh.Sections.Num() == 0 )
		{
			return nullptr;
		}

		// Remaps an Unreal vert to final reduced vertex list
		TArray<int32> VertRemap;
		TArray<int32> UniqueVerts;

		// Weld verts
		DetermineVertsToWeld( VertRemap, UniqueVerts, RenderMesh );

		// Create and fill in the vertex position data source.
		// The position vertices are duplicated, for some reason, retrieve only the first half vertices.
		const int32 VertexCount = VertRemap.Num();
		const int32 PolygonsCount = RenderMesh.Sections.Num();

		Mesh->InitControlPoints( UniqueVerts.Num() );

		FbxVector4* ControlPoints = Mesh->GetControlPoints();
		
		FRotator Rotator = FRotator::MakeFromEuler( FVector( 90, 90, 0 ) );//preview FBX the same as UE

		for( int32 PosIndex = 0; PosIndex < UniqueVerts.Num(); ++PosIndex )
		{
			int32 UnrealPosIndex = UniqueVerts[ PosIndex ];
			FVector Position = (FVector)RenderMesh.VertexBuffers.PositionVertexBuffer.VertexPosition( UnrealPosIndex );
			ControlPoints[ PosIndex ] = FbxVector4( Position.X, -Position.Y, Position.Z );
			if( CVarAssetsWithYUp.GetValueOnAnyThread() == 1 )
			{
				Position = Rotator.RotateVector( Position );
				ControlPoints[ PosIndex ] = FbxVector4( -Position.X, Position.Y, Position.Z );
			}
		}

		// Set the normals on Layer 0.
		FbxLayer* Layer = Mesh->GetLayer( 0 );
		if( Layer == nullptr )
		{
			Mesh->CreateLayer();
			Layer = Mesh->GetLayer( 0 );
		}

		// Build list of Indices re-used multiple times to lookup Normals, UVs, other per face vertex information
		TArray<uint32> Indices;
		for( int32 PolygonsIndex = 0; PolygonsIndex < PolygonsCount; ++PolygonsIndex )
		{
			FIndexArrayView RawIndices = RenderMesh.IndexBuffer.GetArrayView();
			const FStaticMeshSection& Polygons = RenderMesh.Sections[ PolygonsIndex ];
			const uint32 TriangleCount = Polygons.NumTriangles;
			for( uint32 TriangleIndex = 0; TriangleIndex < TriangleCount; ++TriangleIndex )
			{
				//for( int PointIndex = 2; PointIndex >=0; PointIndex-- )
				for( int PointIndex = 0; PointIndex < 3; PointIndex++ )
				{
					uint32 UnrealVertIndex = RawIndices[ Polygons.FirstIndex + ( ( TriangleIndex * 3 ) + PointIndex ) ];
					Indices.Add( UnrealVertIndex );
				}
			}
		}

		// Create and fill in the per-face-vertex normal data source.
		// We extract the Z-tangent and the X/Y-tangents which are also stored in the render mesh.
		FbxLayerElementNormal* LayerElementNormal = FbxLayerElementNormal::Create( Mesh, "" );
		FbxLayerElementTangent* LayerElementTangent = FbxLayerElementTangent::Create( Mesh, "" );
		FbxLayerElementBinormal* LayerElementBinormal = FbxLayerElementBinormal::Create( Mesh, "" );

		// Set 3 NTBs per triangle instead of storing on positional control points
		LayerElementNormal->SetMappingMode( FbxLayerElement::eByPolygonVertex );
		LayerElementTangent->SetMappingMode( FbxLayerElement::eByPolygonVertex );
		LayerElementBinormal->SetMappingMode( FbxLayerElement::eByPolygonVertex );

		// Set the NTBs values for every polygon vertex.
		LayerElementNormal->SetReferenceMode( FbxLayerElement::eDirect );
		LayerElementTangent->SetReferenceMode( FbxLayerElement::eDirect );
		LayerElementBinormal->SetReferenceMode( FbxLayerElement::eDirect );

		TArray<FbxVector4> FbxNormals;
		TArray<FbxVector4> FbxTangents;
		TArray<FbxVector4> FbxBinormals;

		FbxNormals.AddUninitialized( VertexCount );
		FbxTangents.AddUninitialized( VertexCount );
		FbxBinormals.AddUninitialized( VertexCount );

		for( int32 NTBIndex = 0; NTBIndex < VertexCount; ++NTBIndex )
		{
			FVector Normal = (FVector)( RenderMesh.VertexBuffers.StaticMeshVertexBuffer.VertexTangentZ( NTBIndex ) );
			if( CVarAssetsWithYUp.GetValueOnAnyThread() == 1 )
			{
				Normal.Y *= -1;
				Normal = Rotator.RotateVector( Normal );
			}
			FbxVector4& FbxNormal = FbxNormals[ NTBIndex ];
			FbxNormal = FbxVector4( Normal.X, Normal.Y, Normal.Z );
			FbxNormal.Normalize();

			FVector Tangent = (FVector)( RenderMesh.VertexBuffers.StaticMeshVertexBuffer.VertexTangentX( NTBIndex ) );
			if( CVarAssetsWithYUp.GetValueOnAnyThread() == 1 )
			{
				Tangent.Y *= -1;
				Tangent = Rotator.RotateVector( Tangent );
			}
			FbxVector4& FbxTangent = FbxTangents[ NTBIndex ];
			FbxTangent = FbxVector4( Tangent.X, Tangent.Y, Tangent.Z );
			FbxTangent.Normalize();

			FVector Binormal = -(FVector)( RenderMesh.VertexBuffers.StaticMeshVertexBuffer.VertexTangentY( NTBIndex ) );
			if( CVarAssetsWithYUp.GetValueOnAnyThread() == 1 )
			{
				Binormal.Y *= -1;
				Binormal = Rotator.RotateVector( Binormal );
			}
			FbxVector4& FbxBinormal = FbxBinormals[ NTBIndex ];
			FbxBinormal = FbxVector4( Binormal.X, Binormal.Y, Binormal.Z );
			FbxBinormal.Normalize();
		}

		// Add one normal per each face index (3 per triangle)
		for( int32 FbxVertIndex = 0; FbxVertIndex < Indices.Num(); FbxVertIndex++ )
		{
			uint32 UnrealVertIndex = Indices[ FbxVertIndex ];
			LayerElementNormal->GetDirectArray().Add( FbxNormals[ UnrealVertIndex ] );
			LayerElementTangent->GetDirectArray().Add( FbxTangents[ UnrealVertIndex ] );
			LayerElementBinormal->GetDirectArray().Add( FbxBinormals[ UnrealVertIndex ] );
		}

		Layer->SetNormals( LayerElementNormal );
		Layer->SetTangents( LayerElementTangent );
		Layer->SetBinormals( LayerElementBinormal );

		FbxNormals.Empty();
		FbxTangents.Empty();
		FbxBinormals.Empty();

		// Create and fill in the per-face-vertex texture coordinate data source(s).
		// Create UV for Diffuse channel.
		int32 TexCoordSourceCount = ( LightmapUVChannel == -1 ) ? RenderMesh.VertexBuffers.StaticMeshVertexBuffer.GetNumTexCoords() : LightmapUVChannel + 1;
		int32 TexCoordSourceIndex = ( LightmapUVChannel == -1 ) ? 0 : LightmapUVChannel;
		for( ; TexCoordSourceIndex < TexCoordSourceCount; ++TexCoordSourceIndex )
		{
			FbxLayer* UVsLayer = ( LightmapUVChannel == -1 ) ? Mesh->GetLayer( TexCoordSourceIndex ) : Mesh->GetLayer( 0 );
			if( UVsLayer == NULL )
			{
				Mesh->CreateLayer();
				UVsLayer = ( LightmapUVChannel == -1 ) ? Mesh->GetLayer( TexCoordSourceIndex ) : Mesh->GetLayer( 0 );
			}
			check( UVsLayer );

			FString UVChannelNameBuilder = TEXT( "UVmap_" ) + FString::FromInt( TexCoordSourceIndex );
			//const char* UVChannelName = TCHAR_TO_UTF8( *UVChannelNameBuilder ); // actually UTF8 as required by Fbx, but can't use UE4's UTF8CHAR type because that's a uint8 aka *unsigned* char
			//if( ( LightmapUVChannel >= 0 ) || ( ( LightmapUVChannel == -1 ) && ( TexCoordSourceIndex == StaticMesh->GetLightMapCoordinateIndex() ) ) )
			//{
			//	UVChannelName = "LightMapUV";
			//}

			FbxLayerElementUV* UVDiffuseLayer = FbxLayerElementUV::Create( Mesh, TCHAR_TO_UTF8( *UVChannelNameBuilder ) );

			// Note: when eINDEX_TO_DIRECT is used, IndexArray must be 3xTriangle count, DirectArray can be smaller
			UVDiffuseLayer->SetMappingMode( FbxLayerElement::eByPolygonVertex );
			UVDiffuseLayer->SetReferenceMode( FbxLayerElement::eIndexToDirect );

			TArray<int32> UvsRemap;
			TArray<int32> UniqueUVs;
			// Weld UVs
			DetermineUVsToWeld( UvsRemap, UniqueUVs, RenderMesh.VertexBuffers.StaticMeshVertexBuffer, TexCoordSourceIndex );

			// Create the texture coordinate data source.
			for( int32 FbxVertIndex = 0; FbxVertIndex < UniqueUVs.Num(); FbxVertIndex++ )
			{
				int32 UnrealVertIndex = UniqueUVs[ FbxVertIndex ];
				#if ENGINE_MAJOR_VERSION == 4
					const FVector2D& TexCoord = RenderMesh.VertexBuffers.StaticMeshVertexBuffer.GetVertexUV( UnrealVertIndex, TexCoordSourceIndex );
				#else
					const FVector2f& TexCoord = RenderMesh.VertexBuffers.StaticMeshVertexBuffer.GetVertexUV( UnrealVertIndex, TexCoordSourceIndex );
				#endif
				//UVDiffuseLayer->GetDirectArray().Add( FbxVector2( TexCoord.X, TexCoord.Y ) );
				UVDiffuseLayer->GetDirectArray().Add( FbxVector2( TexCoord.X, -TexCoord.Y + 1.0 ) );//Why this Epic ?
			}

			// For each face index, point to a texture uv
			UVDiffuseLayer->GetIndexArray().SetCount( Indices.Num() );
			for( int32 FbxVertIndex = 0; FbxVertIndex < Indices.Num(); FbxVertIndex++ )
			{
				uint32 UnrealVertIndex = Indices[ FbxVertIndex ];
				int32 NewVertIndex = UvsRemap[ UnrealVertIndex ];
				UVDiffuseLayer->GetIndexArray().SetAt( FbxVertIndex, NewVertIndex );
			}

			UVsLayer->SetUVs( UVDiffuseLayer, FbxLayerElement::eTextureDiffuse );
		}

		FbxLayerElementMaterial* MatLayer = FbxLayerElementMaterial::Create( Mesh, "" );
		MatLayer->SetMappingMode( FbxLayerElement::eByPolygon );
		MatLayer->SetReferenceMode( FbxLayerElement::eIndexToDirect );
		Layer->SetMaterials( MatLayer );

		// Keep track of the number of tri's we export
		uint32 AccountedTriangles = 0;
		for( int32 PolygonsIndex = 0; PolygonsIndex < PolygonsCount; ++PolygonsIndex )
		{
			const FStaticMeshSection& Polygons = RenderMesh.Sections[ PolygonsIndex ];
			FIndexArrayView RawIndices = RenderMesh.IndexBuffer.GetArrayView();
			UMaterialInterface* Material = nullptr;

			if( OverrideMaterials && OverrideMaterials->IsValidIndex( Polygons.MaterialIndex ) )
			{
				Material = ( *OverrideMaterials )[ Polygons.MaterialIndex ];
			}
			else
			{
				Material = StaticMesh->GetMaterial( Polygons.MaterialIndex );
			}

			MaterialBinding* Binding = GetMaterialIfAlreadyExported( Material );
			FbxSurfaceMaterial* FbxMaterial = nullptr;
			if( Binding )
				FbxMaterial = ExportMaterial_UTU( Material, Binding, FBXScene );
			else
				FbxMaterial = ExportMaterial( Material, FBXScene );
			//FbxSurfaceMaterial* FbxMaterial = Material ? ExportMaterial( Material ) : NULL;
			if( !FbxMaterial )
			{
				FbxMaterial = CreateDefaultMaterial( FBXScene );
			}
			int ExistentMaterialIndex = -1;
			if( FbxMaterial )
			{
				ExistentMaterialIndex = FbxActor->GetMaterialIndex( FbxMaterial->GetName() );
			}
			if ( ExistentMaterialIndex == -1 )
				ExistentMaterialIndex = FbxActor->AddMaterial( FbxMaterial );

			// Determine the actual material index
			int32 ActualMatIndex = ExistentMaterialIndex;

			if( MaterialOrderOverride )
			{
				ActualMatIndex = MaterialOrderOverride->Find( Material );
			}
			// Static meshes contain one triangle list per element.
			// [GLAFORTE] Could it occasionally contain triangle strips? How do I know?
			uint32 TriangleCount = Polygons.NumTriangles;

			// Copy over the index buffer into the FBX polygons set.
			for( uint32 TriangleIndex = 0; TriangleIndex < TriangleCount; ++TriangleIndex )
			{
				Mesh->BeginPolygon( ActualMatIndex );
				//for( int PointIndex = 2; PointIndex >=0; PointIndex-- )
				for( int PointIndex = 0; PointIndex < 3; PointIndex++ )
				{
					uint32 OriginalUnrealVertIndex = RawIndices[ Polygons.FirstIndex + ( ( TriangleIndex * 3 ) + PointIndex ) ];
					int32 RemappedVertIndex = VertRemap[ OriginalUnrealVertIndex ];
					Mesh->AddPolygon( RemappedVertIndex );
				}
				Mesh->EndPolygon();
			}

			AccountedTriangles += TriangleCount;
		}

	#ifdef TODO_FBX
		// Throw a warning if this is a lightmap export and the exported poly count does not match the raw triangle data count
		if( LightmapUVChannel != -1 && AccountedTriangles != RenderMesh.RawTriangles.GetElementCount() )
		{
			FMessageDialog::Open( EAppMsgType::Ok, NSLOCTEXT( "UnrealEd", "StaticMeshEditor_LightmapExportFewerTriangles", "Fewer polygons have been exported than the raw triangle count.  This Lightmapped UV mesh may contain fewer triangles than the destination mesh on import." ) );
		}

		// Create and fill in the smoothing data source.
		FbxLayerElementSmoothing* SmoothingInfo = FbxLayerElementSmoothing::Create( Mesh, "" );
		SmoothingInfo->SetMappingMode( FbxLayerElement::eByPolygon );
		SmoothingInfo->SetReferenceMode( FbxLayerElement::eDirect );
		FbxLayerElementArrayTemplate<int>& SmoothingArray = SmoothingInfo->GetDirectArray();
		Layer->SetSmoothing( SmoothingInfo );

		// This is broken. We are exporting the render mesh but providing smoothing
		// information from the source mesh. The render triangles are not in the
		// same order. Therefore we should export the raw mesh or not export
		// smoothing group information!
		int32 TriangleCount = RenderMesh.RawTriangles.GetElementCount();
		FStaticMeshTriangle* RawTriangleData = (FStaticMeshTriangle*)RenderMesh.RawTriangles.Lock( LOCK_READ_ONLY );
		for( int32 TriangleIndex = 0; TriangleIndex < TriangleCount; TriangleIndex++ )
		{
			FStaticMeshTriangle* Triangle = ( RawTriangleData++ );

			SmoothingArray.Add( Triangle->SmoothingMask );
		}
		RenderMesh.RawTriangles.Unlock();
	#endif // #if TODO_FBX

		// Create and fill in the vertex color data source.
		const FColorVertexBuffer* ColorBufferToUse = ColorBuffer ? ColorBuffer : &RenderMesh.VertexBuffers.ColorVertexBuffer;
		uint32 ColorVertexCount = ColorBufferToUse->GetNumVertices();

		// Only export vertex colors if they exist
		if( UTUSettings->ExportVertexColors && ColorVertexCount > 0 )
		{
			FbxLayerElementVertexColor* VertexColor = FbxLayerElementVertexColor::Create( Mesh, "" );
			VertexColor->SetMappingMode( FbxLayerElement::eByPolygonVertex );
			VertexColor->SetReferenceMode( FbxLayerElement::eIndexToDirect );
			FbxLayerElementArrayTemplate<FbxColor>& VertexColorArray = VertexColor->GetDirectArray();
			Layer->SetVertexColors( VertexColor );

			for( int32 FbxVertIndex = 0; FbxVertIndex < Indices.Num(); FbxVertIndex++ )
			{
				FLinearColor VertColor( 1.0f, 1.0f, 1.0f );
				uint32 UnrealVertIndex = Indices[ FbxVertIndex ];
				if( UnrealVertIndex < ColorVertexCount )
				{
					VertColor = ColorBufferToUse->VertexColor( UnrealVertIndex ).ReinterpretAsLinear();
				}

				VertexColorArray.Add( FbxColor( VertColor.R, VertColor.G, VertColor.B, VertColor.A ) );
			}

			VertexColor->GetIndexArray().SetCount( Indices.Num() );
			for( int32 FbxVertIndex = 0; FbxVertIndex < Indices.Num(); FbxVertIndex++ )
			{
				VertexColor->GetIndexArray().SetAt( FbxVertIndex, FbxVertIndex );
			}
		}

		if( ( ExportLOD == 0 || ExportLOD == -1 ) && LightmapUVChannel == -1 && ColorBuffer == nullptr && MaterialOrderOverride == nullptr )
		{
			FbxMeshes.Add( StaticMesh, Mesh );
		}
	}
	else
	{
		//Materials in fbx are store in the node and not in the mesh, so even if the mesh was already export
		//we have to find and assign the mesh material.
		const FStaticMeshLODResources& RenderMesh = StaticMesh->GetLODForExport( ExportLOD );
		const int32 PolygonsCount = RenderMesh.Sections.Num();
		uint32 AccountedTriangles = 0;
		for( int32 PolygonsIndex = 0; PolygonsIndex < PolygonsCount; ++PolygonsIndex )
		{
			const FStaticMeshSection& Polygons = RenderMesh.Sections[ PolygonsIndex ];
			FIndexArrayView RawIndices = RenderMesh.IndexBuffer.GetArrayView();
			UMaterialInterface* Material = nullptr;

			if( OverrideMaterials && OverrideMaterials->IsValidIndex( Polygons.MaterialIndex ) )
			{
				Material = ( *OverrideMaterials )[ Polygons.MaterialIndex ];
			}
			else
			{
				Material = StaticMesh->GetMaterial( Polygons.MaterialIndex );
			}

			FbxSurfaceMaterial* FbxMaterial =  Material ? ExportMaterial( Material, FBXScene ) : NULL;
			if( !FbxMaterial )
			{
				FbxMaterial = CreateDefaultMaterial( FBXScene );
			}
			FbxActor->AddMaterial( FbxMaterial );
		}
	}

#if (WITH_PHYSX && PHYSICS_INTERFACE_PHYSX) || WITH_CHAOS
	if( ( ExportLOD == 0 || ExportLOD == -1 ) && GetExportOptions( Exporter )->Collision )
	{
		ExportCollisionMesh( Exporter, StaticMesh, MeshName, FbxActor, FBXScene );
	}
#endif


	//Set the original meshes in case it was already existing
	FbxActor->SetNodeAttribute( Mesh );

	//ExportObjectMetadata( StaticMesh, FbxActor );

	return FbxActor;
}
FbxNode* FindActor( AActor* Actor, INodeNameAdapter* NodeNameAdapter )
{
	if( NodeNameAdapter )
	{
		FbxNode* ActorNode = NodeNameAdapter->GetFbxNode( Actor );

		if( ActorNode )
		{
			return ActorNode;
		}
	}

	if( FbxActors.Find( Actor ) )
	{
		return *FbxActors.Find( Actor );
	}
	else
	{
		return NULL;
	}
}
FString GetFbxObjectName( const FString& FbxObjectNode, INodeNameAdapter& NodeNameAdapter )
{
	FString FbxTestName = FbxObjectNode;
	int32* NodeIndex = FbxNodeNameToIndexMap.Find( FbxTestName );
	if( NodeIndex )
	{
		FbxTestName = FString::Printf( TEXT( "%s%d" ), *FbxTestName, *NodeIndex );
		++( *NodeIndex );
	}
	else
	{
		FbxNodeNameToIndexMap.Add( FbxTestName, 1 );
	}
	return FbxTestName;
}
FbxNode* CreateSkeleton( const USkeletalMesh* SkelMesh, TArray<FbxNode*>& BoneNodes, FbxScene* FBXScene )
{
	#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 27) || ENGINE_MAJOR_VERSION == 5
		const FReferenceSkeleton& RefSkeleton = SkelMesh->GetRefSkeleton();
	#else
		const FReferenceSkeleton& RefSkeleton = SkelMesh->RefSkeleton;
	#endif
	

	if( RefSkeleton.GetRawBoneNum() == 0 )
	{
		return NULL;
	}

	// Create a list of the nodes we create for each bone, so that children can 
	// later look up their parent
	BoneNodes.Reserve( RefSkeleton.GetRawBoneNum() );

	for( int32 BoneIndex = 0; BoneIndex < RefSkeleton.GetRawBoneNum(); ++BoneIndex )
	{
		const FMeshBoneInfo& CurrentBone = RefSkeleton.GetRefBoneInfo()[ BoneIndex ];
		FTransform& BoneTransform = ( FTransform&)RefSkeleton.GetRefBonePose()[ BoneIndex ];

		FbxString BoneName = Converter.ConvertToFbxString( CurrentBone.ExportName );


		// Create the node's attributes
		FbxSkeleton* SkeletonAttribute = FbxSkeleton::Create( FBXScene, BoneName.Buffer() );
		if( BoneIndex )
		{
			SkeletonAttribute->SetSkeletonType( FbxSkeleton::eLimbNode );
			//SkeletonAttribute->Size.Set(1.0);
		}
		else
		{
			SkeletonAttribute->SetSkeletonType( FbxSkeleton::eRoot );
			//SkeletonAttribute->Size.Set(1.0);
		}


		// Create the node
		FbxNode* BoneNode = FbxNode::Create( FBXScene, BoneName.Buffer() );
		BoneNode->SetNodeAttribute( SkeletonAttribute );

		// Set the bone node's local orientation
		FVector UnrealRotation = BoneTransform.GetRotation().Euler();
		
		FRotator Rotator = FRotator::MakeFromEuler( FVector( 90, 0, 0 ) );

		//UTU Flip for Y up
		//FTransform YUpTrans;
		//YUpTrans.SetRotation( Rotator.Quaternion() );
		//BoneTransform = BoneTransform * YUpTrans;

		FbxVector4 LocalPos = Converter.ConvertToFbxPos( BoneTransform.GetTranslation() );
		FbxVector4 LocalRot = Converter.ConvertToFbxRot( UnrealRotation );
		FbxVector4 LocalScale = Converter.ConvertToFbxScale( BoneTransform.GetScale3D() );

		BoneNode->LclTranslation.Set( LocalPos );
		BoneNode->LclRotation.Set( LocalRot );
		BoneNode->LclScaling.Set( LocalScale );


		// If this is not the root bone, attach it to its parent
		if( BoneIndex )
		{
			BoneNodes[ CurrentBone.ParentIndex ]->AddChild( BoneNode );
		}


		// Add the node to the list of nodes, in bone order
		BoneNodes.Push( BoneNode );
	}

	return BoneNodes[ 0 ];
}
int32 GetNumberOfFrames( const UAnimSequence* AnimSeq )
{
#if ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION < 26
	return AnimSeq->GetNumberOfFrames();
#elif ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 26
	return AnimSeq->GetRawNumberOfFrames();
#else
	return AnimSeq->GetNumberOfSampledKeys();
#endif
}
float GetSequenceLength( const UAnimSequence* AnimSeq )
{
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 2
	return AnimSeq->GetPlayLength();
#else
	return AnimSeq->SequenceLength;
#endif	
}

bool SetupAnimStack( const UAnimSequence* AnimSeq, FbxScene* FBXScene )
{
	if( GetSequenceLength( AnimSeq ) == 0.f )
	{
		// something is wrong
		return false;
	}
	
	const float FrameRate = FMath::TruncToFloat( ( ( GetNumberOfFrames(AnimSeq) - 1 ) / GetSequenceLength( AnimSeq ) ) + 0.5f );
	
	//Configure the scene time line
	{
		FbxGlobalSettings& SceneGlobalSettings = FBXScene->GetGlobalSettings();
		double CurrentSceneFrameRate = FbxTime::GetFrameRate( SceneGlobalSettings.GetTimeMode() );
		if( !bSceneGlobalTimeLineSet || FrameRate > CurrentSceneFrameRate )
		{
			FbxTime::EMode ComputeTimeMode = FbxTime::ConvertFrameRateToTimeMode( FrameRate );
			FbxTime::SetGlobalTimeMode( ComputeTimeMode, ComputeTimeMode == FbxTime::eCustom ? FrameRate : 0.0 );
			SceneGlobalSettings.SetTimeMode( ComputeTimeMode );
			if( ComputeTimeMode == FbxTime::eCustom )
			{
				SceneGlobalSettings.SetCustomFrameRate( FrameRate );
			}
			bSceneGlobalTimeLineSet = true;
		}
	}

	// set time correctly
	FbxTime ExportedStartTime, ExportedStopTime;
	ExportedStartTime.SetSecondDouble( 0.f );
	ExportedStopTime.SetSecondDouble( GetSequenceLength( AnimSeq ) );

	FbxTimeSpan ExportedTimeSpan;
	ExportedTimeSpan.Set( ExportedStartTime, ExportedStopTime );
	AnimStack->SetLocalTimeSpan( ExportedTimeSpan );

	return true;
}
#if ENGINE_MAJOR_VERSION == 4 || (ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION <=1 )
void IterateInsideAnimSequence( const UAnimSequence* AnimSeq, float AnimStartOffset, float AnimEndOffset, float AnimPlayRate, float StartTime, TFunctionRef<void( float, FbxTime, bool )> IterationLambda )
{
	float AnimTime = AnimStartOffset;
	float AnimEndTime = ( GetSequenceLength( AnimSeq ) - AnimEndOffset );
	// Subtracts 1 because NumFrames includes an initial pose for 0.0 second
	double TimePerKey = ( GetSequenceLength( AnimSeq ) / ( GetNumberOfFrames( AnimSeq ) - 1 ) );
	const float AnimTimeIncrement = TimePerKey * AnimPlayRate;
	uint32 AnimFrameIndex = 0;

	FbxTime ExportTime;
	ExportTime.SetSecondDouble( StartTime );

	FbxTime ExportTimeIncrement;
	ExportTimeIncrement.SetSecondDouble( TimePerKey );

	// Step through each frame and add custom curve data
	bool bLastKey = false;
	while( !bLastKey )
	{
		bLastKey = ( AnimTime + KINDA_SMALL_NUMBER ) > AnimEndTime;

		IterationLambda( AnimTime, ExportTime, bLastKey );

		ExportTime += ExportTimeIncrement;
		AnimFrameIndex++;
		AnimTime = AnimStartOffset + ( (float)AnimFrameIndex * AnimTimeIncrement );
	}
}
void ExportCustomAnimCurvesToFbx( const TMap<FName, FbxAnimCurve*>& CustomCurves, const UAnimSequence* AnimSeq,
								  float AnimStartOffset, float AnimEndOffset, float AnimPlayRate, float StartTime, float ValueScale,
								  FbxScene* FBXScene )
{
	// stack allocator for extracting curve
	FMemMark Mark( FMemStack::Get() );
	const USkeleton* Skeleton = AnimSeq->GetSkeleton();
	const FSmartNameMapping* SmartNameMapping = Skeleton ? Skeleton->GetSmartNameContainer( USkeleton::AnimCurveMappingName ) : nullptr;

	if( !Skeleton || !SmartNameMapping || !SetupAnimStack( AnimSeq, FBXScene ) )
	{
		//Something is wrong.
		return;
	}

	TArray<SmartName::UID_Type> AnimCurveUIDs;
	{
		//We need to recreate the UIDs array manually so that we keep the empty entries otherwise the BlendedCurve won't have the correct mapping.
		TArray<FName> UID_ToNameArray;
		SmartNameMapping->FillUIDToNameArray( UID_ToNameArray );
		AnimCurveUIDs.Reserve( UID_ToNameArray.Num() );
		for( int32 NameIndex = 0; NameIndex < UID_ToNameArray.Num(); ++NameIndex )
		{
			AnimCurveUIDs.Add( NameIndex );
		}
	}

	for( auto CustomCurve : CustomCurves )
	{
		CustomCurve.Value->KeyModifyBegin();
	}

	auto ExportLambda = [&]( float AnimTime, FbxTime ExportTime, bool bLastKey )
	{
		FBlendedCurve BlendedCurve;
		BlendedCurve.InitFrom( &AnimCurveUIDs );
		AnimSeq->EvaluateCurveData( BlendedCurve, AnimTime, true );
		if( BlendedCurve.IsValid() )
		{
			//Loop over the custom curves and add the actual keys
			for( auto CustomCurve : CustomCurves )
			{
				SmartName::UID_Type NameUID = Skeleton->GetUIDByName( USkeleton::AnimCurveMappingName, CustomCurve.Key );
				if( NameUID != SmartName::MaxUID )
				{
					float CurveValueAtTime = BlendedCurve.Get( NameUID ) * ValueScale;
					int32 KeyIndex = CustomCurve.Value->KeyAdd( ExportTime );
					CustomCurve.Value->KeySetValue( KeyIndex, CurveValueAtTime );
				}
			}
		}
	};

	IterateInsideAnimSequence( AnimSeq, AnimStartOffset, AnimEndOffset, AnimPlayRate, StartTime, ExportLambda );

	for( auto CustomCurve : CustomCurves )
	{
		CustomCurve.Value->KeyModifyEnd();
	}
}
void ExportAnimSequenceToFbx( FFbxExporter* Exporter, const UAnimSequence* AnimSeq,
							  const USkeletalMesh* SkelMesh,
							  TArray<FbxNode*>& BoneNodes,
							  FbxAnimLayer* InAnimLayer,
							  float AnimStartOffset,
							  float AnimEndOffset,
							  float AnimPlayRate,
							  float StartTime,
							  FbxScene* FBXScene )
{
	// stack allocator for extracting curve
	FMemMark Mark( FMemStack::Get() );

	USkeleton* Skeleton = AnimSeq->GetSkeleton();

	if( Skeleton == nullptr || !SetupAnimStack( AnimSeq, FBXScene ) )
	{
		// something is wrong
		return;
	}

	//Prepare root anim curves data to be exported
	TArray<FName> AnimCurveNames;
	TMap<FName, FbxAnimCurve*> CustomCurveMap;
	if( BoneNodes.Num() > 0 )
	{
		const FSmartNameMapping* AnimCurveMapping = Skeleton->GetSmartNameContainer( USkeleton::AnimCurveMappingName );

		if( AnimCurveMapping )
		{
			AnimCurveMapping->FillNameArray( AnimCurveNames );

			const UFbxExportOption* ExportOptions = GetExportOptions( Exporter );
			const bool bExportMorphTargetCurvesInMesh = ExportOptions && ExportOptions->bExportPreviewMesh && ExportOptions->bExportMorphTargets;

			for( auto AnimCurveName : AnimCurveNames )
			{
				const FCurveMetaData* CurveMetaData = AnimCurveMapping->GetCurveMetaData( AnimCurveName );

				//Only export the custom curve if it is not used in a MorphTarget that will be exported latter on.
				if( !( bExportMorphTargetCurvesInMesh && CurveMetaData && CurveMetaData->Type.bMorphtarget ) )
				{
					FbxProperty AnimCurveFbxProp = FbxProperty::Create( BoneNodes[ 0 ], FbxDoubleDT, TCHAR_TO_ANSI( *AnimCurveName.ToString() ) );
					AnimCurveFbxProp.ModifyFlag( FbxPropertyFlags::eAnimatable, true );
					AnimCurveFbxProp.ModifyFlag( FbxPropertyFlags::eUserDefined, true );
					FbxAnimCurve* AnimFbxCurve = AnimCurveFbxProp.GetCurve( InAnimLayer, true );
					CustomCurveMap.Add( AnimCurveName, AnimFbxCurve );
				}
			}
		}
	}

	ExportCustomAnimCurvesToFbx( CustomCurveMap, AnimSeq, AnimStartOffset, AnimEndOffset, AnimPlayRate, StartTime, 1.f, FBXScene );

	TArray<FCustomAttribute> CustomAttributes;

	// Add the animation data to the bone nodes
	for( int32 BoneIndex = 0; BoneIndex < BoneNodes.Num(); ++BoneIndex )
	{
		FbxNode* CurrentBoneNode = BoneNodes[ BoneIndex ];
		int32 BoneTreeIndex = Skeleton->GetSkeletonBoneIndexFromMeshBoneIndex( SkelMesh, BoneIndex );
		int32 BoneTrackIndex = Skeleton->GetRawAnimationTrackIndex( BoneTreeIndex, AnimSeq );
		FName BoneName = Skeleton->GetReferenceSkeleton().GetBoneName( BoneTreeIndex );

		CustomAttributes.Reset();
		//AnimSeq->GetDataModel()->GetAttributesForBone( BoneName, CustomAttributes );

		TArray<TPair<int32, FbxAnimCurve*>> FloatCustomAttributeIndices;
		TArray<TPair<int32, FbxAnimCurve*>> IntCustomAttributeIndices;

		// Setup custom attribute properties and curves
		for( int32 AttributeIndex = 0; AttributeIndex < CustomAttributes.Num(); ++AttributeIndex )
		{
			const FCustomAttribute& Attribute = CustomAttributes[ AttributeIndex ];
			const FName& AttributeName = Attribute.Name;

			const EVariantTypes VariantType = static_cast<EVariantTypes>( Attribute.VariantType );

			if( VariantType == EVariantTypes::Int32 )
			{
				FbxProperty AnimCurveFbxProp = FbxProperty::Create( CurrentBoneNode, FbxIntDT, TCHAR_TO_UTF8( *AttributeName.ToString() ) );
				AnimCurveFbxProp.ModifyFlag( FbxPropertyFlags::eAnimatable, true );
				AnimCurveFbxProp.ModifyFlag( FbxPropertyFlags::eUserDefined, true );

				FbxAnimCurve* AnimFbxCurve = AnimCurveFbxProp.GetCurve( InAnimLayer, true );
				AnimFbxCurve->KeyModifyBegin();
				IntCustomAttributeIndices.Emplace( AttributeIndex, AnimFbxCurve );
			}
			else if( VariantType == EVariantTypes::Float )
			{
				FbxProperty AnimCurveFbxProp = FbxProperty::Create( CurrentBoneNode, FbxFloatDT, TCHAR_TO_UTF8( *AttributeName.ToString() ) );
				AnimCurveFbxProp.ModifyFlag( FbxPropertyFlags::eAnimatable, true );
				AnimCurveFbxProp.ModifyFlag( FbxPropertyFlags::eUserDefined, true );

				FbxAnimCurve* AnimFbxCurve = AnimCurveFbxProp.GetCurve( InAnimLayer, true );
				AnimFbxCurve->KeyModifyBegin();
				FloatCustomAttributeIndices.Emplace( AttributeIndex, AnimFbxCurve );
			}
			else if( VariantType == EVariantTypes::String )
			{
				FbxProperty AnimCurveFbxProp = FbxProperty::Create( CurrentBoneNode, FbxStringDT, TCHAR_TO_UTF8( *AttributeName.ToString() ) );
				AnimCurveFbxProp.ModifyFlag( FbxPropertyFlags::eUserDefined, true );

				// String attributes can't be keyed, simply set a normal value.
				FString AttributeValue;
			#if ENGINE_MAJOR_VERSION == 4
				FCustomAttributesRuntime::GetAttributeValue( Attribute, 0.f, AttributeValue );
			#endif
				FbxString FbxValueString( TCHAR_TO_UTF8( *AttributeValue ) );
				AnimCurveFbxProp.Set( FbxValueString );
			}
			else
			{
				ensureMsgf( false, TEXT( "Trying to export unsupported custom attribte (float, int32 and FString are currently supported)" ) );
			}
		}

		// Create the transform AnimCurves
		const uint32 NumberOfCurves = 9;
		FbxAnimCurve* Curves[ NumberOfCurves ];

		// Individual curves for translation, rotation and scaling
		Curves[ 0 ] = CurrentBoneNode->LclTranslation.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true );
		Curves[ 1 ] = CurrentBoneNode->LclTranslation.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true );
		Curves[ 2 ] = CurrentBoneNode->LclTranslation.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true );

		Curves[ 3 ] = CurrentBoneNode->LclRotation.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true );
		Curves[ 4 ] = CurrentBoneNode->LclRotation.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true );
		Curves[ 5 ] = CurrentBoneNode->LclRotation.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true );

		Curves[ 6 ] = CurrentBoneNode->LclScaling.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true );
		Curves[ 7 ] = CurrentBoneNode->LclScaling.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true );
		Curves[ 8 ] = CurrentBoneNode->LclScaling.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true );

		if( BoneTrackIndex == INDEX_NONE )
		{
			// If this sequence does not have a track for the current bone, then skip it
			continue;
		}

		for( FbxAnimCurve* Curve : Curves )
		{
			Curve->KeyModifyBegin();
		}

		auto ExportLambda = [&]( float AnimTime, FbxTime ExportTime, bool bLastKey )
		{
			FTransform BoneAtom;
			AnimSeq->GetBoneTransform( BoneAtom, BoneTrackIndex, AnimTime, true );

			FbxAMatrix FbxMatrix = Converter.ConvertMatrix( BoneAtom.ToMatrixWithScale() );

			FbxVector4 Translation = Converter.ConvertToFbxPos( BoneAtom.GetTranslation() );
			FbxVector4 Rotation = Converter.ConvertToFbxRot( BoneAtom.GetRotation().Euler() );
			FbxVector4 Scale = Converter.ConvertToFbxScale( BoneAtom.GetScale3D() );
			FbxVector4 Vectors[ 3 ] = { Translation, Rotation, Scale };

			// Loop over each curve and channel to set correct values
			for( uint32 CurveIndex = 0; CurveIndex < 3; ++CurveIndex )
			{
				for( uint32 ChannelIndex = 0; ChannelIndex < 3; ++ChannelIndex )
				{
					uint32 OffsetCurveIndex = ( CurveIndex * 3 ) + ChannelIndex;

					int32 lKeyIndex = Curves[ OffsetCurveIndex ]->KeyAdd( ExportTime );
					Curves[ OffsetCurveIndex ]->KeySetValue( lKeyIndex, Vectors[ CurveIndex ][ ChannelIndex ] );
					Curves[ OffsetCurveIndex ]->KeySetInterpolation( lKeyIndex, bLastKey ? FbxAnimCurveDef::eInterpolationConstant : FbxAnimCurveDef::eInterpolationCubic );

					if( bLastKey )
					{
						Curves[ OffsetCurveIndex ]->KeySetConstantMode( lKeyIndex, FbxAnimCurveDef::eConstantStandard );
					}
				}
			}

		#if ENGINE_MAJOR_VERSION == 4
			for( TPair<int32, FbxAnimCurve*>& CurrentAttributeCurve : FloatCustomAttributeIndices )
			{
				float AttributeValue = 0.f;
				FCustomAttributesRuntime::GetAttributeValue( CustomAttributes[ CurrentAttributeCurve.Key ], AnimTime, AttributeValue );
				int32 KeyIndex = CurrentAttributeCurve.Value->KeyAdd( ExportTime );
				CurrentAttributeCurve.Value->KeySetValue( KeyIndex, AttributeValue );
			}

			for( TPair<int32, FbxAnimCurve*>& CurrentAttributeCurve : IntCustomAttributeIndices )
			{
				int32 AttributeValue = 0;
				FCustomAttributesRuntime::GetAttributeValue( CustomAttributes[ CurrentAttributeCurve.Key ], AnimTime, AttributeValue );
				int32 KeyIndex = CurrentAttributeCurve.Value->KeyAdd( ExportTime );
				CurrentAttributeCurve.Value->KeySetValue( KeyIndex, static_cast<float>( AttributeValue ) );
			}
		#endif
		};

		IterateInsideAnimSequence( AnimSeq, AnimStartOffset, AnimEndOffset, AnimPlayRate, StartTime, ExportLambda );

		for( FbxAnimCurve* Curve : Curves )
		{
			Curve->KeyModifyEnd();
		}

		auto MarkCurveEnd = []( auto& CurvesArray )
		{
			for( auto& CurvePair : CurvesArray )
			{
				CurvePair.Value->KeyModifyEnd();
			}
		};

		MarkCurveEnd( FloatCustomAttributeIndices );
		MarkCurveEnd( IntCustomAttributeIndices );
	}
}
#else
void IterateInsideAnimSequence( const UAnimSequence* AnimSeq, FFrameTime StartFrameTime, FFrameTime EndFrameTime, float FrameRateScale, float StartTime, TFunctionRef<void( double, FbxTime, bool )> IterationLambda )
{
	const double TimePerKey = AnimSeq->GetDataModel()->GetFrameRate().AsInterval();
	const double AnimTimeIncrement = TimePerKey * FrameRateScale;
	uint32 AnimFrameIndex = 0;

	FbxTime ExportTime;
	ExportTime.SetSecondDouble( StartTime );

	FbxTime ExportTimeIncrement;
	ExportTimeIncrement.SetSecondDouble( TimePerKey );

	// Step through each frame and add custom curve data
	bool bLastKey = false;
	FFrameTime FrameTime = StartFrameTime;
	const FFrameRate& FrameRate = AnimSeq->GetDataModel()->GetFrameRate();
	while( !bLastKey )
	{
		bLastKey = FrameTime > EndFrameTime;
		IterationLambda( FrameRate.AsSeconds( FrameTime ), ExportTime, bLastKey );

		ExportTime += ExportTimeIncrement;
		AnimFrameIndex++;
		FrameTime += FFrameTime::FromDecimal( FrameRateScale );
	}
}
void ExportAnimSequenceToFbx( FFbxExporter* Exporter, const UAnimSequence* AnimSeq, const USkeletalMesh* SkelMesh, TArray<FbxNode*>& BoneNodes, FbxAnimLayer* InAnimLayer, FFrameTime StartFrameTime, FFrameTime EndFrameTime, float FrameRateScale, float StartTime,
							  FbxScene* FBXScene )
{
	// stack allocator for extracting curve
	FMemMark Mark( FMemStack::Get() );

	USkeleton* Skeleton = AnimSeq->GetSkeleton();

	if( Skeleton == nullptr || !SetupAnimStack( AnimSeq, FBXScene ) )
	{
		// something is wrong
		return;
	}

	//Prepare root anim curves data to be exported
	TArray<FName> AnimCurveNames;
	TMap<FName, FbxAnimCurve*> CustomCurveMap;
	if( BoneNodes.Num() > 0 )
	{
		const FSmartNameMapping* AnimCurveMapping = Skeleton->GetSmartNameContainer( USkeleton::AnimCurveMappingName );

		if( AnimCurveMapping )
		{
			AnimCurveMapping->FillNameArray( AnimCurveNames );

			const UFbxExportOption* ExportOptions = Exporter->GetExportOptions();
			const bool bExportMorphTargetCurvesInMesh = ExportOptions && ExportOptions->bExportPreviewMesh && ExportOptions->bExportMorphTargets;

			for( auto AnimCurveName : AnimCurveNames )
			{
				const FCurveMetaData* CurveMetaData = AnimCurveMapping->GetCurveMetaData( AnimCurveName );

				//Only export the custom curve if it is not used in a MorphTarget that will be exported latter on.
				if( !( bExportMorphTargetCurvesInMesh && CurveMetaData && CurveMetaData->Type.bMorphtarget ) )
				{
					FbxProperty AnimCurveFbxProp = FbxProperty::Create( BoneNodes[ 0 ], FbxDoubleDT, TCHAR_TO_ANSI( *AnimCurveName.ToString() ) );
					AnimCurveFbxProp.ModifyFlag( FbxPropertyFlags::eAnimatable, true );
					AnimCurveFbxProp.ModifyFlag( FbxPropertyFlags::eUserDefined, true );
					FbxAnimCurve* AnimFbxCurve = AnimCurveFbxProp.GetCurve( InAnimLayer, true );
					CustomCurveMap.Add( AnimCurveName, AnimFbxCurve );
				}
			}
		}
	}

#if ENGINE_MAJOR_VERSION == 4 || (ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION <=1 )
	ExportCustomAnimCurvesToFbx( CustomCurveMap, AnimSeq, StartFrameTime, EndFrameTime, FrameRateScale, StartTime, 1.f, FBXScene );
#endif

	TArray<const FAnimatedBoneAttribute*> CustomAttributes;

	// Add the animation data to the bone nodes
	for( int32 BoneIndex = 0; BoneIndex < BoneNodes.Num(); ++BoneIndex )
	{
		FbxNode* CurrentBoneNode = BoneNodes[ BoneIndex ];
		const int32 BoneTreeIndex = Skeleton->GetSkeletonBoneIndexFromMeshBoneIndex( SkelMesh, BoneIndex );
		const FName BoneName = Skeleton->GetReferenceSkeleton().GetBoneName( BoneTreeIndex );
		const IAnimationDataModel* DataModel = AnimSeq->GetDataModel();

		CustomAttributes.Reset();
		DataModel->GetAttributesForBone( BoneName, CustomAttributes );

		TArray<TPair<int32, FbxAnimCurve*>> FloatCustomAttributeIndices;
		TArray<TPair<int32, FbxAnimCurve*>> IntCustomAttributeIndices;

		// Setup custom attribute properties and curves
		for( int32 AttributeIndex = 0; AttributeIndex < CustomAttributes.Num(); ++AttributeIndex )
		{
			if( const FAnimatedBoneAttribute* AttributePtr = CustomAttributes[ AttributeIndex ] )
			{
				const FAnimatedBoneAttribute& Attribute = *AttributePtr;

				const FName& AttributeName = Attribute.Identifier.GetName();
				const UScriptStruct* AttributeType = Attribute.Identifier.GetType();

				if( AttributeType == FIntegerAnimationAttribute::StaticStruct() )
				{
					FbxProperty AnimCurveFbxProp = FbxProperty::Create( CurrentBoneNode, FbxIntDT, TCHAR_TO_UTF8( *AttributeName.ToString() ) );
					AnimCurveFbxProp.ModifyFlag( FbxPropertyFlags::eAnimatable, true );
					AnimCurveFbxProp.ModifyFlag( FbxPropertyFlags::eUserDefined, true );

					FbxAnimCurve* AnimFbxCurve = AnimCurveFbxProp.GetCurve( InAnimLayer, true );
					AnimFbxCurve->KeyModifyBegin();
					IntCustomAttributeIndices.Emplace( AttributeIndex, AnimFbxCurve );
				}
				else if( AttributeType == FFloatAnimationAttribute::StaticStruct() )
				{
					FbxProperty AnimCurveFbxProp = FbxProperty::Create( CurrentBoneNode, FbxFloatDT, TCHAR_TO_UTF8( *AttributeName.ToString() ) );
					AnimCurveFbxProp.ModifyFlag( FbxPropertyFlags::eAnimatable, true );
					AnimCurveFbxProp.ModifyFlag( FbxPropertyFlags::eUserDefined, true );

					FbxAnimCurve* AnimFbxCurve = AnimCurveFbxProp.GetCurve( InAnimLayer, true );
					AnimFbxCurve->KeyModifyBegin();
					FloatCustomAttributeIndices.Emplace( AttributeIndex, AnimFbxCurve );
				}
				else if( AttributeType == FStringAnimationAttribute::StaticStruct() )
				{
					FbxProperty AnimCurveFbxProp = FbxProperty::Create( CurrentBoneNode, FbxStringDT, TCHAR_TO_UTF8( *AttributeName.ToString() ) );
					AnimCurveFbxProp.ModifyFlag( FbxPropertyFlags::eUserDefined, true );

					// String attributes can't be keyed, simply set a normal value.
					FStringAnimationAttribute EvaluatedAttribute = Attribute.Curve.Evaluate<FStringAnimationAttribute>( 0.f );

					FbxString FbxValueString( TCHAR_TO_UTF8( *EvaluatedAttribute.Value ) );
					AnimCurveFbxProp.Set( FbxValueString );
				}
				else
				{
					ensureMsgf( false, TEXT( "Trying to export unsupported custom attribte (float, int32 and FString are currently supported)" ) );
				}
			}
		}

		// Create the transform AnimCurves
		const uint32 NumberOfCurves = 9;
		FbxAnimCurve* Curves[ NumberOfCurves ];

		// Individual curves for translation, rotation and scaling
		Curves[ 0 ] = CurrentBoneNode->LclTranslation.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true );
		Curves[ 1 ] = CurrentBoneNode->LclTranslation.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true );
		Curves[ 2 ] = CurrentBoneNode->LclTranslation.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true );

		Curves[ 3 ] = CurrentBoneNode->LclRotation.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true );
		Curves[ 4 ] = CurrentBoneNode->LclRotation.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true );
		Curves[ 5 ] = CurrentBoneNode->LclRotation.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true );

		Curves[ 6 ] = CurrentBoneNode->LclScaling.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true );
		Curves[ 7 ] = CurrentBoneNode->LclScaling.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true );
		Curves[ 8 ] = CurrentBoneNode->LclScaling.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true );

		if( !DataModel->IsValidBoneTrackName( BoneName ) )
		{
			// If this sequence does not have a track for the current bone, then skip it
			continue;
		}

		for( FbxAnimCurve* Curve : Curves )
		{
			Curve->KeyModifyBegin();
		}

		auto ExportLambda = [DataModel, BoneName, AnimSeq, &FloatCustomAttributeIndices, &IntCustomAttributeIndices, &Curves, &CustomAttributes]( double AnimTime, FbxTime ExportTime, bool bLastKey )
		{
			const FTransform BoneAtom = DataModel->EvaluateBoneTrackTransform( BoneName, DataModel->GetFrameRate().AsFrameTime( AnimTime ), AnimSeq->Interpolation );
			const FbxAMatrix FbxMatrix = Converter.ConvertMatrix( BoneAtom.ToMatrixWithScale() );

			const FbxVector4 Translation = FbxMatrix.GetT();
			const FbxVector4 Rotation = FbxMatrix.GetR();
			const FbxVector4 Scale = FbxMatrix.GetS();
			const FbxVector4 Vectors[ 3 ] = { Translation, Rotation, Scale };

			// Loop over each curve and channel to set correct values
			for( uint32 CurveIndex = 0; CurveIndex < 3; ++CurveIndex )
			{
				for( uint32 ChannelIndex = 0; ChannelIndex < 3; ++ChannelIndex )
				{
					const uint32 OffsetCurveIndex = ( CurveIndex * 3 ) + ChannelIndex;

					const int32 lKeyIndex = Curves[ OffsetCurveIndex ]->KeyAdd( ExportTime );
					Curves[ OffsetCurveIndex ]->KeySetValue( lKeyIndex, Vectors[ CurveIndex ][ ChannelIndex ] );
					Curves[ OffsetCurveIndex ]->KeySetInterpolation( lKeyIndex, bLastKey ? FbxAnimCurveDef::eInterpolationConstant : FbxAnimCurveDef::eInterpolationCubic );

					if( bLastKey )
					{
						Curves[ OffsetCurveIndex ]->KeySetConstantMode( lKeyIndex, FbxAnimCurveDef::eConstantStandard );
					}
				}
			}

			for( const TPair<int32, FbxAnimCurve*>& CurrentAttributeCurve : FloatCustomAttributeIndices )
			{
				if( const FAnimatedBoneAttribute* AttributePtr = CustomAttributes[ CurrentAttributeCurve.Key ] )
				{
					ensure( AttributePtr->Identifier.GetType() == FFloatAnimationAttribute::StaticStruct() );

					const FFloatAnimationAttribute EvaluatedAttribute = AttributePtr->Curve.Evaluate<FFloatAnimationAttribute>( AnimTime );
					const int32 KeyIndex = CurrentAttributeCurve.Value->KeyAdd( ExportTime );
					CurrentAttributeCurve.Value->KeySetValue( KeyIndex, EvaluatedAttribute.Value );

				}
			}

			for( const TPair<int32, FbxAnimCurve*>& CurrentAttributeCurve : IntCustomAttributeIndices )
			{
				if( const FAnimatedBoneAttribute* AttributePtr = CustomAttributes[ CurrentAttributeCurve.Key ] )
				{
					ensure( AttributePtr->Identifier.GetType() == FIntegerAnimationAttribute::StaticStruct() );

					const FIntegerAnimationAttribute EvaluatedAttribute = AttributePtr->Curve.Evaluate<FIntegerAnimationAttribute>( AnimTime );
					const int32 KeyIndex = CurrentAttributeCurve.Value->KeyAdd( ExportTime );
					CurrentAttributeCurve.Value->KeySetValue( KeyIndex, static_cast<float>( EvaluatedAttribute.Value ) );
				}
			}
		};

		IterateInsideAnimSequence( AnimSeq, StartFrameTime, EndFrameTime, FrameRateScale, StartTime, ExportLambda );

		for( FbxAnimCurve* Curve : Curves )
		{
			Curve->KeyModifyEnd();
		}

		auto MarkCurveEnd = []( auto& CurvesArray )
		{
			for( auto& CurvePair : CurvesArray )
			{
				CurvePair.Value->KeyModifyEnd();
			}
		};

		MarkCurveEnd( FloatCustomAttributeIndices );
		MarkCurveEnd( IntCustomAttributeIndices );
	}
}
#endif
void ConvertTransformForBones( FTransform Trans, TransformComponent* Transform, bool IsRoot )
{
	FVector OriginalTranslation = Trans.GetTranslation();
	OriginalTranslation /= 100.0f;

	static bool DoFBXConversion = false;

	FQuat Quat = Trans.GetRotation();
	FVector Euler = Quat.Euler();
	FVector Translation = OriginalTranslation;
	if( DoFBXConversion )
	{
		//Using FBX conversion logic and add X*-1
		Translation = FVector( -OriginalTranslation.X,
							   -OriginalTranslation.Y,
								OriginalTranslation.Z );
		
		Euler = FVector( Euler.X,
						 -Euler.Y,
						 -Euler.Z );
	}
	if( IsRoot )
	{
		static FVector Add( 0, 0, 0 );// 180, 90, 270 );
		Euler += Add;
	}
	Quat = FQuat::MakeFromEuler( Euler );

	if( 0 )//CVarFBXPerActor.GetValueOnAnyThread() == 1 )
	{
		FRotator Rotator = FRotator::MakeFromEuler( FVector( 0, 0, 0 ) );
		Quat = Quat * Rotator.Quaternion();
	}

	FVector Scale = Trans.GetScale3D();

	if( 0 )//CVarFBXPerActor.GetValueOnAnyThread() == 1 )
	{
		float Temp = Scale.Y;
		Scale.Y = Scale.Z;
		Scale.Z = Temp;

		Temp = Scale.Z;
		Scale.Z = Scale.X;
		Scale.X = Temp;
	}

	Transform->LocalPosition[ 0 ] = Translation.X;
	Transform->LocalPosition[ 1 ] = Translation.Y;
	Transform->LocalPosition[ 2 ] = Translation.Z;

	Transform->LocalRotation[ 0 ] = Quat.X;
	Transform->LocalRotation[ 1 ] = Quat.Y;
	Transform->LocalRotation[ 2 ] = Quat.Z;
	Transform->LocalRotation[ 3 ] = Quat.W;

	Transform->LocalScale[ 0 ] = Scale.X;
	Transform->LocalScale[ 1 ] = Scale.Y;
	Transform->LocalScale[ 2 ] = Scale.Z;

	//if( IsRelative )
	{
		//Transform->LocalPosition[ 0 ] *= -1;
	}
}
void CorrectAnimTrackInterpolation( TArray<FbxNode*>& BoneNodes, FbxAnimLayer* InAnimLayer )
{
	// Add the animation data to the bone nodes
	for( int32 BoneIndex = 0; BoneIndex < BoneNodes.Num(); ++BoneIndex )
	{
		FbxNode* CurrentBoneNode = BoneNodes[ BoneIndex ];

		// Fetch the AnimCurves
		FbxAnimCurve* Curves[ 3 ];
		Curves[ 0 ] = CurrentBoneNode->LclRotation.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_X, true );
		Curves[ 1 ] = CurrentBoneNode->LclRotation.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_Y, true );
		Curves[ 2 ] = CurrentBoneNode->LclRotation.GetCurve( InAnimLayer, FBXSDK_CURVENODE_COMPONENT_Z, true );

		for( int32 CurveIndex = 0; CurveIndex < 3; ++CurveIndex )
		{
			FbxAnimCurve* CurrentCurve = Curves[ CurveIndex ];
			CurrentCurve->KeyModifyBegin();

			float CurrentAngleOffset = 0.f;
			for( int32 KeyIndex = 1; KeyIndex < CurrentCurve->KeyGetCount(); ++KeyIndex )
			{
				float PreviousOutVal = CurrentCurve->KeyGetValue( KeyIndex - 1 );
				float CurrentOutVal = CurrentCurve->KeyGetValue( KeyIndex );

				float DeltaAngle = ( CurrentOutVal + CurrentAngleOffset ) - PreviousOutVal;

				if( DeltaAngle >= 180 )
				{
					CurrentAngleOffset -= 360;
				}
				else if( DeltaAngle <= -180 )
				{
					CurrentAngleOffset += 360;
				}

				CurrentOutVal += CurrentAngleOffset;

				CurrentCurve->KeySetValue( KeyIndex, CurrentOutVal );
			}

			CurrentCurve->KeyModifyEnd();
		}
	}
}
void BindMeshToSkeleton( const USkeletalMesh* SkelMesh, FbxNode* MeshRootNode, TArray<FbxNode*>& BoneNodes, int32 LODIndex, FbxScene* FBXScene )
{
	const FSkeletalMeshModel* SkelMeshResource = SkelMesh->GetImportedModel();
	if( !SkelMeshResource->LODModels.IsValidIndex( LODIndex ) )
	{
		//We cannot bind the LOD if its not valid
		return;
	}
	const FSkeletalMeshLODModel& SourceModel = SkelMeshResource->LODModels[ LODIndex ];
	const int32 VertexCount = SourceModel.NumVertices;

	FbxAMatrix MeshMatrix;

	FbxScene* lScene = MeshRootNode->GetScene();
	if( lScene )
	{
		MeshMatrix = MeshRootNode->EvaluateGlobalTransform();
	}

	FbxGeometry* MeshAttribute = (FbxGeometry*)MeshRootNode->GetNodeAttribute();
	FbxSkin* Skin = FbxSkin::Create( FBXScene, "" );

	const int32 BoneCount = BoneNodes.Num();
	for( int32 BoneIndex = 0; BoneIndex < BoneCount; ++BoneIndex )
	{
		FbxNode* BoneNode = BoneNodes[ BoneIndex ];

		// Create the deforming cluster
		FbxCluster* CurrentCluster = FbxCluster::Create( FBXScene, "" );
		CurrentCluster->SetLink( BoneNode );
		CurrentCluster->SetLinkMode( FbxCluster::eTotalOne );

		// Add all the vertices that are weighted to the current skeletal bone to the cluster
		// NOTE: the bone influence indices contained in the vertex data are based on a per-chunk
		// list of verts.  The convert the chunk bone index to the mesh bone index, the chunk's
		// boneMap is needed
		int32 VertIndex = 0;
		const int32 SectionCount = SourceModel.Sections.Num();
		for( int32 SectionIndex = 0; SectionIndex < SectionCount; ++SectionIndex )
		{
			const FSkelMeshSection& Section = SourceModel.Sections[ SectionIndex ];
			if( 0 )//Section.HasClothingData() )
			{
				continue;
			}

			for( int32 SoftIndex = 0; SoftIndex < Section.SoftVertices.Num(); ++SoftIndex )
			{
				const FSoftSkinVertex& Vert = Section.SoftVertices[ SoftIndex ];

				for( int32 InfluenceIndex = 0; InfluenceIndex < MAX_TOTAL_INFLUENCES; ++InfluenceIndex )
				{
					int32 InfluenceBone = Section.BoneMap[ Vert.InfluenceBones[ InfluenceIndex ] ];
					float InfluenceWeight = Vert.InfluenceWeights[ InfluenceIndex ] / 255.f;

					if( InfluenceBone == BoneIndex && InfluenceWeight > 0.f )
					{
						CurrentCluster->AddControlPointIndex( VertIndex, InfluenceWeight );
					}
				}

				++VertIndex;
			}
		}

		// Now we have the Patch and the skeleton correctly positioned,
		// set the Transform and TransformLink matrix accordingly.
		CurrentCluster->SetTransformMatrix( MeshMatrix );

		FbxAMatrix LinkMatrix;
		if( lScene )
		{
			LinkMatrix = BoneNode->EvaluateGlobalTransform();
		}

		CurrentCluster->SetTransformLinkMatrix( LinkMatrix );

		// Add the clusters to the mesh by creating a skin and adding those clusters to that skin.
		Skin->AddCluster( CurrentCluster );
	}

	// Add the skin to the mesh after the clusters have been added
	MeshAttribute->AddDeformer( Skin );
}
void AddNodeRecursively( FbxArray<FbxNode*>& pNodeArray, FbxNode* pNode )
{
	if( pNode )
	{
		AddNodeRecursively( pNodeArray, pNode->GetParent() );

		if( pNodeArray.Find( pNode ) == -1 )
		{
			// Node not in the list, add it
			pNodeArray.Add( pNode );
		}
	}
}
void CreateBindPose( FbxNode* MeshRootNode, FbxScene* FBXScene )
{
	if( !MeshRootNode )
	{
		return;
	}

	// In the bind pose, we must store all the link's global matrix at the time of the bind.
	// Plus, we must store all the parent(s) global matrix of a link, even if they are not
	// themselves deforming any model.

	// Create a bind pose with the link list

	FbxArray<FbxNode*> lClusteredFbxNodes;
	int                       i, j;

	if( MeshRootNode->GetNodeAttribute() )
	{
		int lSkinCount = 0;
		int lClusterCount = 0;
		switch( MeshRootNode->GetNodeAttribute()->GetAttributeType() )
		{
			case FbxNodeAttribute::eMesh:
			case FbxNodeAttribute::eNurbs:
			case FbxNodeAttribute::ePatch:

				lSkinCount = ( (FbxGeometry*)MeshRootNode->GetNodeAttribute() )->GetDeformerCount( FbxDeformer::eSkin );
				//Go through all the skins and count them
				//then go through each skin and get their cluster count
				for( i = 0; i < lSkinCount; ++i )
				{
					FbxSkin* lSkin = (FbxSkin*)( (FbxGeometry*)MeshRootNode->GetNodeAttribute() )->GetDeformer( i, FbxDeformer::eSkin );
					lClusterCount += lSkin->GetClusterCount();
				}
				break;
		}
		//if we found some clusters we must add the node
		if( lClusterCount )
		{
			//Again, go through all the skins get each cluster link and add them
			for( i = 0; i < lSkinCount; ++i )
			{
				FbxSkin* lSkin = (FbxSkin*)( (FbxGeometry*)MeshRootNode->GetNodeAttribute() )->GetDeformer( i, FbxDeformer::eSkin );
				lClusterCount = lSkin->GetClusterCount();
				for( j = 0; j < lClusterCount; ++j )
				{
					FbxNode* lClusterNode = lSkin->GetCluster( j )->GetLink();
					AddNodeRecursively( lClusteredFbxNodes, lClusterNode );
				}

			}

			// Add the patch to the pose
			lClusteredFbxNodes.Add( MeshRootNode );
		}
	}

	// Now create a bind pose with the link list
	if( lClusteredFbxNodes.GetCount() )
	{
		// A pose must be named. Arbitrarily use the name of the patch node.
		FbxPose* lPose = FbxPose::Create( FBXScene, MeshRootNode->GetName() );

		// default pose type is rest pose, so we need to set the type as bind pose
		lPose->SetIsBindPose( true );

		for( i = 0; i < lClusteredFbxNodes.GetCount(); i++ )
		{
			FbxNode* lKFbxNode = lClusteredFbxNodes.GetAt( i );
			FbxMatrix lBindMatrix = lKFbxNode->EvaluateGlobalTransform();

			lPose->Add( lKFbxNode, lBindMatrix );
		}

		// Add the pose to the scene
		FBXScene->AddPose( lPose );
	}
}
FbxSurfaceMaterial* ExportMaterial( UMaterialInterface* MaterialInterface, FbxScene* FBXScene );
FbxNode* CreateMesh( FFbxExporter* Exporter, const USkeletalMesh* SkelMesh, const TCHAR* MeshName, int32 LODIndex, const UAnimSequence* AnimSeq /*= nullptr*/, const TArray<UMaterialInterface*>* OverrideMaterials /*= nullptr*/,
					 FbxScene* FBXScene )
{
	const FSkeletalMeshModel* SkelMeshResource = SkelMesh->GetImportedModel();
	if( !SkelMeshResource->LODModels.IsValidIndex( LODIndex ) )
	{
		//Return an empty node
		return FbxNode::Create( FBXScene, TCHAR_TO_UTF8( MeshName ) );
	}

	const FSkeletalMeshLODModel& SourceModel = SkelMeshResource->LODModels[ LODIndex ];

	//Current code works with 5.4 & hoodies with cloth from https://www.unrealengine.com/marketplace/en-US/product/modular-sorcerer-male-humans-fantasy-collection
	//const int32 VertexCount = SourceModel.GetNumNonClothingVertices();
	const int32 VertexCount = SourceModel.NumVertices;

	// Verify the integrity of the mesh.
	if( VertexCount == 0 ) return NULL;

	// Copy all the vertex data from the various chunks to a single buffer.
	// Makes the rest of the code in this function cleaner and easier to maintain.  
	TArray<FSoftSkinVertex> Vertices;
	//SourceModel.GetNonClothVertices( Vertices );
	SourceModel.GetVertices( Vertices );
	//if( Vertices.Num() != VertexCount ) return NULL;

	FbxMesh* Mesh = FbxMesh::Create( FBXScene, TCHAR_TO_UTF8( MeshName ) );

	//UTU - aparently skinning needs different rotation ?
	FRotator Rotator = FRotator::MakeFromEuler( FVector( -90, 0, 0 ) );//preview FBX the same as UE

	// Create and fill in the vertex position data source.
	Mesh->InitControlPoints( VertexCount );
	FbxVector4* ControlPoints = Mesh->GetControlPoints();
	for( int32 VertIndex = 0; VertIndex < VertexCount; ++VertIndex )
	{
		FVector Position = (FVector)Vertices[ VertIndex ].Position;
		//Position = Rotator.RotateVector( Position );
		ControlPoints[ VertIndex ] = Converter.ConvertToFbxPos( Position );
	}

	// Create Layer 0 to hold the normals
	FbxLayer* LayerZero = Mesh->GetLayer( 0 );
	if( LayerZero == NULL )
	{
		Mesh->CreateLayer();
		LayerZero = Mesh->GetLayer( 0 );
	}

	// Create and fill in the per-face-vertex normal data source.
	// We extract the Z-tangent and drop the X/Y-tangents which are also stored in the render mesh.
	FbxLayerElementNormal* LayerElementNormal = FbxLayerElementNormal::Create( Mesh, "" );

	LayerElementNormal->SetMappingMode( FbxLayerElement::eByControlPoint );
	// Set the normal values for every control point.
	LayerElementNormal->SetReferenceMode( FbxLayerElement::eDirect );

	for( int32 VertIndex = 0; VertIndex < VertexCount; ++VertIndex )
	{
		FVector Normal;
		#if ENGINE_MAJOR_VERSION >= 5
			FVector4f Normal4 = Vertices[ VertIndex ].TangentZ;
			Normal = FVector( Normal4.X, Normal4.Y, Normal4.Z );
		#else
			Normal = Vertices[ VertIndex ].TangentZ;
		#endif

		//Normal.Y *= -1;
		//Normal = Rotator.RotateVector( Normal );

		FbxVector4 FbxNormal = Converter.ConvertToFbxPos( Normal );

		LayerElementNormal->GetDirectArray().Add( FbxNormal );
	}

	LayerZero->SetNormals( LayerElementNormal );


	// Create and fill in the per-face-vertex texture coordinate data source(s).
	// Create UV for Diffuse channel.
	const int32 TexCoordSourceCount = SourceModel.NumTexCoords;
	TCHAR UVChannelName[ 32 ];
	for( int32 TexCoordSourceIndex = 0; TexCoordSourceIndex < TexCoordSourceCount; ++TexCoordSourceIndex )
	{
		FbxLayer* Layer = Mesh->GetLayer( TexCoordSourceIndex );
		if( Layer == NULL )
		{
			Mesh->CreateLayer();
			Layer = Mesh->GetLayer( TexCoordSourceIndex );
		}

		if( TexCoordSourceIndex == 1 )
		{
			FCString::Sprintf( UVChannelName, TEXT( "LightMapUV" ) );
		}
		else
		{
			FCString::Sprintf( UVChannelName, TEXT( "DiffuseUV" ) );
		}

		FbxLayerElementUV* UVDiffuseLayer = FbxLayerElementUV::Create( Mesh, TCHAR_TO_UTF8( UVChannelName ) );
		UVDiffuseLayer->SetMappingMode( FbxLayerElement::eByControlPoint );
		UVDiffuseLayer->SetReferenceMode( FbxLayerElement::eDirect );

		// Create the texture coordinate data source.
		for( int32 TexCoordIndex = 0; TexCoordIndex < VertexCount; ++TexCoordIndex )
		{
			#if ENGINE_MAJOR_VERSION == 4
			const FVector2D& TexCoord = Vertices[ TexCoordIndex ].UVs[ TexCoordSourceIndex ];
			#else
			const FVector2f& TexCoord = Vertices[ TexCoordIndex ].UVs[ TexCoordSourceIndex ];
			#endif
			UVDiffuseLayer->GetDirectArray().Add( FbxVector2( TexCoord.X, -TexCoord.Y + 1.0 ) );
		}

		Layer->SetUVs( UVDiffuseLayer, FbxLayerElement::eTextureDiffuse );
	}

	FbxLayerElementMaterial* MatLayer = FbxLayerElementMaterial::Create( Mesh, "" );
	MatLayer->SetMappingMode( FbxLayerElement::eByPolygon );
	MatLayer->SetReferenceMode( FbxLayerElement::eIndexToDirect );
	LayerZero->SetMaterials( MatLayer );


	// Create the per-material polygons sets.
	int32 SectionCount = SourceModel.Sections.Num();
	int32 ClothSectionVertexRemoveOffset = 0;
	TArray<TPair<uint32, uint32>> VertexIndexOffsetPairArray{ TPair<uint32, uint32>( 0,0 ) };
	for( int32 SectionIndex = 0; SectionIndex < SectionCount; ++SectionIndex )
	{
		const FSkelMeshSection& Section = SourceModel.Sections[ SectionIndex ];
		//if( Section.HasClothingData() )
		//{
		//	ClothSectionVertexRemoveOffset += Section.GetNumVertices();
		//	VertexIndexOffsetPairArray.Emplace( Section.BaseVertexIndex, ClothSectionVertexRemoveOffset );
		//	continue;
		//}

		int32 MatIndex = Section.MaterialIndex;

		// Static meshes contain one triangle list per element.
		int32 TriangleCount = Section.NumTriangles;

		// Copy over the index buffer into the FBX polygons set.
		for( int32 TriangleIndex = 0; TriangleIndex < TriangleCount; ++TriangleIndex )
		{
			Mesh->BeginPolygon( MatIndex );
			for( int32 PointIndex = 0; PointIndex < 3; PointIndex++ )
			{
				int32 VertexPositionIndex = SourceModel.IndexBuffer[ Section.BaseIndex + ( ( TriangleIndex * 3 ) + PointIndex ) ] - ClothSectionVertexRemoveOffset;
				check( VertexPositionIndex >= 0 );
				Mesh->AddPolygon( VertexPositionIndex );
			}
			Mesh->EndPolygon();
		}
	}

	if( Exporter->GetExportOptions()->VertexColor )
	{
		// Create and fill in the vertex color data source.
		FbxLayerElementVertexColor* VertexColor = FbxLayerElementVertexColor::Create( Mesh, "" );
		VertexColor->SetMappingMode( FbxLayerElement::eByControlPoint );
		VertexColor->SetReferenceMode( FbxLayerElement::eDirect );
		FbxLayerElementArrayTemplate<FbxColor>& VertexColorArray = VertexColor->GetDirectArray();
		LayerZero->SetVertexColors( VertexColor );

		for( int32 VertIndex = 0; VertIndex < VertexCount; ++VertIndex )
		{
			FLinearColor VertColor = Vertices[ VertIndex ].Color.ReinterpretAsLinear();
			VertexColorArray.Add( FbxColor( VertColor.R, VertColor.G, VertColor.B, VertColor.A ) );
		}
	}


	if( Exporter->GetExportOptions()->bExportMorphTargets && GetSkeleton(SkelMesh) ) //The skeleton can be null if this is a destructible mesh.
	{
		const FSmartNameMapping* SmartNameMapping = GetSkeleton( SkelMesh )->GetSmartNameContainer( USkeleton::AnimCurveMappingName );
		TMap<FName, FbxAnimCurve*> BlendShapeCurvesMap;

		if( GetMorphTargets( SkelMesh ).Num() )
		{
			// The original BlendShape Name was not saved during import, so we need to come up with a new one.
			const FString BlendShapeName( SkelMesh->GetName() + TEXT( "_blendShapes" ) );
			FbxBlendShape* BlendShape = FbxBlendShape::Create( Mesh, TCHAR_TO_UTF8( *BlendShapeName ) );
			bool bHasBadMorphTarget = false;

			for( UMorphTarget* MorphTarget : GetMorphTargets(SkelMesh) )
			{
				int32 DeformerIndex = Mesh->AddDeformer( BlendShape );
				FbxBlendShapeChannel* BlendShapeChannel = FbxBlendShapeChannel::Create( BlendShape, TCHAR_TO_UTF8( *MorphTarget->GetName() ) );

				if( BlendShape->AddBlendShapeChannel( BlendShapeChannel ) )
				{
					FbxShape* Shape = FbxShape::Create( BlendShapeChannel, TCHAR_TO_UTF8( *MorphTarget->GetName() ) );
					Shape->InitControlPoints( VertexCount );
					FbxVector4* ShapeControlPoints = Shape->GetControlPoints();

					// Replicate the base mesh in the shape control points to set up the data.
					for( int32 VertIndex = 0; VertIndex < VertexCount; ++VertIndex )
					{
						FVector Position = (FVector)Vertices[ VertIndex ].Position;

						//Position = Rotator.RotateVector( Position );

						ShapeControlPoints[ VertIndex ] = Converter.ConvertToFbxPos( Position );
					}

					int32 NumberOfDeltas = 0;
					const FMorphTargetDelta* MorphTargetDeltas = MorphTarget->GetMorphTargetDelta( LODIndex, NumberOfDeltas );
					for( int32 MorphTargetDeltaIndex = 0; MorphTargetDeltaIndex < NumberOfDeltas; ++MorphTargetDeltaIndex )
					{
						// Apply the morph target deltas to the control points.
						const FMorphTargetDelta& CurrentDelta = MorphTargetDeltas[ MorphTargetDeltaIndex ];
						uint32 RemappedSourceIndex = CurrentDelta.SourceIdx;

						if( VertexIndexOffsetPairArray.Num() > 1 )
						{
							//If the skeletal mesh contains clothing we need to remap the morph target index too.
							int32 UpperBoundIndex = Algo::UpperBoundBy( VertexIndexOffsetPairArray, RemappedSourceIndex,
																		[]( const auto& CurrentPair ) { return CurrentPair.Key; } ); //Value functor
							RemappedSourceIndex -= VertexIndexOffsetPairArray[ UpperBoundIndex - 1 ].Value;
						}

						if( RemappedSourceIndex < static_cast<uint32>( VertexCount ) )
						{
							ShapeControlPoints[ RemappedSourceIndex ] = Converter.ConvertToFbxPos( (FVector)Vertices[ RemappedSourceIndex ].Position + (FVector)CurrentDelta.PositionDelta );
						}
						else
						{
							bHasBadMorphTarget = true;
						}
					}

					BlendShapeChannel->AddTargetShape( Shape );
					FName MorphTargetName = MorphTarget->GetFName();
					if( AnimSeq && SmartNameMapping && SmartNameMapping->GetCurveMetaData( MorphTargetName ) && SmartNameMapping->GetCurveMetaData( MorphTargetName )->Type.bMorphtarget )
					{
						FbxAnimCurve* AnimCurve = Mesh->GetShapeChannel( DeformerIndex, BlendShape->GetBlendShapeChannelCount() - 1, AnimLayer, true );
						BlendShapeCurvesMap.Add( MorphTargetName, AnimCurve );
					}
				}
			}

			if( bHasBadMorphTarget )
			{
				UE_LOG( LogTemp, Warning, TEXT( "Encountered corrupted morphtarget(s) during export of SkeletalMesh %s, bad vertices were ignored." ), *SkelMesh->GetName() );
			}
		}

		if( AnimSeq && BlendShapeCurvesMap.Num() > 0 )
		{
			#if ENGINE_MAJOR_VERSION == 4 || (ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION <=1 )
			ExportCustomAnimCurvesToFbx( BlendShapeCurvesMap, AnimSeq,
										 0.f,		// AnimStartOffset
										 0.f,		// AnimEndOffset
										 1.f,		// AnimPlayRate
										 0.f,		// StartTime
										 100.f,		// ValueScale, for some reason we need to scale BlendShape curves by a factor of 100.
										 FBXScene );
			#endif
		}
	}

	FbxNode* MeshNode = FbxNode::Create( FBXScene, TCHAR_TO_UTF8( MeshName ) );
	MeshNode->SetNodeAttribute( Mesh );



	// Add the materials for the mesh
	const TArray<FSkeletalMaterial>& SkelMeshMaterials = GetMaterials(SkelMesh);
	int32 MaterialCount = SkelMeshMaterials.Num();

	for( int32 MaterialIndex = 0; MaterialIndex < MaterialCount; ++MaterialIndex )
	{
		UMaterialInterface* MatInterface = nullptr;

		if( OverrideMaterials && OverrideMaterials->IsValidIndex( MaterialIndex ) )
		{
			MatInterface = ( *OverrideMaterials )[ MaterialIndex ];
		}
		else
		{
			MatInterface = GetMaterials( SkelMesh )[ MaterialIndex ].MaterialInterface;
		}

		FbxSurfaceMaterial* FbxMaterial = NULL;
		if( LODIndex == 0 )
		{
			if( MatInterface && !FbxMaterials.Find( MatInterface ) )
			{
				FbxMaterial = ExportMaterial( MatInterface, FBXScene );
			}
		}
		else if( MatInterface )
		{
			if( FbxSurfaceMaterial** FbxMaterialPtr = FbxMaterials.Find( MatInterface ) )
			{
				FbxMaterial = *FbxMaterialPtr;
			}
		}

		if( !FbxMaterial )
		{
			// Note: The vertex data relies on there being a set number of Materials.  
			// If you try to add the same material again it will not be added, so create a 
			// default material with a unique name to ensure the proper number of materials

			TCHAR NewMaterialName[ MAX_SPRINTF ] = TEXT( "" );
			FCString::Sprintf( NewMaterialName, TEXT( "Fbx Default Material %i" ), MaterialIndex );

			FbxMaterial = FbxSurfaceLambert::Create( FBXScene, TCHAR_TO_UTF8( NewMaterialName ) );
			( (FbxSurfaceLambert*)FbxMaterial )->Diffuse.Set( FbxDouble3( 0.72, 0.72, 0.72 ) );
		}

		MeshNode->AddMaterial( FbxMaterial );
	}

	int32 SavedMaterialCount = MeshNode->GetMaterialCount();
	check( SavedMaterialCount == MaterialCount );

	return MeshNode;
}
FbxNode* ExportAnimSequence( FFbxExporter* Exporter, const UAnimSequence* AnimSeq, const USkeletalMesh* SkelMesh, bool bExportSkelMesh, const TCHAR* MeshName, FbxNode* ActorRootNode, const TArray<UMaterialInterface*>* OverrideMaterials /*= nullptr*/,
							 FbxScene* FBXScene )
{
	if( FBXScene == NULL || AnimSeq == NULL || SkelMesh == NULL )
	{
		return NULL;
	}


	FbxNode* RootNode = ( ActorRootNode ) ? ActorRootNode : FBXScene->GetRootNode();

	//Create a temporary node attach to the scene root.
	//This will allow us to do the binding without the scene transform (non uniform scale is not supported when binding the skeleton)
	//We then detach from the temp node and attach to the parent and remove the temp node
	FString FbxNodeName = FGuid::NewGuid().ToString( EGuidFormats::Digits );
	FbxNode* TmpNodeNoTransform = FbxNode::Create( FBXScene, TCHAR_TO_UTF8( *FbxNodeName ) );
	FBXScene->GetRootNode()->AddChild( TmpNodeNoTransform );


	// Create the Skeleton
	TArray<FbxNode*> BoneNodes;
	FbxNode* SkeletonRootNode = CreateSkeleton( SkelMesh, BoneNodes, FBXScene );
	TmpNodeNoTransform->AddChild( SkeletonRootNode );


	// Export the anim sequence
	{
		#if ENGINE_MAJOR_VERSION == 4 || (ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION <=1 )
			ExportAnimSequenceToFbx( Exporter, AnimSeq,
									 SkelMesh,
									 BoneNodes,
									 AnimLayer,
									 0.f,		// AnimStartOffset
									 0.f,		// AnimEndOffset
									 1.f,		// AnimPlayRate
									 0.f, 		// StartTime
									 FBXScene );
		#else
			ExportAnimSequenceToFbx( Exporter, AnimSeq,
									 SkelMesh,
									 BoneNodes,
									 AnimLayer,
									 // Start frame to export
									 FFrameTime( 0 ),
									 // Final frame to export
									 FFrameTime( AnimSeq->GetDataModel()->GetNumberOfFrames() ),
									 1.f,		// AnimPlayRate
									 0.f, 		// StartTime
									 FBXScene );
		#endif

		CorrectAnimTrackInterpolation( BoneNodes, AnimLayer );
	}


	// Optionally export the mesh
	if( bExportSkelMesh )
	{
		FString MeshNodeName;

		if( MeshName )
		{
			MeshNodeName = MeshName;
		}
		else
		{
			SkelMesh->GetName( MeshNodeName );
		}

		FbxNode* MeshRootNode = nullptr;
		if( Exporter->GetExportOptions()->LevelOfDetail && SkelMesh->GetLODNum() > 1 )
		{
			FString LodGroup_MeshName = MeshNodeName + TEXT( "_LodGroup" );
			MeshRootNode = FbxNode::Create( FBXScene, TCHAR_TO_UTF8( *LodGroup_MeshName ) );
			TmpNodeNoTransform->AddChild( MeshRootNode );
			LodGroup_MeshName = MeshNodeName + TEXT( "_LodGroupAttribute" );
			FbxLODGroup* FbxLodGroupAttribute = FbxLODGroup::Create( FBXScene, TCHAR_TO_UTF8( *LodGroup_MeshName ) );
			MeshRootNode->AddNodeAttribute( FbxLodGroupAttribute );

			FbxLodGroupAttribute->ThresholdsUsedAsPercentage = true;
			//Export an Fbx Mesh Node for every LOD and child them to the fbx node (LOD Group)
			for( int CurrentLodIndex = 0; CurrentLodIndex < SkelMesh->GetLODNum(); ++CurrentLodIndex )
			{
				FString FbxLODNodeName = MeshNodeName + TEXT( "_LOD" ) + FString::FromInt( CurrentLodIndex );
				if( CurrentLodIndex + 1 < SkelMesh->GetLODNum() )
				{
					//Convert the screen size to a threshold, it is just to be sure that we set some threshold, there is no way to convert this precisely
					double LodScreenSize = (double)( 10.0f / SkelMesh->GetLODInfo( CurrentLodIndex )->ScreenSize.Default );
					FbxLodGroupAttribute->AddThreshold( LodScreenSize );
				}
				FbxNode* FbxActorLOD = CreateMesh( Exporter, SkelMesh, *FbxLODNodeName, CurrentLodIndex, AnimSeq, OverrideMaterials, FBXScene );
				if( FbxActorLOD )
				{
					MeshRootNode->AddChild( FbxActorLOD );
					if( SkeletonRootNode )
					{
						// Bind the mesh to the skeleton
						BindMeshToSkeleton( SkelMesh, FbxActorLOD, BoneNodes, CurrentLodIndex, FBXScene );
						// Add the bind pose
						CreateBindPose( FbxActorLOD, FBXScene );
					}
				}
			}
		}
		else
		{
			const int32 LodIndex = 0;
			MeshRootNode = CreateMesh( Exporter, SkelMesh, *MeshNodeName, LodIndex, AnimSeq, OverrideMaterials, FBXScene );
			if( MeshRootNode )
			{
				TmpNodeNoTransform->AddChild( MeshRootNode );
				if( SkeletonRootNode )
				{
					// Bind the mesh to the skeleton
					BindMeshToSkeleton( SkelMesh, MeshRootNode, BoneNodes, LodIndex, FBXScene );

					// Add the bind pose
					CreateBindPose( MeshRootNode, FBXScene );
				}
			}
		}

		if( MeshRootNode )
		{
			TmpNodeNoTransform->RemoveChild( MeshRootNode );
			RootNode->AddChild( MeshRootNode );
		}
	}

	if( SkeletonRootNode )
	{
		TmpNodeNoTransform->RemoveChild( SkeletonRootNode );
		RootNode->AddChild( SkeletonRootNode );
	}

	FBXScene->GetRootNode()->RemoveChild( TmpNodeNoTransform );
	FBXScene->RemoveNode( TmpNodeNoTransform );

	return SkeletonRootNode;
}
void ExportObjectMetadata( const UObject* ObjectToExport, FbxNode* Node )
{
	if( ObjectToExport && Node )
	{
		// Retrieve the metadata map without creating it
		const TMap<FName, FString>* MetadataMap = UMetaData::GetMapForObject( ObjectToExport );
		if( MetadataMap )
		{
			static const FString MetadataPrefix( FBX_METADATA_PREFIX );
			for( const auto& MetadataIt : *MetadataMap )
			{
				// Export object metadata tags that are prefixed as FBX custom user-defined properties
				// Remove the prefix since it's for Unreal use only (and '.' is considered an invalid character for user property names in DCC like Maya)
				FString TagAsString = MetadataIt.Key.ToString();
				if( TagAsString.RemoveFromStart( MetadataPrefix ) )
				{
					// Remaining tag follows the format NodeName.PropertyName, so replace '.' with '_'
					TagAsString.ReplaceInline( TEXT( "." ), TEXT( "_" ) );

					if( MetadataIt.Value == TEXT( "true" ) || MetadataIt.Value == TEXT( "false" ) )
					{
						FbxProperty Property = FbxProperty::Create( Node, FbxBoolDT, TCHAR_TO_UTF8( *TagAsString ) );
						FbxBool ValueBool = MetadataIt.Value == TEXT( "true" ) ? true : false;

						Property.Set( ValueBool );
						Property.ModifyFlag( FbxPropertyFlags::eUserDefined, true );
					}
					else
					{
						FbxProperty Property = FbxProperty::Create( Node, FbxStringDT, TCHAR_TO_UTF8( *TagAsString ) );
						FbxString ValueString( TCHAR_TO_UTF8( *MetadataIt.Value ) );

						Property.Set( ValueString );
						Property.ModifyFlag( FbxPropertyFlags::eUserDefined, true );
					}
				}
			}
		}
	}
}
void ExportObjectMetadataToBones( const UObject* ObjectToExport, const TArray<FbxNode*>& Nodes )
{
	if( !ObjectToExport || Nodes.Num() == 0 )
	{
		return;
	}

	// Retrieve the metadata map without creating it
	const TMap<FName, FString>* MetadataMap = UMetaData::GetMapForObject( ObjectToExport );
	if( MetadataMap )
	{
		// Map the nodes to their names for fast access
		TMap<FString, FbxNode*> NameToNode;
		for( FbxNode* Node : Nodes )
		{
			NameToNode.Add( FString( Node->GetName() ), Node );
		}

		static const FString MetadataPrefix( FBX_METADATA_PREFIX );
		for( const auto& MetadataIt : *MetadataMap )
		{
			// Export object metadata tags that are prefixed as FBX custom user-defined properties
			// Remove the prefix since it's for Unreal use only (and '.' is considered an invalid character for user property names in DCC like Maya)
			FString TagAsString = MetadataIt.Key.ToString();
			if( TagAsString.RemoveFromStart( MetadataPrefix ) )
			{
				// Extract the node name from the metadata tag
				FString NodeName;
				int32 CharPos = INDEX_NONE;
				if( TagAsString.FindChar( TEXT( '.' ), CharPos ) )
				{
					NodeName = TagAsString.Left( CharPos );

					// The remaining part is the actual metadata tag
					TagAsString.RightChopInline( CharPos + 1, false ); // exclude the period
				}

				// Try to attach the metadata to its associated node by name
				FbxNode** Node = NameToNode.Find( NodeName );
				if( Node )
				{
					if( MetadataIt.Value == TEXT( "true" ) || MetadataIt.Value == TEXT( "false" ) )
					{
						FbxProperty Property = FbxProperty::Create( *Node, FbxBoolDT, TCHAR_TO_UTF8( *TagAsString ) );
						FbxBool ValueBool = MetadataIt.Value == TEXT( "true" ) ? true : false;

						Property.Set( ValueBool );
						Property.ModifyFlag( FbxPropertyFlags::eUserDefined, true );
					}
					else
					{
						FbxProperty Property = FbxProperty::Create( *Node, FbxStringDT, TCHAR_TO_UTF8( *TagAsString ) );
						FbxString ValueString( TCHAR_TO_UTF8( *MetadataIt.Value ) );

						Property.Set( ValueString );
						Property.ModifyFlag( FbxPropertyFlags::eUserDefined, true );
					}
				}
			}
		}
	}
}
void PrepareFBXExporter( FString CurrentFilename, UnFbx::FFbxExporter** Exporter, FbxScene** FBXScene );
void WriteToFile( FFbxExporter* UEExporter, FString Filename, FbxScene* FBXScene );

struct AnimationEntry
{
	const USkeletalMesh* SkeletalMesh;
	const UAnimSequence* AnimSeq;
	const TCHAR* MeshName;
	TArray<UMaterialInterface*> OverrideMaterials;
};
TArray< AnimationEntry > AnimationsToExport;
FbxNode* ExportSkeletalMeshToFbx( FFbxExporter* Exporter, const USkeletalMesh* SkeletalMesh, const UAnimSequence* AnimSeq, const TCHAR* MeshName, FbxNode* ActorRootNode, const TArray<UMaterialInterface*>* OverrideMaterials /*= nullptr*/,
								  FbxScene* FBXScene)
{
	if( AnimSeq )
	{
		AnimationEntry NewAnimationEntry;

		NewAnimationEntry.SkeletalMesh = SkeletalMesh;
		NewAnimationEntry.AnimSeq = AnimSeq;
		NewAnimationEntry.MeshName = MeshName;
		for( int i = 0; i < OverrideMaterials->Num(); i++ )
		{
			NewAnimationEntry.OverrideMaterials.Add( ( *OverrideMaterials )[ i ] );
		}
		AnimationsToExport.Add( NewAnimationEntry );
	}
	//else
	{
		//Create a temporary node attach to the scene root.
		//This will allow us to do the binding without the scene transform (non uniform scale is not supported when binding the skeleton)
		//We then detach from the temp node and attach to the parent and remove the temp node
		FString FbxNodeName = FGuid::NewGuid().ToString( EGuidFormats::Digits );
		FbxNode* TmpNodeNoTransform = FbxNode::Create( FBXScene, TCHAR_TO_UTF8( *FbxNodeName ) );
		FBXScene->GetRootNode()->AddChild( TmpNodeNoTransform );

		TArray<FbxNode*> BoneNodes;

		// Add the skeleton to the scene
		FbxNode* SkeletonRootNode = CreateSkeleton( SkeletalMesh, BoneNodes, FBXScene );
		if( SkeletonRootNode )
		{
			TmpNodeNoTransform->AddChild( SkeletonRootNode );
		}

		FbxNode* MeshRootNode = nullptr;
		if( UTUSettings->ExportLODs && SkeletalMesh->GetLODNum() > 1 )
		{
			FString LodGroup_MeshName = FString( MeshName ) + TEXT( "_LodGroup" );
			MeshRootNode = FbxNode::Create( FBXScene, TCHAR_TO_UTF8( *LodGroup_MeshName ) );
			TmpNodeNoTransform->AddChild( MeshRootNode );
			LodGroup_MeshName = FString( MeshName ) + TEXT( "_LodGroupAttribute" );
			FbxLODGroup* FbxLodGroupAttribute = FbxLODGroup::Create( FBXScene, TCHAR_TO_UTF8( *LodGroup_MeshName ) );
			MeshRootNode->AddNodeAttribute( FbxLodGroupAttribute );

			FbxLodGroupAttribute->ThresholdsUsedAsPercentage = true;
			//Export an Fbx Mesh Node for every LOD and child them to the fbx node (LOD Group)
			for( int CurrentLodIndex = 0; CurrentLodIndex < SkeletalMesh->GetLODNum(); ++CurrentLodIndex )
			{
				FString FbxLODNodeName = FString( MeshName ) + TEXT( "_LOD" ) + FString::FromInt( CurrentLodIndex );
				if( CurrentLodIndex + 1 < SkeletalMesh->GetLODNum() )
				{
					//Convert the screen size to a threshold, it is just to be sure that we set some threshold, there is no way to convert this precisely
					double LodScreenSize = (double)( 10.0f / SkeletalMesh->GetLODInfo( CurrentLodIndex )->ScreenSize.Default );
					FbxLodGroupAttribute->AddThreshold( LodScreenSize );
				}
				const UAnimSequence* NullAnimSeq = nullptr;
				FbxNode* FbxActorLOD = CreateMesh( Exporter, SkeletalMesh, *FbxLODNodeName, CurrentLodIndex, NullAnimSeq, OverrideMaterials, FBXScene );
				if( FbxActorLOD )
				{
					MeshRootNode->AddChild( FbxActorLOD );
					if( SkeletonRootNode )
					{
						// Bind the mesh to the skeleton
						BindMeshToSkeleton( SkeletalMesh, FbxActorLOD, BoneNodes, CurrentLodIndex, FBXScene );
						// Add the bind pose
						CreateBindPose( FbxActorLOD, FBXScene );
					}
				}
			}
		}
		else
		{
			const int32 LODIndex = 0;
			const UAnimSequence* NullAnimSeq = nullptr;
			FString FbxMeshName = FString( MeshName );// +TEXT( "_LOD0" );
			MeshRootNode = CreateMesh( Exporter, SkeletalMesh, *FbxMeshName, LODIndex, NullAnimSeq, OverrideMaterials, FBXScene );
			if( MeshRootNode )
			{
				TmpNodeNoTransform->AddChild( MeshRootNode );
				if( SkeletonRootNode )
				{
					// Bind the mesh to the skeleton
					BindMeshToSkeleton( SkeletalMesh, MeshRootNode, BoneNodes, 0, FBXScene );

					// Add the bind pose
					CreateBindPose( MeshRootNode, FBXScene );
				}
			}
		}

		if( SkeletonRootNode )
		{
			TmpNodeNoTransform->RemoveChild( SkeletonRootNode );
			ActorRootNode->AddChild( SkeletonRootNode );
		}

		ExportObjectMetadataToBones( GetSkeleton(SkeletalMesh), BoneNodes );

		if( MeshRootNode )
		{
			TmpNodeNoTransform->RemoveChild( MeshRootNode );
			ActorRootNode->AddChild( MeshRootNode );
			ExportObjectMetadata( SkeletalMesh, MeshRootNode );
		}

		FBXScene->GetRootNode()->RemoveChild( TmpNodeNoTransform );
		FBXScene->RemoveNode( TmpNodeNoTransform );
		return SkeletonRootNode;
	}

	return NULL;
}
#if ENGINE_MAJOR_VERSION == 4
	TArray<UMaterialInterface*> GetArrayOfMaterials( TArray<UMaterialInterface*>& ArrayType )
#else
	TArray<UMaterialInterface*> GetArrayOfMaterials( TArray<TObjectPtr<class UMaterialInterface>>& NewArrayType )
#endif
{
	#if ENGINE_MAJOR_VERSION == 4
		return ArrayType;
	#else
		TArray<UMaterialInterface*> Array;
		for( int i = 0; i < NewArrayType.Num(); i++ )
		{
			Array.Add( NewArrayType[ i ] );
		}	
		return Array;
	#endif
}
void ExportSkeletalMeshComponent( FFbxExporter* Exporter, USkeletalMeshComponent* SkelMeshComp, const TCHAR* MeshName, FbxNode* ActorRootNode, INodeNameAdapter& NodeNameAdapter, bool bSaveAnimSeq, FbxScene* FBXScene )
{
	if( SkelMeshComp && GetSkeletalMesh( SkelMeshComp ) )
	{
		UAnimSequence* AnimSeq = ( bSaveAnimSeq && SkelMeshComp->GetAnimationMode() == EAnimationMode::AnimationSingleNode ) ? GetAnimationSequence( SkelMeshComp ) : NULL;
		#if ENGINE_MAJOR_VERSION == 4
			FbxNode* SkeletonRootNode = ExportSkeletalMeshToFbx( Exporter, SkelMeshComp->SkeletalMesh, AnimSeq, MeshName, ActorRootNode, &SkelMeshComp->OverrideMaterials, FBXScene );
		#else
			TArray<UMaterialInterface*> Materials = GetArrayOfMaterials( SkelMeshComp->OverrideMaterials );
			FbxNode* SkeletonRootNode = ExportSkeletalMeshToFbx( Exporter, GetSkeletalMesh( SkelMeshComp ), AnimSeq, MeshName, ActorRootNode, &Materials, FBXScene );
		#endif

		if( SkeletonRootNode )
		{
			FbxSkeletonRoots.Add( SkelMeshComp, SkeletonRootNode );
			NodeNameAdapter.AddFbxNode( SkelMeshComp, SkeletonRootNode );
		}
	}
}
FbxNode* ExportActor( FFbxExporter* Exporter, AActor* Actor, bool bExportComponents, INodeNameAdapter& NodeNameAdapter, bool bSaveAnimSeq /*= true*/, FbxScene* FBXScene )
{
	// Verify that this actor isn't already exported, create a structure for it
	// and buffer it.
	FbxNode* ActorNode = FindActor( Actor, &NodeNameAdapter );
	if( ActorNode == NULL )
	{
		FString FbxNodeName = NodeNameAdapter.GetActorNodeName( Actor );
		FbxNodeName = GetFbxObjectName( FbxNodeName, NodeNameAdapter );
		FbxNodeName = FixUnicodeCharacters( FbxNodeName );
		ActorNode = FbxNode::Create( FBXScene, TCHAR_TO_UTF8( *FbxNodeName ) );

		AActor* ParentActor = Actor->GetAttachParentActor();
		// this doesn't work with skeletalmeshcomponent
		FbxNode* ParentNode = FindActor( ParentActor, &NodeNameAdapter );
		FVector ActorLocation, ActorRotation, ActorScale;

		TArray<AActor*> AttachedActors;
		Actor->GetAttachedActors( AttachedActors );
		const bool bHasAttachedActors = AttachedActors.Num() != 0;

		// For cameras and lights: always add a rotation to get the correct coordinate system.
		FTransform RotationDirectionConvert = FTransform::Identity;
		const bool bIsCameraActor = Actor->IsA( ACameraActor::StaticClass() );
		const bool bIsLightActor = Actor->IsA( ALight::StaticClass() );
		if( bIsCameraActor || bIsLightActor )
		{
			if( bIsCameraActor )
			{
				FRotator Rotator = FFbxDataConverter::GetCameraRotation().GetInverse();
				RotationDirectionConvert = FTransform( Rotator );
			}
			else if( bIsLightActor )
			{
				FRotator Rotator = FFbxDataConverter::GetLightRotation().GetInverse();
				RotationDirectionConvert = FTransform( Rotator );
			}
		}

		//If the parent is the root or is not export use the root node as the parent
		if( bKeepHierarchy && ParentNode )
		{
			// Set the default position of the actor on the transforms
			// The transformation is different from FBX's Z-up: invert the Y-axis for translations and the Y/Z angle values in rotations.
			const FTransform RelativeTransform = RotationDirectionConvert * Actor->GetTransform().GetRelativeTransform( ParentActor->GetTransform() );
			ActorLocation = RelativeTransform.GetTranslation();
			ActorRotation = RelativeTransform.GetRotation().Euler();
			ActorScale = RelativeTransform.GetScale3D();
		}
		else
		{
			ParentNode = FBXScene->GetRootNode();
			// Set the default position of the actor on the transforms
			// The transformation is different from FBX's Z-up: invert the Y-axis for translations and the Y/Z angle values in rotations.
			if( ParentActor != NULL )
			{
				//In case the parent was not export, get the absolute transform
				const FTransform AbsoluteTransform = RotationDirectionConvert * Actor->GetTransform();
				ActorLocation = AbsoluteTransform.GetTranslation();
				ActorRotation = AbsoluteTransform.GetRotation().Euler();
				ActorScale = AbsoluteTransform.GetScale3D();
			}
			else
			{
				const FTransform ConvertedTransform = RotationDirectionConvert * Actor->GetTransform();
				ActorLocation = ConvertedTransform.GetTranslation();
				ActorRotation = ConvertedTransform.GetRotation().Euler();
				ActorScale = ConvertedTransform.GetScale3D();
			}
		}

		ParentNode->AddChild( ActorNode );
		FbxActors.Add( Actor, ActorNode );
		NodeNameAdapter.AddFbxNode( Actor, ActorNode );

		// Set the default position of the actor on the transforms
		// The transformation is different from FBX's Z-up: invert the Y-axis for translations and the Y/Z angle values in rotations.
		bool SetIdentity = true;
		if( SetIdentity )
		{
			ActorNode->LclRotation.Set( Converter.ConvertToFbxRot( FVector( 90, 0, 0 )));//used to work
			//ActorNode->LclRotation.Set( Converter.ConvertToFbxRot( FVector( 90, 180, 0 ) ) );//rotate for similar preview angle
		}
		else
		{
			ActorNode->LclTranslation.Set( Converter.ConvertToFbxPos( ActorLocation ) );
			ActorNode->LclRotation.Set( Converter.ConvertToFbxRot( ActorRotation ) );
			ActorNode->LclScaling.Set( Converter.ConvertToFbxScale( ActorScale ) );
		}

		if( bExportComponents )
		{
			TInlineComponentArray<USceneComponent*> ComponentsToExport;
			for( UActorComponent* ActorComp : Actor->GetComponents() )
			{
				USceneComponent* Component = Cast<USceneComponent>( ActorComp );

				if( Component == nullptr || Component->bHiddenInGame )
				{
					//Skip hidden component like camera mesh or other editor helper
					continue;
				}

				UStaticMeshComponent* StaticMeshComp = Cast<UStaticMeshComponent>( Component );
				USkeletalMeshComponent* SkelMeshComp = Cast<USkeletalMeshComponent>( Component );
				UChildActorComponent* ChildActorComp = Cast<UChildActorComponent>( Component );

				if( StaticMeshComp && StaticMeshComp->GetStaticMesh() )
				{
					ComponentsToExport.Add( StaticMeshComp );
				}
				else if( SkelMeshComp && GetSkeletalMesh( SkelMeshComp ) )
				{
					ComponentsToExport.Add( SkelMeshComp );
				}
				else if( Component->IsA( UCameraComponent::StaticClass() ) )
				{
					ComponentsToExport.Add( Component );
				}
				else if( Component->IsA( ULightComponent::StaticClass() ) )
				{
					ComponentsToExport.Add( Component );
				}
				else if( ChildActorComp && ChildActorComp->GetChildActor() )
				{
					ComponentsToExport.Add( ChildActorComp );
				}
			}

			for( int32 CompIndex = 0; CompIndex < ComponentsToExport.Num(); ++CompIndex )
			{
				USceneComponent* Component = ComponentsToExport[ CompIndex ];

				RotationDirectionConvert = FTransform::Identity;
				// For cameras and lights: always add a rotation to get the correct coordinate system
				// Unless we are parented to an Actor of the same type, since the rotation direction was already added
				if( Component->IsA( UCameraComponent::StaticClass() ) || Component->IsA( ULightComponent::StaticClass() ) )
				{
					if( !bIsCameraActor && Component->IsA( UCameraComponent::StaticClass() ) )
					{
						FRotator Rotator = FFbxDataConverter::GetCameraRotation().GetInverse();
						RotationDirectionConvert = FTransform( Rotator );
					}
					else if( !bIsLightActor && Component->IsA( ULightComponent::StaticClass() ) )
					{
						FRotator Rotator = FFbxDataConverter::GetLightRotation().GetInverse();
						RotationDirectionConvert = FTransform( Rotator );
					}
				}

				FbxNode* ExportNode = ActorNode;
				if( ComponentsToExport.Num() > 1 )
				{
					// This actor has multiple components
					// create a child node under the actor for each component
					FbxNode* CompNode = FbxNode::Create( FBXScene, TCHAR_TO_UTF8( *Component->GetName() ) );

					if( Component != Actor->GetRootComponent() )
					{
						// Transform is relative to the root component
						const FTransform RelativeTransform = RotationDirectionConvert * Component->GetComponentToWorld().GetRelativeTransform( Actor->GetTransform() );
						CompNode->LclTranslation.Set( Converter.ConvertToFbxPos( RelativeTransform.GetTranslation() ) );
						CompNode->LclRotation.Set( Converter.ConvertToFbxRot( RelativeTransform.GetRotation().Euler() ) );
						CompNode->LclScaling.Set( Converter.ConvertToFbxScale( RelativeTransform.GetScale3D() ) );
					}

					ExportNode = CompNode;
					ActorNode->AddChild( CompNode );
				}
				// If this actor has attached actors, don't allow its non root component components to contribute to the transform
				else if( Component != Actor->GetRootComponent() && !bHasAttachedActors )
				{
					// Merge the component relative transform in the ActorNode transform since this is the only component to export and its not the root
					const FTransform RelativeTransform = RotationDirectionConvert * Component->GetComponentToWorld().GetRelativeTransform( Actor->GetTransform() );

					FTransform ActorTransform( FRotator::MakeFromEuler( ActorRotation ).Quaternion(), ActorLocation, ActorScale );
					FTransform TotalTransform = RelativeTransform * ActorTransform;

					ActorNode->LclTranslation.Set( Converter.ConvertToFbxPos( TotalTransform.GetLocation() ) );
					ActorNode->LclRotation.Set( Converter.ConvertToFbxRot( TotalTransform.GetRotation().Euler() ) );
					ActorNode->LclScaling.Set( Converter.ConvertToFbxScale( TotalTransform.GetScale3D() ) );
				}

				UStaticMeshComponent* StaticMeshComp = Cast<UStaticMeshComponent>( Component );
				USkeletalMeshComponent* SkelMeshComp = Cast<USkeletalMeshComponent>( Component );
				UChildActorComponent* ChildActorComp = Cast<UChildActorComponent>( Component );

				if( StaticMeshComp && StaticMeshComp->GetStaticMesh() )
				{
					if( USplineMeshComponent* SplineMeshComp = Cast<USplineMeshComponent>( StaticMeshComp ) )
					{
						//ExportSplineMeshToFbx( SplineMeshComp, *SplineMeshComp->GetName(), ExportNode );
					}
					else if( UInstancedStaticMeshComponent* InstancedMeshComp = Cast<UInstancedStaticMeshComponent>( StaticMeshComp ) )
					{
						//ExportInstancedMeshToFbx( InstancedMeshComp, *InstancedMeshComp->GetName(), ExportNode );
					}
					else
					{
						const int32 LODIndex = ( StaticMeshComp->ForcedLodModel > 0 ? StaticMeshComp->ForcedLodModel - 1 : /* auto-select*/ 0 );
						const int32 LightmapUVChannel = -1;
						const TArray<FStaticMaterial>* MaterialOrderOverride = nullptr;
						const TArray<UMaterialInterface*> Materials = StaticMeshComp->GetMaterials();
						const FColorVertexBuffer* ColorBuffer = nullptr;

						//Original name is a blueprint name
						//TODO : temporary fix, LODs are not exported through this !
						FString FbxLODNodeName = StaticMeshComp->GetStaticMesh()->GetName();
						FbxLODNodeName += TEXT( "_LOD0" );
						ExportNode->SetName( TCHAR_TO_UTF8( *FbxLODNodeName ) );
						ExportStaticMeshToFbx( Exporter, StaticMeshComp->GetStaticMesh(), LODIndex, *StaticMeshComp->GetName(), ExportNode, LightmapUVChannel, ColorBuffer, MaterialOrderOverride, &Materials, FBXScene );
					}
				}
				else if( SkelMeshComp && GetSkeletalMesh( SkelMeshComp ) )
				{
					ExportSkeletalMeshComponent( Exporter, SkelMeshComp, *GetSkeletalMesh(SkelMeshComp)->GetName(), ExportNode, NodeNameAdapter, bSaveAnimSeq, FBXScene );
				}
				// If this actor has attached actors, don't allow a camera component to determine the node attributes because that would alter the transform
				else if( Component->IsA( UCameraComponent::StaticClass() ) && !bHasAttachedActors )
				{
					//FbxCamera* Camera = FbxCamera::Create( Scene, TCHAR_TO_UTF8( *Component->GetName() ) );
					//FillFbxCameraAttribute( ActorNode, Camera, Cast<UCameraComponent>( Component ) );
					//ExportNode->SetNodeAttribute( Camera );
				}
				else if( Component->IsA( ULightComponent::StaticClass() ) && !bHasAttachedActors )
				{
					//FbxLight* Light = FbxLight::Create( Scene, TCHAR_TO_UTF8( *Component->GetName() ) );
					//FillFbxLightAttribute( Light, ActorNode, Cast<ULightComponent>( Component ) );
					//ExportNode->SetNodeAttribute( Light );
				}
				else if( ChildActorComp && ChildActorComp->GetChildActor() )
				{
					FbxNode* ChildActorNode = ExportActor( Exporter, ChildActorComp->GetChildActor(), true, NodeNameAdapter, bSaveAnimSeq, FBXScene );
					FbxActors.Add( ChildActorComp->GetChildActor(), ChildActorNode );
					NodeNameAdapter.AddFbxNode( ChildActorComp->GetChildActor(), ChildActorNode );
				}
			}
		}

	}

	return ActorNode;
}
void ExportStaticMesh( FFbxExporter* Exporter, AActor* Actor, UStaticMeshComponent* StaticMeshComponent, INodeNameAdapter& NodeNameAdapter, FbxScene* FBXScene )
{
	//if( Exporter->Scene == NULL || Actor == NULL || StaticMeshComponent == NULL )
	//{
	//	return;
	//}

	// Retrieve the static mesh rendering information at the correct LOD level.
	UStaticMesh* StaticMesh = StaticMeshComponent->GetStaticMesh();
	if( StaticMesh == NULL || !StaticMesh->HasValidRenderData() )
	{
		return;
	}
	FString FbxNodeName = NodeNameAdapter.GetActorNodeName( Actor );
	FString FbxMeshName = StaticMesh->GetName();// .Replace( TEXT( "-" ), TEXT( "_" ) );
	FbxMeshName = FixUnicodeCharacters( FbxMeshName );
	FColorVertexBuffer* ColorBuffer = NULL;

	if( UTUSettings->ExportLODs && StaticMesh->GetNumLODs() > 1 )
	{
		//Create a fbx LOD Group node
		FbxNode* FbxActor = ExportActor( Exporter, Actor, false, NodeNameAdapter, true, FBXScene );
		FString FbxLODGroupName = NodeNameAdapter.GetActorNodeName( Actor );
		FbxLODGroupName += TEXT( "_LodGroup" );
		FbxLODGroupName = GetFbxObjectName( FbxLODGroupName, NodeNameAdapter );
		FbxLODGroup* FbxLodGroupAttribute = FbxLODGroup::Create( FBXScene, TCHAR_TO_UTF8( *FbxLODGroupName ) );
		FbxActor->AddNodeAttribute( FbxLodGroupAttribute );
		FbxLodGroupAttribute->ThresholdsUsedAsPercentage = true;
		//Export an Fbx Mesh Node for every LOD and child them to the fbx node (LOD Group)
		for( int CurrentLodIndex = 0; CurrentLodIndex < StaticMesh->GetNumLODs(); ++CurrentLodIndex )
		{
			if( CurrentLodIndex < StaticMeshComponent->LODData.Num() )
			{
				ColorBuffer = StaticMeshComponent->LODData[ CurrentLodIndex ].OverrideVertexColors;
			}
			else
			{
				ColorBuffer = nullptr;
			}
			FString FbxLODNodeName = StaticMesh->GetName();// NodeNameAdapter.GetActorNodeName( Actor );
			FbxLODNodeName += TEXT( "_LOD" ) + FString::FromInt( CurrentLodIndex );
			FbxLODNodeName = GetFbxObjectName( FbxLODNodeName, NodeNameAdapter );
			FbxNode* FbxActorLOD = FbxNode::Create( FBXScene, TCHAR_TO_UTF8( *FbxLODNodeName ) );
			FbxActor->AddChild( FbxActorLOD );
			if( CurrentLodIndex + 1 < StaticMesh->GetNumLODs() )
			{
				//Convert the screen size to a threshold, it is just to be sure that we set some threshold, there is no way to convert this precisely
				double LodScreenSize = (double)( 10.0f / GetRenderData( StaticMesh )->ScreenSize[ CurrentLodIndex ].Default );
				FbxLodGroupAttribute->AddThreshold( LodScreenSize );
			}

			const int32 LightmapUVChannel = -1;
			const TArray<FStaticMaterial>* MaterialOrderOverride = nullptr;
			const TArray<UMaterialInterface*> Materials = GetMaterialsToBeUsedInFBX( StaticMeshComponent );			
			ExportStaticMeshToFbx( Exporter, StaticMesh, CurrentLodIndex, *FbxMeshName, FbxActorLOD, LightmapUVChannel, ColorBuffer, MaterialOrderOverride,  &Materials, FBXScene );
		}
	}
	else
	{
		const int32 LODIndex = ( StaticMeshComponent->ForcedLodModel > 0 ? StaticMeshComponent->ForcedLodModel - 1 : /* auto-select*/ 0 );
		if( LODIndex != INDEX_NONE && LODIndex < StaticMeshComponent->LODData.Num() )
		{
			ColorBuffer = StaticMeshComponent->LODData[ LODIndex ].OverrideVertexColors;
		}
		FbxNode* FbxActor = ExportActor( Exporter, Actor, false, NodeNameAdapter, true, FBXScene );

		FString FbxLODNodeName = StaticMesh->GetName();
		FbxLODNodeName = FixUnicodeCharacters( FbxLODNodeName );
		FbxActor->SetName( TCHAR_TO_UTF8( *FbxLODNodeName ) );

		const int32 LightmapUVChannel = -1;
		const TArray<FStaticMaterial>* MaterialOrderOverride = nullptr;
		const TArray<UMaterialInterface*> Materials = GetMaterialsToBeUsedInFBX( StaticMeshComponent );
		ExportStaticMeshToFbx( Exporter, StaticMesh, LODIndex, *FbxMeshName, FbxActor, LightmapUVChannel, ColorBuffer, MaterialOrderOverride, &Materials, FBXScene );
	}
}
void ExportLevelMesh( FFbxExporter* Exporter, ULevel* InLevel, bool bExportLevelGeometry, TArray<AActor*>& ActorToExport, INodeNameAdapter& NodeNameAdapter, bool bSaveAnimSeq, FbxScene* FBXScene )
{
	if( InLevel == NULL )
	{
		return;
	}

	if( bExportLevelGeometry )
	{		
		// Exports the level's scene geometry
		// the vertex number of Model must be more than 2 (at least a triangle panel)
		//if( InLevel->Model != NULL && InLevel->Model->VertexBuffer.Vertices.Num() > 2 && InLevel->Model->MaterialIndexBuffers.Num() > 0 )
		//{
		//	// create a FbxNode
		//	FbxNode* Node = FbxNode::Create( TheScene, "LevelMesh" );
		//
		//	// set the shading mode to view texture
		//	Node->SetShadingMode( FbxNode::eTextureShading );
		//	Node->LclScaling.Set( FbxVector4( 1.0, 1.0, 1.0 ) );
		//
		//	TheScene->GetRootNode()->AddChild( Node );
		//
		//	// Export the mesh for the world
		//	//Exporter->ExportModel( InLevel->Model, Node, "Level Mesh" );
		//}
	}

	//Sort the hierarchy to make sure parent come first
	//Exporter->SortActorsHierarchy( ActorToExport );
	int32 ActorCount = ActorToExport.Num();
	for( int32 ActorIndex = 0; ActorIndex < ActorCount; ++ActorIndex )
	{
		AActor* Actor = ActorToExport[ ActorIndex ];
		//We export only valid actor
		if( Actor == nullptr )
			continue;

		bool bIsBlueprintClass = false;
		if( UClass* ActorClass = Actor->GetClass() )
		{
			// Check if we export the actor as a blueprint
			bIsBlueprintClass = UBlueprint::GetBlueprintFromClass( ActorClass ) != nullptr;
		}

		//Blueprint can be any type of actor so it must be done first
		if( bIsBlueprintClass )
		{
			// Export blueprint actors and all their components.
			//ExportActor( Exporter, Actor, true, NodeNameAdapter, bSaveAnimSeq );

			TArray<UActorComponent*> comps;
			Actor->GetComponents( comps );
			
			for( int i = 0; i < comps.Num(); i++ )
			{
				UActorComponent* AC = comps[ i ];
				UClass* Class = AC->GetClass();
				UStaticMeshComponent* StaticMeshComp = dynamic_cast<UStaticMeshComponent*>( AC );
				USkeletalMeshComponent* SkeletalMeshComp = dynamic_cast<USkeletalMeshComponent*>( AC );
				if( StaticMeshComp )
				{
					ExportStaticMesh( Exporter, Actor, StaticMeshComp, NodeNameAdapter, FBXScene );
				}
				if( SkeletalMeshComp )
				{
					ExportActor( Exporter, Actor, true, NodeNameAdapter, bSaveAnimSeq, FBXScene );
				}
			}			
		}
		//else if( Actor->IsA( ALight::StaticClass() ) )
		//{
		//	Exporter->ExportLight( (ALight*)Actor, NodeNameAdapter );
		//}
		else if( Actor->IsA( AStaticMeshActor::StaticClass() ) )
		{
			ExportStaticMesh( Exporter, Actor, CastChecked<AStaticMeshActor>( Actor )->GetStaticMeshComponent(), NodeNameAdapter, FBXScene );
		}
		//else if( Actor->IsA( ALandscapeProxy::StaticClass() ) )
		//{
		//	Exporter->ExportLandscape( CastChecked<ALandscapeProxy>( Actor ), false, NodeNameAdapter );
		//}
		//else if( Actor->IsA( ABrush::StaticClass() ) )
		//{
		//	// All brushes should be included within the world geometry exported above.
		//	Exporter->ExportBrush( (ABrush*)Actor, NULL, 0, NodeNameAdapter );
		//}
		//else if( Actor->IsA( AEmitter::StaticClass() ) )
		//{
		//	Exporter->ExportActor( Actor, false, NodeNameAdapter, bSaveAnimSeq ); // Just export the placement of the particle emitter.
		//}
		//else if( Actor->IsA( ACameraActor::StaticClass() ) )
		//{
		//	Exporter->ExportCamera( CastChecked<ACameraActor>( Actor ), false, NodeNameAdapter );
		//}
		else
		{
			// Export any other type of actors and all their components.
			ExportActor( Exporter, Actor, true, NodeNameAdapter, bSaveAnimSeq, FBXScene );
		}
	}
}
FbxScene* CreateDocument( FFbxExporter* Exporter )
{
	SdkManager = FbxManager::Create();

	// create an IOSettings object
	FbxIOSettings* ios = FbxIOSettings::Create( SdkManager, "IOSROOT");
	SdkManager->SetIOSettings( ios );

	DefaultCamera = NULL;

	FbxScene* RetScene = FbxScene::Create( SdkManager, "" );

	// create scene info
	FbxDocumentInfo* SceneInfo = FbxDocumentInfo::Create( SdkManager, "SceneInfo" );
	SceneInfo->mTitle = "Unreal FBX Exporter";
	SceneInfo->mSubject = "Export FBX meshes from Unreal";
	SceneInfo->Original_ApplicationVendor.Set( "Ciprian Stanciu" );
	SceneInfo->Original_ApplicationName.Set( "UnrealToUnity" );
	SceneInfo->Original_ApplicationVersion.Set( "1.39" );
	SceneInfo->LastSaved_ApplicationVendor.Set( "Ciprian Stanciu" );
	SceneInfo->LastSaved_ApplicationName.Set( "UnrealToUnity" );
	SceneInfo->LastSaved_ApplicationVersion.Set( "1.39" );

	RetScene->SetSceneInfo( SceneInfo );

	//FbxScene->GetGlobalSettings().SetOriginalUpAxis(KFbxAxisSystem::Max);
	FbxAxisSystem::EFrontVector FrontVector = (FbxAxisSystem::EFrontVector)-FbxAxisSystem::eParityOdd;
	if( GetExportOptions( Exporter )->bForceFrontXAxis )
		FrontVector = FbxAxisSystem::eParityEven;

	const FbxAxisSystem UnrealZUp( FbxAxisSystem::eZAxis, FrontVector, FbxAxisSystem::eRightHanded );
	RetScene->GetGlobalSettings().SetAxisSystem( UnrealZUp );
	RetScene->GetGlobalSettings().SetOriginalUpAxis( UnrealZUp );
	// Maya use cm by default
	RetScene->GetGlobalSettings().SetSystemUnit( FbxSystemUnit::cm );
	//FbxScene->GetGlobalSettings().SetOriginalSystemUnit( KFbxSystemUnit::m );

	//bSceneGlobalTimeLineSet = false;
	RetScene->GetGlobalSettings().SetTimeMode( FbxTime::eDefaultMode );

	// setup anim stack
	AnimStack = FbxAnimStack::Create( RetScene, "Unreal Take" );
	//KFbxSet<KTime>(AnimStack->LocalStart, KTIME_ONE_SECOND);
	AnimStack->Description.Set( "Animation Take for Unreal." );

	// this take contains one base layer. In fact having at least one layer is mandatory.
	AnimLayer = FbxAnimLayer::Create( RetScene, "Base Layer" );
	AnimStack->AddMember( AnimLayer );

	return RetScene;
}
void CloseDocument(FbxScene* FBXScene)
{
	FbxActors.Reset();
	FbxSkeletonRoots.Reset();
	FbxMaterials.Reset();
	FbxMeshes.Reset();
	FbxCollisionMeshes.Reset();
	FbxNodeNameToIndexMap.Reset();

	if( FBXScene )
	{
		FBXScene->Destroy();
		FBXScene = NULL;
	}
	//bSceneGlobalTimeLineSet = false;
}
#ifdef IOS_REF
#undef  IOS_REF
#define IOS_REF (*(SdkManager->GetIOSettings()))
#endif
void WriteToFile( FFbxExporter* UEExporter, FString Filename, FbxScene* FBXScene )
{
	int32 Major, Minor, Revision;
	bool Status = true;

	int32 FileFormat = -1;
	bool bEmbedMedia = false;
	bool bASCII = GetExportOptions( UEExporter )->bASCII;

	// Create an exporter.
	FbxExporter* Exporter = FbxExporter::Create( SdkManager, "" );

	// set file format
	// Write in fall back format if pEmbedMedia is true
	if( bASCII )
	{
		FileFormat = SdkManager->GetIOPluginRegistry()->FindWriterIDByDescription( "FBX ascii (*.fbx)" );
	}
	else
	{
		FileFormat = SdkManager->GetIOPluginRegistry()->GetNativeWriterFormat();
	}

	// Set the export states. By default, the export states are always set to 
	// true except for the option eEXPORT_TEXTURE_AS_EMBEDDED. The code below 
	// shows how to change these states.

	IOS_REF.SetBoolProp( EXP_FBX_MATERIAL, true );
	IOS_REF.SetBoolProp( EXP_FBX_TEXTURE, true );
	IOS_REF.SetBoolProp( EXP_FBX_EMBEDDED, bEmbedMedia );
	IOS_REF.SetBoolProp( EXP_FBX_SHAPE, true );
	IOS_REF.SetBoolProp( EXP_FBX_GOBO, true );
	IOS_REF.SetBoolProp( EXP_FBX_ANIMATION, true );
	IOS_REF.SetBoolProp( EXP_FBX_GLOBAL_SETTINGS, true );
	IOS_REF.SetBoolProp( EXP_ASCIIFBX, bASCII );

	//Get the compatibility from the editor settings
	const char* CompatibilitySetting = FBX_2013_00_COMPATIBLE;
	const EFbxExportCompatibility FbxExportCompatibility = GetExportOptions( UEExporter )->FbxExportCompatibility;
	switch( FbxExportCompatibility )
	{
		case EFbxExportCompatibility::FBX_2011:
			CompatibilitySetting = FBX_2011_00_COMPATIBLE;
			break;
		case EFbxExportCompatibility::FBX_2012:
			CompatibilitySetting = FBX_2012_00_COMPATIBLE;
			break;
		case EFbxExportCompatibility::FBX_2013:
			CompatibilitySetting = FBX_2013_00_COMPATIBLE;
			break;
		case EFbxExportCompatibility::FBX_2014:
			CompatibilitySetting = FBX_2014_00_COMPATIBLE;
			break;
		case EFbxExportCompatibility::FBX_2016:
			CompatibilitySetting = FBX_2016_00_COMPATIBLE;
			break;
		case EFbxExportCompatibility::FBX_2018:
			CompatibilitySetting = FBX_2018_00_COMPATIBLE;
			break;
		#if ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 26
		case EFbxExportCompatibility::FBX_2019:
			CompatibilitySetting = FBX_2019_00_COMPATIBLE;
			break;
		case EFbxExportCompatibility::FBX_2020:
			CompatibilitySetting = FBX_2020_00_COMPATIBLE;
			break;
		#endif
		default:
			CompatibilitySetting = FBX_2013_00_COMPATIBLE;
			break;
	}

	// We export using FBX 2013 format because many users are still on that version and FBX 2014 files has compatibility issues with
	// normals when importing to an earlier version of the plugin
	if( !Exporter->SetFileExportVersion( CompatibilitySetting, FbxSceneRenamer::eNone ) )
	{
		UE_LOG( LogTemp, Warning, TEXT( "Call to KFbxExporter::SetFileExportVersion(FBX_2013_00_COMPATIBLE) to export 2013 fbx file format failed.\n" ) );
	}

	// Initialize the exporter by providing a filename.
	std::string ANSIStr = ToANSIString( *Filename );
	//const char* UTF8_FileName = TCHAR_TO_UTF8( Filename );
	//int WideLen = wcslen( Filename );
	//int UTF8Len = strlen( UTF8_FileName );
	if( !Exporter->Initialize( ANSIStr.c_str(), FileFormat, SdkManager->GetIOSettings()) )
	{
		UE_LOG( LogTemp, Warning, TEXT( "Call to KFbxExporter::Initialize() failed.\n" ) );
		auto ErrorString = Exporter->GetStatus().GetErrorString();
		FString Str = ErrorString;
		UE_LOG( LogTemp, Warning, TEXT( "Error returned: %s\n\n" ), *Str );
		return;
	}

	FbxManager::GetFileFormatVersion( Major, Minor, Revision );
	UE_LOG( LogTemp, Warning, TEXT( "FBX version number for this version of the FBX SDK is %d.%d.%d\n\n" ), Major, Minor, Revision );

	// Export the scene.
	Status = Exporter->Export( FBXScene );
	if( !Status )
	{
		const char* ErrorString = Exporter->GetStatus().GetErrorString();
		FString Str = ErrorString;
		FString DialogText = FString::Printf( TEXT(
			"Error!\n\n"
			"Could not save Mesh %s !\n"
			"Status = %s"
			"\n"
			"Do you have enough free space on that drive ?\n"
			"Do you have permission to save files there ?\n" ), *Filename, *Str );
		FText Txt = FText::FromString( DialogText );
		FMessageDialog::Open( EAppMsgType::Ok, Txt );
	}

	// Destroy the exporter.
	Exporter->Destroy();

	CloseDocument( FBXScene );

	return;
}

UFbxExportOption* GlobalFBXExportOptions = nullptr;
void PrepareFBXExporter( FString CurrentFilename, UnFbx::FFbxExporter** Exporter, FbxScene** FBXScene )
{
	*Exporter = UnFbx::FFbxExporter::GetInstance();
	(*Exporter)->SetExportOptionsOverride(GlobalFBXExportOptions);

	*FBXScene = CreateDocument( *Exporter );
}
bool ExportCancel = false;
bool ShowFBXDialog = false;

void ExportFBXForActor( AActor *Actor, FString CurrentFilename )
{	
	UWorld* World = Actor->GetWorld();

	UnFbx::FFbxExporter* Exporter = UnFbx::FFbxExporter::GetInstance();
	
	if( !GlobalFBXExportOptions )
	{
		ExportCancel = false;
		//Show the fbx export dialog options
		bool ExportAll = false;
		if ( ShowFBXDialog )
			Exporter->FillExportOptions( false, true, CurrentFilename, ExportCancel, ExportAll );
		GlobalFBXExportOptions = GetExportOptions( Exporter );
	}
	else
		Exporter->SetExportOptionsOverride( GlobalFBXExportOptions );

	if( !ExportCancel )
	{
		auto TheScene = CreateDocument( Exporter );

		GWarn->StatusUpdate( 0, 1, NSLOCTEXT( "UnrealEd", "ExportingToFBX", "Exporting To FBX" ) );
		{
			ULevel* Level = World->PersistentLevel;

			//if( bSelectedOnly )
			//{
			//	Exporter->ExportBSP( World->GetModel(), true );
			//}

			INodeNameAdapter NodeNameAdapter;
			bool bSaveAnimSeq = true;

			TArray<AActor*> ActorToExport;
			ActorToExport.Add( Actor );
			//Exporter->ExportLevelMesh( Level, bSelectedOnly, NodeNameAdapter );
			ExportLevelMesh( Exporter, Level, true, ActorToExport, NodeNameAdapter, bSaveAnimSeq, TheScene );

			// Export streaming levels and actors
			//for( int32 CurLevelIndex = 0; CurLevelIndex < World->GetNumLevels(); ++CurLevelIndex )
			//{
			//	ULevel* CurLevel = World->GetLevel( CurLevelIndex );
			//	if( CurLevel != NULL && CurLevel != Level )
			//	{
			//		Exporter->ExportLevelMesh( CurLevel, bSelectedOnly, NodeNameAdapter );
			//	}
			//}
		}
		WriteToFile( Exporter , CurrentFilename, TheScene );
	}

	Exporter->SetExportOptionsOverride( nullptr );
}
bool ShouldExportActor(AActor* A)
{
	ALODActor* LODActor = Cast< ALODActor >( A );
	if( LODActor )
		return false;
	AGroupActor* GroupActor = Cast< AGroupActor >( A );
	if( GroupActor )
		return false;
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 0
	AWorldPartitionHLOD* HLODActor = Cast< AWorldPartitionHLOD >( A );
	if( HLODActor )
		return false;
#endif

	return true;
}
bool ClearMetas = false;
extern GameObject* GameObjectForTrees;


void DoExportScene( UWorld* World, FString ExportFolder )
{
	GGlobalExportFolder = ExportFolder;

#if WITH_EDITOR

	UObject* ShaderErrorMaterial = StaticLoadObject( UMaterialInterface::StaticClass(), nullptr, TEXT( "/Engine/EngineMaterials/EmissiveTexturedMaterial" ) );
	UObject* ShaderErrorTexture = StaticLoadObject( UTexture2D::StaticClass(), nullptr, TEXT( "/UnrealToUnity/ShaderDidntCompile" ) );
	ShaderErrorTexture2D = Cast<UTexture2D>( ShaderErrorTexture );
	MaterialParentForShaderError = Cast<UMaterialInterface>( ShaderErrorMaterial );
	if( MaterialParentForShaderError && ShaderErrorTexture2D )
	{
		ShaderErrorMID = UMaterialInstanceDynamic::Create( MaterialParentForShaderError, nullptr );
		ShaderErrorMID->SetTextureParameterValue( TEXT( "Texture" ), ShaderErrorTexture2D );
		ShaderErrorMID->AddToRoot();
		MaterialParentForShaderError->AddToRoot();
	}

	GlobalFeatureLevel = GMaxRHIFeatureLevel;
	GlobalQualityLevel = GetCachedScalabilityCVars().MaterialQualityLevel;

	ProcessingState = 0;
	//Don't clear prefabs when reusing them
	if( !ReusePrefabs )
	{
		AllMaterials.clear();
		MeshList.clear();
		AllTextures.clear();
	}
	MaterialNames.Reset();

	FString AssetsFolder = GetAssetsFolder();
	FString ShadersFolder = AssetsFolder + TEXT("Shaders/");
	FString ScriptsFolder = AssetsFolder + TEXT( "Scripts/");
	FString ProjectSettingsFolder = AssetsFolder + TEXT( "../ProjectSettings/");
	FString SettingsFolder = AssetsFolder + TEXT( "Settings/");
	FString PackagesFolder = AssetsFolder + TEXT( "../Packages/");
	FString HDRPDefaultResourcesFolder = AssetsFolder + TEXT( "../Assets/HDRPDefaultResources/");

	if( ClearMetas )
	{
		IFileManager& FileMan = IFileManager::Get();

		TArray<FString> DictionaryList;
		
		FileMan.FindFilesRecursive( DictionaryList, *AssetsFolder, TEXT( "*.meta" ), true, false );

		for( int i = 0; i < DictionaryList.Num(); i++ )
		{
			FString File = DictionaryList[ i ];
			bool Result = FPlatformFileManager::Get().GetPlatformFile().DeleteFile( *File );
			if( !Result )
			{
			}
		}

		bool RemoveLibrary = false;
		if( RemoveLibrary )
		{
			FString LibraryDir = GetAssetsFolder();
			LibraryDir += TEXT( "../Library");
			bool DeletedLibrary = FPlatformFileManager::Get().GetPlatformFile().DeleteDirectoryRecursively( *LibraryDir );
		}

		FString MaterialsDir = GetAssetsFolder();
		MaterialsDir += TEXT( "/Materials");
		bool DeletedMaterials = FPlatformFileManager::Get().GetPlatformFile().DeleteDirectoryRecursively( *MaterialsDir );

		FString MeshesDir = GetAssetsFolder();
		MeshesDir += TEXT( "/Meshes");
		bool DeletedMeshes = FPlatformFileManager::Get().GetPlatformFile().DeleteDirectoryRecursively( *MeshesDir );
	}
	//if( UTUSettings->Engine == EngineType::GODOT )
	//{
	//	FString GodotCacheFolder = GetAssetsFolder();
	//	GodotCacheFolder += TEXT( ".godot" );
	//	bool DeletedLibrary = FPlatformFileManager::Get().GetPlatformFile().DeleteDirectoryRecursively( *GodotCacheFolder );
	//}

	if( UTUSettings->Engine == EngineType::UNITY )
	{
		bool Mismatch = WarnAboutRenderPipelineMismatch( UTUSettings->ScriptableRenderPipeline );
		if( Mismatch )
			return;
	}

	CurrentWorld = World;

	VerifyOrCreateDirectory( GGlobalExportFolder );
	VerifyOrCreateDirectory( AssetsFolder );

	if( UTUSettings->Engine == EngineType::UNITY )
	{
		VerifyOrCreateDirectory( ShadersFolder );
		VerifyOrCreateDirectory( ProjectSettingsFolder );
		VerifyOrCreateDirectory( ScriptsFolder );

		if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_URP )
		{
			CopyToOutput( TEXT( "URP/ProjectSettings.asset" ), TEXT( "ProjectSettings/ProjectSettings.asset" ), false );
			CopyToOutput( TEXT( "URP/GraphicsSettings.asset" ), TEXT( "ProjectSettings/GraphicsSettings.asset" ), false );
			CopyToOutput( TEXT( "URP/ProjectVersion.txt" ), TEXT( "ProjectSettings/ProjectVersion.txt" ), false );
			CopyToOutput( TEXT( "URP/QualitySettings.asset" ), TEXT( "ProjectSettings/QualitySettings.asset" ), false );
		}
		else if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
		{
			CopyToOutput( TEXT( "HDRP/ProjectSettings.asset" ), TEXT( "ProjectSettings/ProjectSettings.asset" ), false );
			CopyToOutput( TEXT( "HDRP/GraphicsSettings.asset" ), TEXT( "ProjectSettings/GraphicsSettings.asset" ), false );
			CopyToOutput( TEXT( "HDRP/ProjectVersion.txt" ), TEXT( "ProjectSettings/ProjectVersion.txt" ), false );
		}
		else
		{
			CopyToOutput( TEXT( "ProjectSettings.asset" ), TEXT( "ProjectSettings/ProjectSettings.asset" ), false );
			CopyToOutput( TEXT( "ProjectVersion.txt" ), TEXT( "ProjectSettings/ProjectVersion.txt" ), false );
		}

		CopyToOutput( TEXT( "Utilities.cs" ), TEXT( "Assets/Scripts/Utilities.cs" ), false );
		CopyToOutput( TEXT( "TreeInstanceComponent.cs" ), TEXT( "Assets/Scripts/TreeInstanceComponent.cs" ), false );
		CopyToOutput( TEXT( "TreeInstanceComponent.cs.meta" ), TEXT( "Assets/Scripts/TreeInstanceComponent.cs.meta" ), false );
		CopyToOutput( TEXT( "InstancedMesh.cs" ), TEXT( "Assets/Scripts/InstancedMesh.cs" ), false );

		VerifyOrCreateDirectory( PackagesFolder );

		if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_BUILTIN )
		{
			CopyToOutput( TEXT( "manifest.json" ), TEXT( "/Packages/manifest.json" ), false );
			CopyToOutput( TEXT( "packages-lock.json" ), TEXT( "/Packages/packages-lock.json" ), false );
		}
		else if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_URP )
		{
			VerifyOrCreateDirectory( SettingsFolder );

			CopyToOutput( TEXT( "URP/ForwardRenderer.asset" ), TEXT( "/Assets/Settings/ForwardRenderer.asset" ), false );
			CopyToOutput( TEXT( "URP/ForwardRenderer.asset.meta" ), TEXT( "/Assets/Settings/ForwardRenderer.asset.meta" ), false );
			CopyToOutput( TEXT( "URP/UniversalRP-HighQuality.asset" ), TEXT( "/Assets/Settings/UniversalRP-HighQuality.asset" ), false );			
			CopyToOutput( TEXT( "URP/UniversalRP-HighQuality.asset.meta" ), TEXT( "/Assets/Settings/UniversalRP-HighQuality.asset.meta" ), false );
			CopyToOutput( TEXT( "URP/manifest.json" ), TEXT( "/Packages/manifest.json" ), false );
			CopyToOutput( TEXT( "URP/packages-lock.json" ), TEXT( "/Packages/packages-lock.json" ), false );
			CopyToOutput( TEXT( "URP/Global Volume Profile.asset" ), TEXT( "/Assets/Settings/Global Volume Profile.asset" ), false );
			CopyToOutput( TEXT( "URP/Global Volume Profile.asset.meta" ), TEXT( "/Assets/Settings/Global Volume Profile.asset.meta" ), false );
			//CopyToOutput( TEXT("URP/URPCommonPass.hlsl", TEXT("/Assets/Shaders/URPCommonPass.hlsl" );
		}
		else if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
		{
			VerifyOrCreateDirectory( HDRPDefaultResourcesFolder );

			CopyToOutput( TEXT( "HDRP/DefaultHDRPAsset.asset" ), TEXT( "/Assets/HDRPDefaultResources/DefaultHDRPAsset.asset" ), false );
			CopyToOutput( TEXT( "HDRP/DefaultHDRPAsset.asset.meta" ), TEXT( "/Assets/HDRPDefaultResources/DefaultHDRPAsset.asset.meta" ), false );
			CopyToOutput( TEXT( "HDRP/DefaultSettingsVolumeProfile.asset" ), TEXT( "/Assets/HDRPDefaultResources/DefaultSettingsVolumeProfile.asset" ), true );
			CopyToOutput( TEXT( "HDRP/DefaultSettingsVolumeProfile.asset.meta" ), TEXT( "/Assets/HDRPDefaultResources/DefaultSettingsVolumeProfile.asset.meta" ), true );
			CopyToOutput( TEXT( "HDRP/HDRenderPipelineGlobalSettings.asset" ), TEXT( "/Assets/HDRPDefaultResources/HDRenderPipelineGlobalSettings.asset" ), true );
			CopyToOutput( TEXT( "HDRP/HDRenderPipelineGlobalSettings.asset.meta" ), TEXT( "/Assets/HDRPDefaultResources/HDRenderPipelineGlobalSettings.asset.meta" ), true );
			CopyToOutput( TEXT( "HDRP/manifest.json" ), TEXT( "/Packages/manifest.json" ), false );
			CopyToOutput( TEXT( "HDRP/packages-lock.json" ), TEXT( "/Packages/packages-lock.json" ), false );
			//CopyToOutput( TEXT("URP/URPCommonPass.hlsl", TEXT("/Assets/Shaders/URPCommonPass.hlsl" );
		}
	}
#ifdef ENABLE_GODOT_EXPORT
	if( UTUSettings->Engine == EngineType::GODOT )
	{
		CopyGodotGlobalFiles();
	}
#endif

	FString SceneFile = GetAssetsFolder();
	SceneFile += *World->GetName();
	SceneFile += GetSceneExtension();

	std::vector< GameObject* > PreviousPrefabs;
	std::vector< UnityMaterial* > PreviousMaterials;
	if( GUnityScene )
	{
		PreviousPrefabs = GUnityScene->Prefabs;
		PreviousMaterials = GUnityScene->Materials;
	}
	GUnityScene = AllocateScene();

	GUnityScene->UsePrefabs = UTUSettings->UsePrefabs;
	if( GUnityScene->UsePrefabs && ReusePrefabs )
	{
		GUnityScene->Prefabs = PreviousPrefabs;
		GUnityScene->Materials = PreviousMaterials;
	}
	
	AllComponentsInScene.Reset( 0 );
	for( TActorIterator<AActor> ActorItr( CurrentWorld ); ActorItr; ++ActorItr )
	{
		AActor* A = *ActorItr;
		//Ignore specific actors
		if( !ShouldExportActor( A ) )
			continue;
		
		TArray<UActorComponent*> comps;
		A->GetComponents( comps );

		for( int i = 0; i < comps.Num(); i++ )
			AllComponentsInScene.Add( comps[ i ] );
	}

	int32 AllActors = CurrentWorld->GetProgressDenominator();

	{
		FScopedSlowTask ActorProgress( AllActors );
		ActorProgress.MakeDialog();

		int ProcessedActors = 0;
		for( TActorIterator<AActor> ActorItr( CurrentWorld ); ActorItr; ++ActorItr )
		{
			auto Current = ActorItr.GetProgressNumerator();
			FString Text = FString::Printf( TEXT( "ProcessingActors %d/%d" ), ProcessedActors, AllActors );
			FText StrTxt = FText::FromString( Text );
			ActorProgress.EnterProgressFrame( 1.0f, StrTxt );

			//Ignore specific actors
			if( !ShouldExportActor( *ActorItr ) )
				continue;

			ProcessActor( *ActorItr, GUnityScene );
			ProcessedActors++;
		}

	}

	TArray<UTexture*> AllUsedTextures;
	int MaterialGUIDCollisions = 0;
	int MaterialShaderGUIDCollisions = 0;
	for( int i = 0; i < AllMaterials.size(); i++ )
	{
		auto Material = AllMaterials[ i ];
		CountTextures( Material, AllUsedTextures );
	}

	{
		int TotalTextureCount = AllUsedTextures.Num();
		FScopedSlowTask TexturesProgress( TotalTextureCount );
		if (!DoAsyncTextureExport )
			TexturesProgress.MakeDialog();

		int PrevCount = 0;
		for( int i = 0; i < AllMaterials.size(); i++ )
		{			
			auto Material = AllMaterials[ i ];
			ExportMaterialTextures( Material, AllUsedTextures, TotalTextureCount );
			int CurrentCount = TotalTextureCount - AllUsedTextures.Num();
			GetMaterialShaderSource( Material, true );
			if( Material->MaterialInterface )
			{
				Material->BaseMaterial = Material->MaterialInterface->GetMaterial();
				Material->MaterialInstance = Cast<UMaterialInstance>( Material->MaterialInterface );
			}
			if( CurrentCount > PrevCount )
			{
				int Dif = CurrentCount - PrevCount;
				PrevCount = CurrentCount;
				if (!DoAsyncTextureExport )
					TexturesProgress.EnterProgressFrame( Dif, LOCTEXT( "ExportingTextures", "Exporting Textures" ) );
			}
		}
	}

	bool Sync = false;// true;
	RTTI->QueCommand( Sync );

	while( ProcessingState < 1 )
	{
		FPlatformProcess::Sleep( 0.01f );
	}
	
	for( int i = 0; i < AllTextures.size(); i++ )
	{
		auto Binding = AllTextures[ i ];

		if( DoAsyncTextureExport )
		{
			Binding->TaskHandle = TGraphTask<FExportTextureTask>::CreateTask( NULL, ENamedThreads::GameThread ).ConstructAndDispatchWhenReady( Binding->UnrealTexture );
		}
		
		if( !Binding->UnityTex )
		{
			//UE_LOG( LogEngine, Error, TEXT( "Texture %d has no UnityTex !!" ), i );
			continue;
		}

		std::string TexMetaFile = Binding->UnityTex->File;
		TexMetaFile += ToANSIString( *GetMetaExtension() );

		int sRGB = Binding->UnrealTexture->SRGB;
		UnityTextureShape Shape = UTS_2D;
		int TileX = 0, TileY = 0;
		if( Cast<UTextureCube>( Binding->UnrealTexture ) )
			Shape = UTS_Cube;
		#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION > 20) || ENGINE_MAJOR_VERSION == 5
		UTexture2DArray* Tex2DArray = Cast< UTexture2DArray>( Binding->UnrealTexture );
		if( Tex2DArray )
		{
			TileX = 1;
			TileY = Tex2DArray->SourceTextures.Num();
			Shape = UTS_2DArray;
		}
		#endif
		UVolumeTexture* VolTex = Cast<UVolumeTexture>( Binding->UnrealTexture );
		if( VolTex )
		{
			Shape = UTS_3D;
			
			UTexture2D* SourceTex = nullptr;
			#if ENGINE_MAJOR_VERSION == 4
				SourceTex = VolTex->Source2DTexture;
			#else
				SourceTex = VolTex->Source2DTexture.Get();
			#endif
			if( SourceTex )
			{
				TileX = SourceTex->Source.GetSizeX() / VolTex->Source2DTileSizeX;
				TileY = SourceTex->Source.GetSizeY() / VolTex->Source2DTileSizeY;
			}
		}
		
		int TextureCompression = 0;
		if( Binding->UnrealTexture->CompressionSettings == TC_Default ||
			Binding->UnrealTexture->CompressionSettings == TC_Normalmap ||
			Binding->UnrealTexture->CompressionSettings == TC_HDR_Compressed ||
			Binding->UnrealTexture->CompressionSettings == TC_BC7 )
			TextureCompression = 1;
		
		std::string TexMetaContents = GenerateTextureMeta( Binding->UnityTex, Binding->IsNormalMap, sRGB, Shape, TileX, TileY, TextureCompression );
		if ( ExportTextures )
			::SaveFile( TexMetaFile.c_str(), (uint32*)TexMetaContents.c_str(), TexMetaContents.length() );
	}
	//Wait for all textures to get exported
	if( DoAsyncTextureExport )
	{
		FScopedSlowTask TexturesProgress( AllTextures.size() );
		TexturesProgress.MakeDialog();
		for( int i = 0; i < AllTextures.size(); i++ )
		{
			auto Binding = AllTextures[ i ];
			FString TextureFileName = GenerateTexturePath( Binding->UnrealTexture );
			FString Text = FString::Printf( TEXT( "Exporting Textures Asynchronously (Waiting for %s ) %d/%d" ), *TextureFileName, i, AllTextures.size() );
			FText StrTxt = FText::FromString( Text );
			TexturesProgress.EnterProgressFrame( 1, StrTxt );
			FTaskGraphInterface::Get().WaitUntilTaskCompletes( Binding->TaskHandle, ENamedThreads::GameThread_Local );
		}
	}
	
	for( int i = 0; i < AllMaterials.size(); i++ )
	{
		MaterialBinding* Mat = AllMaterials[ i ];

		FString MatFile;

		if( CVarUseOriginalPaths.GetValueOnAnyThread() == 1 )
		{
			MatFile += GetAssetPathFolder( Mat->MaterialInterface );
		}
		else
		{
			MatFile += TEXT("/Materials/" );
		}
		
		FString NameWide = ToWideString( Mat->UnityMat->Name ).c_str();
		MatFile += NameWide;
		MatFile += GetMaterialExtension();
		Mat->UnityMat->ResourcePath = TCHAR_TO_ANSI( *MatFile );
		MatFile = GetAssetsFolder() + MatFile;
		CreateAllDirectories( MatFile );
		Mat->UnityMat->File = TCHAR_TO_ANSI( *MatFile );

		std::string MatFileContents = Mat->UnityMat->GenerateMaterialFile();
		std::string MatFileStr = TCHAR_TO_ANSI( *MatFile );
		FixUnicodeCharacters( MatFileStr );
		::SaveFile( MatFileStr.c_str(), (uint32*)MatFileContents.c_str(), MatFileContents.length() );

		if( UTUSettings->Engine == EngineType::UNITY )
		{
			FString MatMetaFile = MatFile;
			MatMetaFile += GetMetaExtension();
			Mat->UnityMat->GenerateGUID();
			std::string MaterialMetaContents = GenerateMaterialMeta( Mat->UnityMat->GUID );
			std::string MatMetaFileStr = TCHAR_TO_ANSI( *MatMetaFile );
			FixUnicodeCharacters( MatMetaFileStr );
			::SaveFile( MatMetaFileStr.c_str(), (uint32*)MaterialMetaContents.c_str(), MaterialMetaContents.length() );
		}
	}
	
	{
		FScopedSlowTask MeshesProgress( MeshList.size() );
		MeshesProgress.MakeDialog();

		TArray<UAnimSequence*> AnimationSequences;
		auto GetAllAnimSequencesLambda = [&]( FAssetData& Asset )
		{
			bool Modified = false;
			UAnimSequence* Anim = Cast<UAnimSequence>( Asset.GetAsset() );
			if( Anim )
			{
				AnimationSequences.Add( Anim );
			}

			return Modified;
		};
		if( UTUSettings->ExportAllAnimations )
		{
			IterateOverAllAssetsOfType( FName( "AnimSequence" ), GetAllAnimSequencesLambda, false );
		}
		for( int i = 0; i < MeshList.size(); i++ )
		{
			MeshBinding* MB = MeshList[ i ];
			UnityMesh* M = MB->TheUnityMesh;

			FString MeshFile = M->File.c_str();

			UE_LOG( LogTemp, Log, TEXT( "Writing Mesh %s (%d/%d)" ), *MeshFile, i + 1, MeshList.size() );

			FString Filename = MeshFile;
			CreateAllDirectories( Filename );
			#ifdef ENABLE_GODOT_EXPORT
			if( UTUSettings->Engine == EngineType::GODOT )
			{
				bool ShowOptions = ( i == 0 );
				bool Status = DoMeshExportForGodot( MB, ShowOptions );
				//User may have cancelled
				if( !Status )
					break;
			}
			else
			#endif
				ExportFBXForActor( MB->OwnerActor, Filename );
			
			if( UTUSettings->ExportAllAnimations && MB->UnrealSkeletalMesh )
			{
				for( int a = 0; a < AnimationSequences.Num(); a++ )
				{
					UAnimSequence* Anim = AnimationSequences[ a ];
					
					if( GetSkeleton( MB->UnrealSkeletalMesh ) == Anim->GetSkeleton() )
					{
						AnimationEntry NewAnimationEntry;

						NewAnimationEntry.SkeletalMesh = MB->UnrealSkeletalMesh;
						NewAnimationEntry.AnimSeq = Anim;
						NewAnimationEntry.MeshName = *MB->UnrealSkeletalMesh->GetName();
							
						AnimationsToExport.Add( NewAnimationEntry );
					}					
				}
			}

			if( MB->UnrealSkeletalMesh && AnimationsToExport.Num() > 0 )
			{
				for( int a = 0; a < AnimationsToExport.Num(); a++ )
				{
					FString Str = FString::Printf( TEXT( "Exporting %d Animations for %s" ), AnimationsToExport.Num(), *MB->UnrealSkeletalMesh->GetName());
					FText StrTxt = FText::FromString( Str );
					MeshesProgress.EnterProgressFrame( 1.0f / (float)AnimationsToExport.Num(), StrTxt );

					auto AnimationData = AnimationsToExport[ a ];

					FString AnimFBXName = GenerateAnimationFilePath( AnimationData.AnimSeq );
					//Skip existing files, Animation export can take a while, people might end task this
					if( FPlatformFileManager::Get().GetPlatformFile().FileExists( *AnimFBXName ) )
						continue;

					UnFbx::FFbxExporter* AnimExporter = nullptr;
					FbxScene* AnimFBXScene = nullptr;
					PrepareFBXExporter( AnimFBXName, &AnimExporter, &AnimFBXScene );
					std::string AnimNameStr = ToANSIString( *AnimationData.AnimSeq->GetName() );
					if( AnimStack )
						AnimStack->SetName( AnimNameStr.c_str() );
					auto AnimNode = ExportAnimSequence( AnimExporter, AnimationData.AnimSeq, AnimationData.SkeletalMesh,
														GetExportOptions( AnimExporter )->bExportPreviewMesh, AnimationData.MeshName,
														AnimFBXScene->GetRootNode(), &AnimationData.OverrideMaterials, AnimFBXScene );
					AnimFBXScene->GetRootNode()->AddChild( AnimNode );

					WriteToFile( AnimExporter, AnimFBXName, AnimFBXScene );

					//Write Animation FBX Meta

					FString AnimationAssetPath = GetAssetPathFolder( AnimationData.AnimSeq );
					AnimationAssetPath += *AnimationData.AnimSeq->GetName();
					std::string AnimationAssetPathStr = ToANSIString( *AnimationAssetPath );
					std::size_t hash = std::hash<std::string>{}( AnimationAssetPathStr );
					std::string GUID = GetGUIDFromSizeT( hash );
					std::string MetaData = GenerateAnimationFBXMeta( GUID );
					int MetaDataLen = MetaData.length();
					FString AnimationFBXMetaPath = AnimFBXName + GetMetaExtension();
					std::string AnimationFBXMetaPathStr = ToANSIString( *AnimationFBXMetaPath );

					::SaveFile( AnimationFBXMetaPathStr.c_str(), (uint32*)MetaData.c_str(), MetaDataLen );
				}
			}
			else
			{
				FString Text = FString::Printf( TEXT( "Exporting Meshes %d/%d" ), i + 1, MeshList.size() );
				FText StrTxt = FText::FromString( Text );
				MeshesProgress.EnterProgressFrame( 1.0f, StrTxt );
			}
			AnimationsToExport.Reset( 0 );

			FString MeshMetaFile = MeshFile;
			MeshMetaFile += GetMetaExtension();

			std::string MetaData = GenerateMeshMeta( M, ( CVarFBXPerActor.GetValueOnAnyThread() == 1 ), MB->TotalLods );
			int MetaDataLen = MetaData.length();
			std::string MeshMetaFileStr = ToANSIString( *MeshMetaFile );
			::SaveFile( MeshMetaFileStr.c_str(), (uint32*)MetaData.c_str(), MetaDataLen );
		}
	}

	FString ProxySceneFile = GetResourceDir();
	ProxySceneFile += TEXT( "Proxy.unity" );

	if( GUnityScene->UsePrefabs )
	{
		FString PrefabFolder = GetAssetsFolder();
		PrefabFolder += TEXT("Prefabs/" );
		VerifyOrCreateDirectory( PrefabFolder );
		GUnityScene->FixDuplicatePrefabNames();
		std::string PrefabFolderStr = ToANSIString( *PrefabFolder );
		GUnityScene->WritePrefabs( PrefabFolderStr.c_str() );
	}

	if( GameObjectForTrees )
	{
		GUnityScene->Add( GameObjectForTrees );
	}
	GUnityScene->WriteScene( ToANSIString(* SceneFile).c_str(), ToANSIString(*ProxySceneFile).c_str() );
	
	//Reset these to give a chance of changing them on subsequent exports
	GlobalFBXExportOptions = nullptr;

	if ( UTUSettings->ExportAllSounds )
		ExportSounds();

	if( UTUSettings->Engine == EngineType::UNITY )
	{
		FString FinishText = FString::Printf( TEXT(
			"Export Complete !\n\n"
			"For URP/HDRP you need Unity 2021.2 minimum\n"
			"Don't mix Builtin/URP/HDRP exports into the same folder\n"
			"Don't save the current scene because the export process modifies some assets in memory\n" ) );
		FText Txt = FText::FromString( FinishText );
		FMessageDialog::Open( EAppMsgType::Ok, Txt );
	}
	else
	{
		FString FinishText = FString::Printf( TEXT(
			"Export Complete !\n\n"
			"Exported project must be opened in Godot 4.2+\n") );
		FText Txt = FText::FromString( FinishText );
		FMessageDialog::Open( EAppMsgType::Ok, Txt );
	}
	#endif
}
