﻿
#include "UnityScene.h"
#include "ExportToUnity.h"
#ifdef ENABLE_GODOT_EXPORT
	#include "GodotScene.h"
#endif
#include "Module.h"

#include "Runtime/Engine/Classes/Components/LightComponent.h"
#include "Runtime/Engine/Classes/Components/PointLightComponent.h"
#include "Runtime/Engine/Classes/Components/SpotLightComponent.h"
#include "Runtime/Engine/Classes/Components/RectLightComponent.h"
#include "Runtime/Engine/Classes/Components/DirectionalLightComponent.h"

#if PLATFORM_WINDOWS
#else
//#define snprintf sprintf
#endif
#if WITH_EDITOR

extern TAutoConsoleVariable<int> CVarRenderPipeline;

std::string NullGUID = "0000000000000000f000000000000000";

UnityComponent::UnityComponent()
{
	ID = GetUniqueID();
}
std::string UnityComponent::GetSceneData()
{
	return "";
}
uint64 UnityComponent::GetUniqueID()
{
	uint64 ID = 1030971880 + ( Counter++);
	return ID;
}

uint64 UnityComponent::Counter = 0;

TransformComponent::TransformComponent()
{
	Type = CT_TRANSFORM;

	Reset();
}
void TransformComponent::Reset()
{
	memset( LocalPosition, 0, sizeof( LocalPosition ) );
	memset( LocalRotation, 0, sizeof( LocalRotation ) );
	memset( LocalScale, 0, sizeof( LocalScale ) );

	LocalRotation[ 3 ] = 1.0f;
	for( int i = 0; i < 3; i++ )
		LocalScale[ i ] = 1.0f;
}
void TransformComponent::Set( FVector Position, FQuat Quat, FVector Scale )
{
	LocalPosition[ 0 ] = Position.X;
	LocalPosition[ 1 ] = Position.Y;
	LocalPosition[ 2 ] = Position.Z;
	LocalRotation[ 0 ] = Quat.X;
	LocalRotation[ 1 ] = Quat.Y;
	LocalRotation[ 2 ] = Quat.Z;
	LocalRotation[ 3 ] = Quat.W;
	LocalScale[ 0 ] = Scale.X;
	LocalScale[ 1 ] = Scale.Y;
	LocalScale[ 2 ] = Scale.Z;
}
void TransformComponent::Copy( TransformComponent& Other )
{
	for( int i = 0; i < 4; i++ )
	{
		LocalRotation[ i ] = Other.LocalRotation[ i ];
		if( i < 3 )
		{
			LocalPosition[ i ] = Other.LocalPosition[ i ];
			LocalScale[ i ] = Other.LocalScale[ i ];
		}
	}
}
std::string TransformComponent::GetChildrenText()
{	
	if( Owner->Children.size() == 0 )
		return " []\n";
	else
	{
		std::string Ret = "\n";
		for( int i = 0; i < Owner->Children.size(); i++ )
		{
			auto Child = Owner->Children[ i ];
			TransformComponent* TC = ( TransformComponent*)Child->GetComponent( ComponentType::CT_TRANSFORM );
			char Line[ 256 ];
			//uint64_t ID = 0;
			snprintf( Line, sizeof( Line ), "  - {fileID: %lld}\n", TC->ID );
			Ret += Line;
		}

		return Ret;
	}
}
std::string TransformComponent::GetSceneData()
{
	uint64 ParentID = 0;
	if( Owner->Parent )
	{
		TransformComponent * TC = ( TransformComponent*) Owner->Parent->GetComponent( CT_TRANSFORM );
		
		ParentID = TC->ID;
	}
	std::string ChildrenText = GetChildrenText();
	int Size = 1024 + ChildrenText.length();
	char* Text = new char[ Size ];
	snprintf( Text, Size,
			   "--- !u!4 &%lld\n"
			   "Transform:\n"
			   "  m_ObjectHideFlags: 0\n"
			   "  m_CorrespondingSourceObject: {fileID: 0}\n"
			   "  m_PrefabInstance: {fileID: 0}\n"
			   "  m_PrefabAsset: {fileID: 0}\n"
			   "  m_GameObject: {fileID: %lld}\n"
			   "  m_LocalRotation: {x: %f, y: %f, z: %f, w: %f}\n"
			   "  m_LocalPosition: {x: %f, y: %f, z: %f}\n"
			   "  m_LocalScale: {x: %f, y: %f, z: %f}\n"
			   "  m_ConstrainProportionsScale: 0\n"
			   "  m_Children:%s"
			   "  m_Father: {fileID: %lld}\n"
			   "  m_RootOrder: 0\n"
			   "  m_LocalEulerAnglesHint: {x: 0, y: 0, z: 0}\n"
			   ,
			   this->ID,
			   Owner->ID,//Gameobject
			   LocalRotation[ 0 ], LocalRotation[ 1 ], LocalRotation[ 2 ], LocalRotation[ 3 ],//Rotation
			   LocalPosition[ 0 ], LocalPosition[ 1 ], LocalPosition[ 2 ],//Position
			   LocalScale[ 0 ], LocalScale[ 1 ], LocalScale[ 2 ],//Scale
			   ChildrenText.c_str(),
			   ParentID//father
			   );
	
	std::string RetStr = Text;

	return RetStr;
}


std::string MeshRenderer::GetSceneData()
{
	std::string MaterialText;
	char Line[ 512 ];

	if( Materials.size() > 0 )
	{
		//MeshFilter* MF = (MeshFilter*)Owner->GetComponent( ComponentType::CT_MESHFILTER );
		
		for( int i = 0; i < Materials.size(); i++ )
		{
			int fileIDBase = 2100000;
			UnityMaterial* Mat = Materials[ i ];
			//Don't reindex materials since I already did that based on LOD level
			std::string MatGUID = "0000000000000000f000000000000000";
			if( Mat )
				MatGUID = Mat->GUID;
			snprintf( Line, sizeof(Line), "  - {fileID: %d, guid: %s, type: 2}\n", fileIDBase, MatGUID.c_str() );
			MaterialText += Line;
		}
	}
	else
	{
		snprintf( Line, sizeof(Line), "  - {fileID: 10303, guid: 0000000000000000f000000000000000, type: 0}\n" );
		MaterialText += Line;
	}

	int TextLen = 2048 + MaterialText.length();
	char* Text = new char[ TextLen ];

	snprintf( Text, TextLen,
	"--- !u!23 &%lld\n"
	"MeshRenderer:\n"
	"  m_ObjectHideFlags: 0\n"
	"  m_CorrespondingSourceObject: {fileID: 0}\n"
	"  m_PrefabInstance: {fileID: 0}\n"
	"  m_PrefabAsset: {fileID: 0}\n"
	"  m_GameObject: {fileID: %lld}\n"
	"  m_Enabled: 1\n"
	"  m_CastShadows: %d\n"
	"  m_ReceiveShadows: 1\n"
	"  m_DynamicOccludee: 1\n"
	"  m_MotionVectors: 1\n"
	"  m_LightProbeUsage: 1\n"
	"  m_ReflectionProbeUsage: 1\n"
	"  m_RayTracingMode: 2\n"
	"  m_RayTraceProcedural: 0\n"
	"  m_RenderingLayerMask: 1\n"
	"  m_RendererPriority: 0\n"
	"  m_Materials:\n"
	"%s"
	"  m_StaticBatchInfo:\n"
	"    firstSubMesh: 0\n"
	"    subMeshCount: 0\n"
	"  m_StaticBatchRoot: {fileID: 0}\n"
	"  m_ProbeAnchor: {fileID: 0}\n"
	"  m_LightProbeVolumeOverride: {fileID: 0}\n"
	"  m_ScaleInLightmap: 1\n"
	"  m_ReceiveGI: 1\n"
	"  m_PreserveUVs: 1\n"
	"  m_IgnoreNormalsForChartDetection: 0\n"
	"  m_ImportantGI: 0\n"
	"  m_StitchLightmapSeams: 1\n"
	"  m_SelectedEditorRenderState: 3\n"
	"  m_MinimumChartSize: 4\n"
	"  m_AutoUVMaxDistance: 0.5\n"
	"  m_AutoUVMaxAngle: 89\n"
	"  m_LightmapParameters: {fileID: 0}\n"
	"  m_SortingLayerID: 0\n"
	"  m_SortingLayer: 0\n"
	"  m_SortingOrder: 0\n"
	"  m_AdditionalVertexStreams: {fileID: 0}\n"
	, ID, Owner->ID, CastShadows, MaterialText.c_str() );

	std::string RetStr = Text;

	delete[] Text;

	return RetStr;
}
std::string SkinnedMeshRenderer::GenerateBoneDesc()
{
	std::string Ret = "";

	if( BoneGUIDs.size() > 0 )
	{
		Ret += "\n";
		for( int i = 0; i < BoneGUIDs.size(); i++ )
		{
			char Text[ 128 ] = "";
			snprintf( Text, sizeof( Text ), "  - {fileID: %lld}\n", BoneGUIDs[ i ] );
			Ret += Text;
		}
	}
	else
	{
		Ret += "[]\n";
	}

	return Ret;
}
void SkinnedMeshRenderer::FindBoneGameObjects()
{
				//Means we already found the IDs
	if( !Mesh || BoneGUIDs.size() > 0)
		return;
	
	for( int i = 0; i < Mesh->BoneNames.size(); i++ )
	{
		GameObject* GO = Owner->Parent->Find( Mesh->BoneNames[i].c_str());
		if( GO )
		{
			TransformComponent* TC = ( TransformComponent*)GO->GetComponent( CT_TRANSFORM );
			BoneGUIDs.push_back( TC->ID );
		}
		else
			BoneGUIDs.push_back( 0 );
	}
}
uint64 SkinnedMeshRenderer::GetRootTransformID()
{
	if( Mesh->BoneNames.size() == 0 )
		return 0;

	GameObject* GO = Owner->Parent->Find( Mesh->BoneNames[ 0 ].c_str() );
	if( GO )
	{
		TransformComponent* TC = (TransformComponent*)GO->GetComponent( CT_TRANSFORM );
		return TC->ID;
	}

	return 0;
}
std::string SkinnedMeshRenderer::GetSceneData()
{
	std::string MaterialText;
	char Line[ 512 ];

	if( Materials.size() > 0 )
	{
		MeshFilter* MF = (MeshFilter*)Owner->GetComponent( ComponentType::CT_MESHFILTER );

		for( int i = 0; i < Materials.size(); i++ )
		{
			int fileIDBase = 2100000;
			UnityMaterial* Mat = Materials[ i ];
			//Don't reindex materials since I already did that based on LOD level
			std::string MatGUID = "0000000000000000f000000000000000";
			if( Mat )
				MatGUID = Mat->GUID;
			snprintf( Line, sizeof(Line), "  - {fileID: %d, guid: %s, type: 2}\n", fileIDBase, MatGUID.c_str());
			MaterialText += Line;
		}
	}
	else
	{
		snprintf( Line, sizeof( Line ), "  - {fileID: 10303, guid: 0000000000000000f000000000000000, type: 0}\n" );
		MaterialText += Line;
	}

	FindBoneGameObjects();

	int MeshFileID = 4300000 + LOD * 2;
	if ( TotalLods > 1 )
		MeshFileID = 4300000 + LOD * 2;
	std::string AllBonesStr = GenerateBoneDesc();
	uint64 RootTransformID = GetRootTransformID();
	int TextLen = 2048 + MaterialText.length() + AllBonesStr.length();
	char* Text = new char[ TextLen ];
	snprintf( Text, TextLen,
			   "--- !u!137 &%lld\n"
			   "SkinnedMeshRenderer:\n"
			   "  m_ObjectHideFlags: 0\n"
			   "  m_CorrespondingSourceObject: {fileID: 0}\n"
			   "  m_PrefabInstance: {fileID: 0}\n"
			   "  m_PrefabAsset: {fileID: 0}\n"
			   "  m_GameObject: {fileID: %lld}\n"
			   "  m_Enabled: 1\n"
			   "  m_CastShadows: %d\n"
			   "  m_ReceiveShadows: 1\n"
			   "  m_DynamicOccludee: 1\n"
			   "  m_StaticShadowCaster: 0\n"
			   "  m_MotionVectors: 1\n"
			   "  m_LightProbeUsage: 1\n"
			   "  m_ReflectionProbeUsage: 1\n"
			   "  m_RayTracingMode: 3\n"
			   "  m_RayTraceProcedural: 0\n"
			   "  m_RenderingLayerMask: 1\n"
			   "  m_RendererPriority: 0\n"
			   "  m_Materials:\n"
			   "%s"
			   "  m_StaticBatchInfo:\n"
			   "    firstSubMesh: 0\n"
			   "    subMeshCount: 0\n"
			   "  m_StaticBatchRoot: {fileID: 0}\n"
			   "  m_ProbeAnchor: {fileID: 0}\n"
			   "  m_LightProbeVolumeOverride: {fileID: 0}\n"
			   "  m_ScaleInLightmap: 1\n"
			   "  m_ReceiveGI: 1\n"
			   "  m_PreserveUVs: 1\n"
			   "  m_IgnoreNormalsForChartDetection: 0\n"
			   "  m_ImportantGI: 0\n"
			   "  m_StitchLightmapSeams: 1\n"
			   "  m_SelectedEditorRenderState: 3\n"
			   "  m_MinimumChartSize: 4\n"
			   "  m_AutoUVMaxDistance: 0.5\n"
			   "  m_AutoUVMaxAngle: 89\n"
			   "  m_LightmapParameters: {fileID: 0}\n"
			   "  m_SortingLayerID: 0\n"
			   "  m_SortingLayer: 0\n"
			   "  m_SortingOrder: 0\n"
			   "  serializedVersion: 2\n"
			   "  m_Quality: 0\n"
			   "  m_UpdateWhenOffscreen: 0\n"
			   "  m_SkinnedMotionVectors: 1\n"
			   "  m_Mesh: {fileID: %d, guid: %s, type: 3}\n"
			   "  m_Bones: %s"
			   "  m_BlendShapeWeights: []\n"
			   "  m_RootBone: {fileID: %lld}\n"
			   "  m_AABB:\n"
			   "    m_Center: {x: %f, y: %f, z: %f}\n"
			   "    m_Extent: {x: %f, y: %f, z: %f}\n"
			   "  m_DirtyAABB: 0\n"
			   , ID, Owner->ID, CastShadows, MaterialText.c_str(), MeshFileID, Mesh->GUID.c_str(), AllBonesStr.c_str(), RootTransformID,
			  Center.X, Center.Y, Center.Z,
			  Extent.X, Extent.Y, Extent.Z );

	std::string RetStr = Text;

	delete[] Text;

	return RetStr;
}
std::string AnimationComponent::GetSceneData()
{
	char Text[ 1024];
	uint64 AnimationFileID = 0;
	std::string AnimationGUID = NullGUID;
	snprintf( Text, sizeof( Text ),
			  "--- !u!111 &%lld\n"
			  "Animation:\n"
			  "m_ObjectHideFlags: 0\n"
			  "m_CorrespondingSourceObject: {fileID: 0}\n"
			  "m_PrefabInstance: {fileID: 0}\n"
			  "m_PrefabAsset: {fileID: 0}\n"
			  "m_GameObject: {fileID: %lld}\n"
			  "m_Enabled: 1\n"
			  "serializedVersion: 3\n"
			  "m_Animation: {fileID: %lld, guid: %s, type: 3}\n"
			  "m_Animations:\n"
			  "- {fileID: %lld, guid: %s, type: 3}\n"
			  "m_WrapMode: 0\n"
			  "m_PlayAutomatically: 1\n"
			  "m_AnimatePhysics: 0\n"
			  "m_CullingType: 0\n",
				ID, Owner->ID, AnimationFileID, AnimationGUID.c_str(), AnimationFileID, AnimationGUID.c_str() );

	std::string Ret = Text;
	return Ret;
}
void Renderer::AddMaterial( UnityMaterial* NewMat, bool HasDuplicateMaterials )
{
	//Only needs this when base mesh has duplicate materials that will get merged by unity
	//if( HasDuplicateMaterials )
	//{
	//	for( int i = 0; i < Materials.size(); i++ )
	//	{
	//		if( Materials[ i ] == NewMat )
	//		{
	//			//If it's a duplicate, don't add it
	//			return;
	//		}
	//	}
	//}
	Materials.push_back( NewMat );
}
std::string MeshFilter::GetSceneData()
{
	//uint64_t SubMeshID = 4300000 + LOD * 2;

	char Text[ 1024 ];
	snprintf( Text, sizeof( Text ),
		"--- !u!33 &%lld\n"
		"MeshFilter:\n"
		"  m_ObjectHideFlags: 0\n"
		"  m_CorrespondingSourceObject: {fileID: 0}\n"
		"  m_PrefabInstance: {fileID: 0}\n"
		"  m_PrefabAsset: {fileID: 0}\n"
		"  m_GameObject: {fileID: %lld}\n"
		"  m_Mesh: {fileID: %lld, guid: %s, type: 3}\n"
		, this->ID, Owner->ID, SubMeshID, Mesh->GUID.c_str() );

	std::string RetStr = Text;

	return RetStr;
}
std::string LodGroup::GetLODsString()
{
	std::string RetStr;
	for( int i = 0; i < Lods.size(); i++ )
	{
		LOD* lod = Lods[ i ];

		std::string RenderersText;
		for( int l = 0; l < lod->renderers.size(); l++ )
		{
			char Local[ 1024 ];
			snprintf( Local, sizeof( Local ), "    - renderer: {fileID: %lld}\n", lod->renderers[l]->ID );
			RenderersText += Local;
		}

		char Text[ 1024 ];
		snprintf( Text, sizeof( Text ),
				   "  - screenRelativeHeight: %0.2f\n"
				   "    fadeTransitionWidth: %0.1f\n"
				   "    renderers:\n", lod->screenRelativeTransitionHeight, lod->fadeTransitionWidth );
		RetStr += Text;
		RetStr += RenderersText;
	}

	return RetStr;
}
std::string LodGroup::GetSceneData()
{
	std::string LodsString = LodGroup::GetLODsString();	

	int TextSize = 1024 + LodsString.length();
	char* Text = new char[ TextSize ];
	snprintf( Text, TextSize,
			   "--- !u!205 &%lld\n"
			   "LODGroup:\n"
			   "  m_ObjectHideFlags: 0\n"
			   "  m_CorrespondingSourceObject: {fileID: 0}\n"
			   "  m_PrefabInstance: {fileID: 0}\n"
			   "  m_PrefabAsset: {fileID: 0}\n"
			   "  m_GameObject: {fileID: %lld}\n"
			   "  serializedVersion: 2\n"
			   "  m_LocalReferencePoint: {x: %f, y: %f, z: %f}\n"
			   "  m_Size: %f\n"
			   "  m_FadeMode: 0\n"
			   "  m_AnimateCrossFading: 0\n"
			   "  m_LastLODIsBillboard: 0\n"
			   "  m_LODs:\n"
			   "%s"
			   "  m_Enabled: 1\n"
			   , this->ID, Owner->ID, LocalReferencePoint.X, LocalReferencePoint.Y, LocalReferencePoint.Z, Size, LodsString.c_str() );

	std::string RetStr = Text;

	delete[] Text;

	return RetStr;
}

std::string MeshCollider::GetSceneData()
{
	std::string MeshGUID = "";
	if( Mesh )
		MeshGUID = Mesh->GUID;
	char Text[ 2048 ];
	snprintf( Text, sizeof( Text ),
			   "--- !u!64 &%lld\n"
			   "MeshCollider:\n"
			   "  m_ObjectHideFlags: 0\n"
			   "  m_CorrespondingSourceObject: {fileID: 0}\n"
			   "  m_PrefabInstance: {fileID: 0}\n"
			   "  m_PrefabAsset: {fileID: 0}\n"
			   "  m_GameObject: {fileID: %lld}\n"
			   "  m_Material: {fileID: 0}\n"
			   "  m_IsTrigger: 0\n"
			   "    m_Enabled: 1\n"
			   "    serializedVersion: 3\n"
			   "    m_Convex: %d\n"
			   "    m_CookingOptions: 14\n"
			   "    m_Mesh : {fileID: %lld, guid : %s, type : 3}\n",
			   this->ID, Owner->ID, IsConvex ? 1 : 0, SubMeshID, MeshGUID.c_str() );

	return Text;
}
std::string BoxCollider::GetSceneData()
{
	char Text[ 2048 ];
	snprintf( Text, sizeof( Text ),
			   "--- !u!65 &%lld\n"
			   "BoxCollider:\n"
			   "  m_ObjectHideFlags: 0\n"
			   "  m_CorrespondingSourceObject: {fileID: 0}\n"
			   "  m_PrefabInstance: {fileID: 0}\n"
			   "  m_PrefabAsset: {fileID: 0}\n"
			   "  m_GameObject: {fileID: %lld}\n"
			   "  m_Material: {fileID: 0}\n"
			   "  m_IsTrigger: 0\n"
			   "  m_Enabled: 1\n"
			   "  serializedVersion: 2\n"
			   "  m_Size : {x: %f, y : %f, z : %f}\n"
			   "  m_Center : {x: %f, y : %f, z : %f}\n",
			   this->ID, Owner->ID, Size.X, Size.Y, Size.Z, Center.X, Center.Y, Center.Z );

	return Text;
}
std::string SphereCollider::GetSceneData()
{
	char Text[ 2048 ];
	snprintf( Text, sizeof( Text ),
			   "--- !u!135 &%lld\n"
			   "SphereCollider:\n"
			   "  m_ObjectHideFlags: 0\n"
			   "  m_CorrespondingSourceObject: {fileID: 0}\n"
			   "  m_PrefabInstance: {fileID: 0}\n"
			   "  m_PrefabAsset: {fileID: 0}\n"
			   "  m_GameObject: {fileID: %lld}\n"
			   "  m_Material: {fileID: 0}\n"
			   "  m_IsTrigger: 0\n"
			   "  m_Enabled: 1\n"
			   "  serializedVersion: 2\n"
			   "  m_Radius : %f\n"
			   "  m_Center : {x: %f, y : %f, z : %f}\n",
			   this->ID, Owner->ID, Radius, Center.X, Center.Y, Center.Z );

	return Text;
}
std::string CapsuleCollider::GetSceneData()
{
	char Text[ 2048 ];
	snprintf( Text, sizeof( Text ),
			   "--- !u!136 &%lld\n"
			   "CapsuleCollider:\n"
			   "  m_ObjectHideFlags: 0\n"
			   "  m_CorrespondingSourceObject: {fileID: 0}\n"
			   "  m_PrefabInstance: {fileID: 0}\n"
			   "  m_PrefabAsset: {fileID: 0}\n"
			   "  m_GameObject: {fileID: %lld}\n"
			   "  m_Material: {fileID: 0}\n"
			   "  m_IsTrigger: 0\n"
			   "  m_Enabled: 1\n"
			   "  m_Radius : %f\n"
			   "  m_Height : %f\n"
			   "  m_Direction : %d\n"
			   "  m_Center : {x: %f, y : %f, z : %f}\n",
			   this->ID, Owner->ID, Radius, Height, Direction, Center.X, Center.Y, Center.Z );

	return Text;
}
float ToFloat( uint8 v )
{
	float r = float(v) / 255.0f;
	return r;
}
std::string LightComponent::GetSceneData()
{
	char Text[ 2048 ];
	int EnabledInt = (Enabled == true  ? 1: 0);
	int ShadowsType = ( Shadows == true ? 2 : 0 );
	snprintf( Text, sizeof( Text ),
			   "--- !u!108 &%lld\n"
			   "Light:\n"
			   "  m_ObjectHideFlags: 0\n"
			   "  m_CorrespondingSourceObject: {fileID: 0}\n"
			   "  m_PrefabInstance: {fileID: 0}\n"
			   "  m_PrefabAsset: {fileID: 0}\n"
			   "  m_GameObject: {fileID: %lld}\n"
			   "  m_Enabled: %d\n"
			   "  serializedVersion: 8\n"
			   "  m_Type: %d\n"
			   "  m_Color: {r: %f, g: %f, b: %f, a: %f}\n"
			   "  m_Intensity: %f\n"
			   "  m_Range: %f\n"
			   "  m_SpotAngle: %f\n"
			   "  m_CookieSize: 10\n"
			   "  m_Shadows:\n"
			   "    m_Type: %d\n"
			   "    m_Resolution: -1\n"
			   "    m_CustomResolution: -1\n"
			   "    m_Strength: 1\n"
			   "    m_Bias: 0.05\n"
			   "    m_NormalBias: 0.4\n"
			   "    m_NearPlane: 0.2\n"
			   "  m_Cookie: {fileID: 0}\n"
			   "  m_DrawHalo: 0\n"
			   "  m_Flare: {fileID: 0}\n"
			   "  m_RenderMode: 0\n"
			   "  m_CullingMask:\n"
			   "    serializedVersion: 2\n"
			   "    m_Bits: 4294967295\n"
			   "  m_Lightmapping: 4\n"
			   "  m_LightShadowCasterMode: 0\n"
			   "  m_AreaSize: {x: %f, y: %f}\n"
			   "  m_BounceIntensity: 1\n"
			   "  m_ColorTemperature: 6570\n"
			   "  m_UseColorTemperature: 0\n"
			   "  m_ShadowRadius: 0\n"
			   "  m_ShadowAngle: 0\n",
			   this->ID, Owner->ID, EnabledInt, Type,
			   ToFloat(Color.R), ToFloat( Color.G), ToFloat( Color.B ), ToFloat( Color.A ),
			   Intensity, Range, SpotAngle, ShadowsType,
			   Width, Height );

	std::string RetStr = Text;

	return RetStr;
}
std::string ReflectionProbeComponent::GetSceneData()
{
	char Text[ 2048 ];
	snprintf( Text, sizeof( Text ),
			   "--- !u!215 &%lld\n"
			   "ReflectionProbe:\n"
			   "  m_ObjectHideFlags: 0\n"
			   "  m_CorrespondingSourceObject: {fileID: 0}\n"
			   "  m_PrefabInstance: {fileID: 0}\n"
			   "  m_PrefabAsset: {fileID: 0}\n"
			   "  m_GameObject: {fileID: %lld}\n"
			   "  m_Enabled: 1\n"
			   "  serializedVersion: 2\n"
			   "  m_Type: 0\n"
			   "  m_Mode: 1\n"
			   "  m_RefreshMode: 0\n"
			   "  m_TimeSlicingMode: 0\n"
			   "  m_Resolution: 512\n"
			   "  m_UpdateFrequency: 0\n"
			   "  m_BoxSize: {x: %f, y: %f, z: %f}\n"
			   "  m_BoxOffset: {x: 0, y: 0, z: 0}\n"
			   "  m_NearClip: 0.3\n"
			   "  m_FarClip: 1000\n"
			   "  m_ShadowDistance: 100\n"
			   "  m_ClearFlags: 1\n"
			   "  m_BackGroundColor: {r: 0.19215687, g: 0.3019608, b: 0.4745098, a: 0}\n"
			   "  m_CullingMask:\n"
			   "    serializedVersion: 2\n"
			   "    m_Bits: 4294967295\n"
			   "  m_IntensityMultiplier: %f\n"
			   "  m_BlendDistance: 1\n"
			   "  m_HDR: 1\n"
			   "  m_BoxProjection: 0\n"
			   "  m_RenderDynamicObjects: 0\n"
			   "  m_UseOcclusionCulling: 1\n"
			   "  m_Importance: 1\n"
			   "  m_CustomBakedTexture: {fileID: 0}\n",
			   this->ID, Owner->ID, Size.X, Size.Y, Size.Z, Intensity );

	return Text;
}
std::string DecalComponent::GetSceneData()
{
	std::string MatGUID = "0000000000000000f000000000000000";
	if( Material )
		MatGUID = Material->GUID;

	char Text[ 2048 ];
	const char* ScriptGUID = "0777d029ed3dffa4692f417d4aba19ca";//URP
	if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
	{
		ScriptGUID = "f19d9143a39eb3b46bc4563e9889cfbd";
	}

	snprintf( Text, sizeof( Text ),
			   "--- !u!114 &%lld\n"
			   "MonoBehaviour:\n"
			   "  m_ObjectHideFlags: 0\n"
			   "  m_CorrespondingSourceObject: {fileID: 0}\n"
			   "  m_PrefabInstance: {fileID: 0}\n"
			   "  m_PrefabAsset: {fileID: 0}\n"
			   "  m_GameObject: {fileID: %lld}\n"
			   "  m_Enabled: 1\n"
			   "  m_EditorHideFlags: 0\n"
			   "  m_Script: {fileID: 11500000, guid: %s, type: 3}\n"
			   "  m_Name: \n"
			   "  m_EditorClassIdentifier: \n"
			   "  m_Material: {fileID: 2100000, guid: %s, type: 2}\n"
			   "  m_DrawDistance: 1000\n"
			   "  m_FadeScale: 0.9\n"
			   "  m_StartAngleFade: 180\n"
			   "  m_EndAngleFade: 180\n"
			   "  m_UVScale: {x: 1, y: 1}\n"
			   "  m_UVBias: {x: 0, y: 0}\n"
			   "  m_ScaleMode: 1\n"
			   "  m_Offset: {x: 0, y: 0, z: 0.0}\n"
			   "  m_Size: {x: %f, y: %f, z: %f}\n"
			   "  m_FadeFactor: 1\n",
			   this->ID, Owner->ID, ScriptGUID, MatGUID.c_str(), Size.X, Size.Y, Size.Z );

	return Text;
}
std::string AdditionalCameraData::GetSceneData()
{
	//URP only for now
	const char* ScriptGUID = "a79441f348de89743a2939f4d699eac1";
	
	char Text[ 4096 ];
	if( UTUSettings->ScriptableRenderPipeline == RenderPipeline::RP_URP )
	{
		snprintf( Text, sizeof( Text ),
				  "--- !u!114 &%lld\n"
				  "MonoBehaviour:\n"
				  "  m_ObjectHideFlags: 0\n"
				  "  m_CorrespondingSourceObject: {fileID: 0}\n"
				  "  m_PrefabInstance: {fileID: 0}\n"
				  "  m_PrefabAsset: {fileID: 0}\n"
				  "  m_GameObject: {fileID: %lld}\n"
				  "  m_Enabled: 1\n"
				  "  m_EditorHideFlags: 0\n"
				  "  m_Script: {fileID: 11500000, guid: %s, type: 3}\n"
				  "  m_Name: \n"
				  "  m_EditorClassIdentifier: \n"
				  "  m_RenderShadows: 1\n"
				  "  m_RequiresDepthTextureOption: 2\n"
				  "  m_RequiresOpaqueTextureOption: 2\n"
				  "  m_CameraType: 0\n"
				  "  m_Cameras: []\n"
				  "  m_RendererIndex: -1\n"
				  "  m_VolumeLayerMask:\n"
				  "    serializedVersion: 2\n"
				  "    m_Bits: 1\n"
				  "  m_VolumeTrigger: {fileID: 0}\n"
				  "  m_VolumeFrameworkUpdateModeOption: 2\n"
				  "  m_RenderPostProcessing: 1\n"
				  "  m_Antialiasing: 0\n"
				  "  m_AntialiasingQuality: 2\n"
				  "  m_StopNaN: 0\n"
				  "  m_Dithering: 0\n"
				  "  m_ClearDepth: 1\n"
				  "  m_AllowXRRendering: 1\n"
				  "  m_RequiresDepthTexture: 0\n"
				  "  m_RequiresColorTexture: 0\n"
				  "  m_Version: 2\n"
				  ,
				  this->ID, Owner->ID, ScriptGUID );
	}

	return Text;
}
std::string AdditionalLightData::GetSceneData()
{
	if( !Light )
		return "";

	const char* ScriptGUID = "7a68c43fe1f2a47cfa234b5eeaa98012";
	char Text[ 4096 ];
	if( UTUSettings->ScriptableRenderPipeline == RenderPipeline::RP_HDRP )
	{
		snprintf( Text, sizeof( Text ),
			  "--- !u!114 &%lld\n"
			  "MonoBehaviour:\n"
			  "  m_ObjectHideFlags: 0\n"
			  "  m_CorrespondingSourceObject: {fileID: 0}\n"
			  "  m_PrefabInstance: {fileID: 0}\n"
			  "  m_PrefabAsset: {fileID: 0}\n"
			  "  m_GameObject: {fileID: %lld}\n"
			  "  m_Enabled: 1\n"
			  "  m_EditorHideFlags: 0\n"
			  "  m_Script: {fileID: 11500000, guid: %s, type: 3}\n"
			  "  m_Name: \n"
			  "  m_EditorClassIdentifier: \n"
			  "  m_Intensity: %f\n"
			  "  m_EnableSpotReflector: 1\n"
			  "  m_LuxAtDistance : 1\n"
			  "  m_InnerSpotPercent: 0\n"
			  "  m_SpotIESCutoffPercent: 100\n"
			  "  m_LightDimmer: 1\n"
			  "  m_VolumetricDimmer: 1\n"
			  "  m_LightUnit: %d\n"
			  "  m_FadeDistance: 10000\n"
			  "  m_VolumetricFadeDistance: 10000\n"
			  "  m_AffectDiffuse: 1\n"
			  "  m_AffectSpecular: 1\n"
			  "  m_NonLightmappedOnly: 0\n"
			  "  m_ShapeWidth: 0.5\n"
			  "  m_ShapeHeight: 0.5\n"
			  "  m_AspectRatio: 1\n"
			  "  m_ShapeRadius: 0.025\n"
			  "  m_SoftnessScale: 1\n"
			  "  m_UseCustomSpotLightShadowCone: 0\n"
			  "  m_CustomSpotLightShadowCone: 30\n"
			  "  m_MaxSmoothness: 0.99\n"
			  "  m_ApplyRangeAttenuation: 1\n"
			  "  m_DisplayAreaLightEmissiveMesh: 0\n"
			  "  m_AreaLightCookie: {fileID: 0}\n"
			  "  m_IESPoint: {fileID: 0}\n"
			  "  m_IESSpot: {fileID: 0}\n"
			  "  m_IncludeForRayTracing: 1\n"
			  "  m_AreaLightShadowCone: 120\n"
			  "  m_UseScreenSpaceShadows: 0\n"
			  "  m_InteractsWithSky: 1\n"
			  "  m_AngularDiameter: 0.5\n"
			  "  m_FlareSize: 2\n"
			  "  m_FlareTint: {r: 1, g: 1, b: 1, a: 1}\n"
			  "  m_FlareFalloff: 4\n"
			  "  m_SurfaceTexture: {fileID: 0}\n"
			  "  m_SurfaceTint: {r: 1, g: 1, b: 1, a: 1}\n"
			  "  m_Distance: 1.5e+11\n"
			  "  m_UseRayTracedShadows: 0\n"
			  "  m_NumRayTracingSamples: 4\n"
			  "  m_FilterTracedShadow: 1\n"
			  "  m_FilterSizeTraced: 16\n"
			  "  m_SunLightConeAngle: 0.5\n"
			  "  m_LightShadowRadius: 0.5\n"
			  "  m_SemiTransparentShadow: 0\n"
			  "  m_ColorShadow: 1\n"
			  "  m_DistanceBasedFiltering: 0\n"
			  "  m_EvsmExponent: 15\n"
			  "  m_EvsmLightLeakBias: 0\n"
			  "  m_EvsmVarianceBias: 0.00001\n"
			  "  m_EvsmBlurPasses: 0\n"
			  "  m_LightlayersMask: 1\n"
			  "  m_LinkShadowLayers: 1\n"
			  "  m_ShadowNearPlane: 0.1\n"
			  "  m_BlockerSampleCount: 24\n"
			  "  m_FilterSampleCount: 16\n"
			  "  m_MinFilterSize: 0.1\n"
			  "  m_KernelSize: 5\n"
			  "  m_LightAngle: 1\n"
			  "  m_MaxDepthBias: 0.001\n"
			  "  m_ShadowResolution:\n"
			  "     m_Override: 512\n"
			  "    m_UseOverride: 1\n"
			  "    m_Level: 0\n"
			  "  m_ShadowDimmer: 1\n"
			  "  m_VolumetricShadowDimmer: 1\n"
			  "  m_ShadowFadeDistance: 10000\n"
			  "  m_UseContactShadow:\n"
			  "    m_Override : 0\n"
			  "    m_UseOverride: 1\n"
			  "    m_Level: 0\n"
			  "  m_RayTracedContactShadow: 0\n"
			  "  m_ShadowTint: {r: 0, g: 0, b: 0, a: 1}\n"
			  "  m_PenumbraTint: 0\n"
			  "  m_NormalBias: 0.75\n"
			  "  m_SlopeBias: 0.5\n"
			  "  m_ShadowUpdateMode: 0\n"
			  "  m_AlwaysDrawDynamicShadows: 0\n"
			  "  m_UpdateShadowOnLightMovement: 0\n"
			  "  m_CachedShadowTranslationThreshold: 0.01\n"
			  "  m_CachedShadowAngularThreshold: 0.5\n"
			  "  m_BarnDoorAngle: 90\n"
			  "  m_BarnDoorLength: 0.05\n"
			  "  m_preserveCachedShadow: 0\n"
			  "  m_OnDemandShadowRenderOnPlacement: 1\n"
			  "  m_ShadowCascadeRatios:\n"
			  "  - 0.05\n"
			  "  - 0.2\n"
			  "  - 0.3\n"
				"  m_ShadowCascadeBorders:\n"
				"  - 0.2\n"
				"  - 0.2\n"
				"  - 0.2\n"
				"  - 0.2\n"
				"  m_ShadowAlgorithm: 0\n"
				"  m_ShadowVariant: 0\n"
				"  m_ShadowPrecision: 0\n"
				"  useOldInspector: 0\n"
				"  useVolumetric: 1\n"
				"  featuresFoldout: 1\n"
				"  m_AreaLightEmissiveMeshShadowCastingMode: 0\n"
				"  m_AreaLightEmissiveMeshMotionVectorGenerationMode: 0\n"
				"  m_AreaLightEmissiveMeshLayer: -1\n"
				"  m_Version: 11\n"
				"  m_ObsoleteShadowResolutionTier: 1\n"
				"  m_ObsoleteUseShadowQualitySettings: 0\n"
				"  m_ObsoleteCustomShadowResolution: 512\n"
				"  m_ObsoleteContactShadows: 0\n"
				"  m_PointlightHDType: 0\n"
				"  m_SpotLightShape: 0\n"
				"  m_AreaLightShape: 0\n"
			  ,
			  this->ID, Owner->ID, ScriptGUID, Light->Intensity, Unit );
	}
	return Text;
}
std::string TreeInstancesComponent::GetSceneData()
{
	char Text[ 4096 ];
	snprintf( Text, sizeof( Text ),
			  "--- !u!114 &%lld\n"
			  "MonoBehaviour:\n"
			  "  m_ObjectHideFlags: 0\n"
			  "  m_CorrespondingSourceObject: {fileID: 0}\n"
			  "  m_PrefabInstance: {fileID: 0}\n"
			  "  m_PrefabAsset: {fileID: 0}\n"
			  "  m_GameObject: {fileID: %lld}\n"
			  "  m_Enabled: 1\n"
			  "  m_EditorHideFlags: 0\n"
			  "  m_Script: {fileID: 11500000, guid:7f919289a76fc594f87d8f933c257fc5, type: 3}\n"
			  "  m_Name: \n"
			  "  m_EditorClassIdentifier: \n",
			  this->ID, Owner->ID );

	std::string InstanceText;
	InstanceText += "  position:\n";
	for( int i = 0; i < Instances.size(); i++ )
	{
		TreeInstance* Instance = Instances[ i ];
		char Local[ 256 ] = "";
		snprintf( Local, sizeof( Local ), "  - {x: %f, y: %f, z: %f}\n", Instance->Position.X, Instance->Position.Y, Instance->Position.Z);
		InstanceText += Local;
	}
	InstanceText += "  widthScale:\n";
	for( int i = 0; i < Instances.size(); i++ )
	{
		TreeInstance* Instance = Instances[ i ];
		char Local[ 256 ] = "";
		snprintf( Local, sizeof( Local ), "  - %f\n", Instance->widthScale );
		InstanceText += Local;
	}
	InstanceText += "  heightScale:\n";
	for( int i = 0; i < Instances.size(); i++ )
	{
		TreeInstance* Instance = Instances[ i ];
		char Local[ 256 ] = "";
		snprintf( Local, sizeof( Local ), "  - %f\n", Instance->heightScale );
		InstanceText += Local;
	}
	InstanceText += "  rotation:\n";
	for( int i = 0; i < Instances.size(); i++ )
	{
		TreeInstance* Instance = Instances[ i ];
		char Local[ 256 ] = "";
		snprintf( Local, sizeof( Local ), "  - %f\n", Instance->rotation );
		InstanceText += Local;
	}
	InstanceText += "  Prefab:\n";
	for( int i = 0; i < Instances.size(); i++ )
	{
		TreeInstance* Instance = Instances[ i ];
		char Local[ 256 ] = "";
		std::string PrefabGUID = NullGUID;
		uint64 FileID = 0;
		if( Instance->Prefab )
		{
			FileID = Instance->Prefab->ID;
			PrefabGUID = Instance->Prefab->PrefabGUID;
		}
		snprintf( Local, sizeof( Local ), "  - {fileID: %lld, guid: %s, type: 3}\n", FileID,
				  PrefabGUID.c_str() );
		InstanceText += Local;
	}

	std::string Ret = Text;
	Ret += InstanceText;
	return Ret;
}
void UnityTexture::GenerateGUID()
{
	std::size_t hash = std::hash<std::string>{}( File );
	GUID = GetGUIDFromSizeT( hash );
}
void UnityMesh::GenerateGUID()
{
	std::size_t hash = std::hash<std::string>{}( File );
	GUID = GetGUIDFromSizeT( hash );
}
UnityMaterial::UnityMaterial()
{
	Shader = new UnityShader();
}
void UnityShader::GenerateGUID()
{
	std::size_t hash = std::hash<std::string>{}( FileName );
	GUID = GetGUIDFromSizeT( hash );
}
void UnityMaterial::GenerateGUID()
{
	std::string Input = File + Shader->GUID;
	std::size_t hash = std::hash<std::string>{}( Input );
	GUID = GetGUIDFromSizeT( hash );
}
std::string GenerateGUIDFromString( std::string str )
{
	std::size_t hash = std::hash<std::string>{}( str );
	std::string Ret = GetGUIDFromSizeT( hash );
	return Ret;
}
GameObject::GameObject( )
{
	ID = UnityComponent::GetUniqueID();

	TransformComponent *Trans = new TransformComponent;
	Trans->Owner = this;
	Components.push_back( Trans );
}
UnityComponent* GameObject::AddComponent( ComponentType Type )
{
	if( Type == CT_MESHFILTER )
	{
		MeshFilter *MF = new MeshFilter;
		MF->Owner = this;
		Components.push_back( MF );
		return MF;
	}
	else if( Type == CT_MESHRENDERER )
	{
		MeshRenderer *MR = new MeshRenderer;
		MR->Owner = this;
		Components.push_back( MR );
		return MR;
	}
	else if( Type == CT_SKINNEDMESHRENDERER )
	{
		SkinnedMeshRenderer* SMR = new SkinnedMeshRenderer;
		SMR->Owner = this;
		Components.push_back( SMR );
		return SMR;
	}	
	else if( Type == CT_LIGHT )
	{
		LightComponent* NewLight = new LightComponent;
		NewLight->Owner = this;
		Components.push_back( NewLight );
		return NewLight;
	}
	else if( Type == CT_LODGROUP )
	{
		LodGroup* NewLodGroup = new LodGroup;
		NewLodGroup->Owner = this;
		Components.push_back( NewLodGroup );
		return NewLodGroup;
	}
	else if( Type == CT_MESHCOLLIDER )
	{
		MeshCollider* NewMeshCollider = new MeshCollider;
		NewMeshCollider->Owner = this;
		Components.push_back( NewMeshCollider );
		return NewMeshCollider;
	}
	else if( Type == CT_BOXCOLLIDER )
	{
		BoxCollider* NewBoxCollider = new BoxCollider;
		NewBoxCollider->Owner = this;
		Components.push_back( NewBoxCollider );
		return NewBoxCollider;
	}
	else if( Type == CT_SPHERECOLLIDER )
	{
		SphereCollider* NewSphereCollider = new SphereCollider;
		NewSphereCollider->Owner = this;
		Components.push_back( NewSphereCollider );
		return NewSphereCollider;
	}
	else if( Type == CT_CAPSULECOLLIDER )
	{
		CapsuleCollider* NewCapsuleCollider = new CapsuleCollider;
		NewCapsuleCollider->Owner = this;
		Components.push_back( NewCapsuleCollider );
		return NewCapsuleCollider;
	}
	else if( Type == CT_REFLECTIONPROBE )
	{
		ReflectionProbeComponent* NewReflectionProbeComponent = new ReflectionProbeComponent;
		NewReflectionProbeComponent->Owner = this;
		Components.push_back( NewReflectionProbeComponent );
		return NewReflectionProbeComponent;
	}
	else if( Type == CT_DECAL )
	{
		DecalComponent* NewDecalComponent = new DecalComponent;
		NewDecalComponent->Owner = this;
		Components.push_back( NewDecalComponent );
		return NewDecalComponent;
	}
	else if( Type == CT_ANIMATION )
	{
		AnimationComponent* NewAnimationComponent = new AnimationComponent;
		NewAnimationComponent->Owner = this;
		Components.push_back( NewAnimationComponent );
		return NewAnimationComponent;
	}
	else if( Type == CT_ADDITIONAL_LIGHT_DATA )
	{
		AdditionalLightData* NewAdditionalLightData = new AdditionalLightData;
		NewAdditionalLightData->Owner = this;
		Components.push_back( NewAdditionalLightData );
		return NewAdditionalLightData;
	}
	else if( Type == CT_ADDITIONAL_CAMERA_DATA )
	{
		AdditionalCameraData* NewAdditionalCameraData = new AdditionalCameraData;
		NewAdditionalCameraData->Owner = this;
		Components.push_back( NewAdditionalCameraData );
		return NewAdditionalCameraData;
	}
	else if( Type == CT_TREEINSTANCES )
	{
		TreeInstancesComponent* NewTreeInstancesComponent = new TreeInstancesComponent;
		NewTreeInstancesComponent->Owner = this;
		Components.push_back( NewTreeInstancesComponent );
		return NewTreeInstancesComponent;
	}

	return nullptr;
}
void GameObject::AddChild( GameObject* GO )
{
	Children.push_back( GO );
	GO->Parent = this;
}
UnityComponent* GameObject::GetComponent( ComponentType Type )
{
	for ( int i = 0; i < Components.size(); i++ )
	{
		if ( Components[ i ]->Type == Type )
			return Components[ i ];
	}

	return nullptr;
}
UnityComponent* GameObject::GetComponentInChildren( ComponentType Type )
{
	for( int i = 0; i < Components.size(); i++ )
	{
		if( Components[ i ]->Type == Type )
			return Components[ i ];
	}

	for( int i = 0; i < Children.size(); i++ )
	{
		UnityComponent* Comp = Children[ i ]->GetComponentInChildren( Type );
		if( Comp )
			return Comp;
	}

	return nullptr;
}
GameObject* GameObject::Find( const char* pName )
{
	if( this->Name.compare( pName ) == 0 )
		return this;

	for( int i = 0; i < Children.size(); i++ )
	{
		GameObject* GO = Children[ i ]->Find( pName );
		if ( GO )
			return GO;
	}

	return nullptr;
}
void GameObject::GetAllComponentsInChildren( std::vector< UnityComponent* >& AllComponents )
{
	for( int i = 0; i < Components.size(); i++ )
	{
		AllComponents.push_back( Components[ i ] );
	}

	for( int i = 0; i < Children.size(); i++ )
	{
		Children[ i ]->GetAllComponentsInChildren( AllComponents );
	}
}
std::string GameObject::ToSceneData( bool WritePrefab )
{
	std::string RetStr;

	std::string MainStr = GetGameObjectString( WritePrefab );
	RetStr += MainStr;

	for( int i = 0; i < Components.size(); i++ )
	{
		auto Comp = Components[ i ];
		if( WritePrefab && Comp->Type == ComponentType::CT_TRANSFORM )
		{
			TransformComponent* Trans = (TransformComponent*)Comp;
			TransformComponent OriginalTransform;
			OriginalTransform = *Trans;
			Trans->Reset();
			RetStr += Comp->GetSceneData();
			*Trans = OriginalTransform;
		}
		else
			RetStr += Comp->GetSceneData();
	}

	for( int i = 0; i < Children.size(); i++ )
	{
		auto Child = Children[ i ];
		std::string ChildStr = Child->ToSceneData();
		RetStr += ChildStr;
	}

	return RetStr;
}
std::string GameObject::GeneratePrefabInstance()
{
	if( !PrefabTemplate )
		return "";
	
	TransformComponent* TemplateTransform = ( TransformComponent*)PrefabTemplate->GetComponent( CT_TRANSFORM );
	TransformComponent* InstanceTransform = ( TransformComponent*)GetComponent( CT_TRANSFORM );
	uint64 PrefabTransformID = 0;
	if( TemplateTransform )
		PrefabTransformID = TemplateTransform->ID;

	std::string PrefabID = PrefabTemplate->PrefabGUID;
	char Text[ 4096 ];
	snprintf( Text, sizeof( Text ),
		"--- !u!1001 &%lld\n"
		"PrefabInstance:\n"
		"  m_ObjectHideFlags: 0\n"
		"  serializedVersion: 2\n"
		"  m_Modification:\n"
		"    m_TransformParent: {fileID: 0}\n"
		"    m_Modifications:\n"
		"    - target: {fileID: %lld, guid: %s, type: 3}\n"
		"      propertyPath: m_Name\n"
		"      value: %s\n"
		"      objectReference: {fileID: 0}\n"
		"    - target: {fileID: %lld, guid: %s, type: 3}\n"
		"      propertyPath: m_LocalPosition.x\n"
		"      value: %f\n"
		"      objectReference: {fileID: 0}\n"
		"    - target: {fileID: %lld, guid: %s, type: 3}\n"
		"      propertyPath: m_LocalPosition.y\n"
		"      value: %f\n"
		"      objectReference: {fileID: 0}\n"
		"    - target: {fileID: %lld, guid: %s, type: 3}\n"
		"      propertyPath: m_LocalPosition.z\n"
		"      value: %f\n"
		"      objectReference: {fileID: 0}\n"
		"    - target: {fileID: %lld, guid: %s, type: 3}\n"
		"      propertyPath: m_LocalRotation.x\n"
		"      value: %f\n"
		"      objectReference: {fileID: 0}\n"
		"    - target: {fileID: %lld, guid: %s, type: 3}\n"
		"      propertyPath: m_LocalRotation.y\n"
		"      value: %f\n"
		"      objectReference: {fileID: 0}\n"
		"    - target: {fileID: %lld, guid: %s, type: 3}\n"
		"      propertyPath: m_LocalRotation.z\n"
		"      value: %f\n"
		"      objectReference: {fileID: 0}\n"
		"    - target: {fileID: %lld, guid: %s, type: 3}\n"
		"      propertyPath: m_LocalRotation.w\n"
		"      value: %f\n"
		"      objectReference: {fileID: 0}\n"
		//"    - target: {fileID: %lld, guid: %s, type: 3}\n"
		//"      propertyPath: m_LocalEulerAnglesHint.x\n"
		//"      value: %f\n"
		//"      objectReference: {fileID: 0}\n"
		//"    - target: {fileID: %lld, guid: %s, type: 3}\n"
		//"      propertyPath: m_LocalEulerAnglesHint.y\n"
		//"      value:%f\n"
		//"      objectReference: {fileID: 0}\n"
		//"    - target: {fileID: %lld, guid: %s, type: 3}\n"
		//"      propertyPath: m_LocalEulerAnglesHint.z\n"
		//"      value: %f\n"
		//"      objectReference: {fileID: 0}\n"
		"    - target: {fileID: %lld, guid: %s, type: 3}\n"
		"      propertyPath: m_LocalScale.x\n"
		"      value: %f\n"
		"      objectReference: {fileID: 0}\n"
		"    - target: {fileID: %lld, guid: %s, type: 3}\n"
		"      propertyPath: m_LocalScale.y\n"
		"      value: %f\n"
		"      objectReference: {fileID: 0}\n"
		"    - target: {fileID: %lld, guid: %s, type: 3}\n"
		"      propertyPath: m_LocalScale.z\n"
		"      value: %f\n"
		"      objectReference: {fileID: 0}\n"
		"    m_RemovedComponents: []\n"
		"  m_SourcePrefab: {fileID: 100100000, guid: %s, type: 3}\n", ID, 
			   PrefabTemplate->ID, PrefabID.c_str(), this->Name.c_str(),

			   PrefabTransformID, PrefabID.c_str(), InstanceTransform->LocalPosition[ 0 ],
			   PrefabTransformID, PrefabID.c_str(), InstanceTransform->LocalPosition[ 1 ],
			   PrefabTransformID, PrefabID.c_str(), InstanceTransform->LocalPosition[ 2 ],

			   PrefabTransformID, PrefabID.c_str(), InstanceTransform->LocalRotation[ 0 ],
			   PrefabTransformID, PrefabID.c_str(), InstanceTransform->LocalRotation[ 1 ],
			   PrefabTransformID, PrefabID.c_str(), InstanceTransform->LocalRotation[ 2 ],
			   PrefabTransformID, PrefabID.c_str(), InstanceTransform->LocalRotation[ 3 ],

			   PrefabTransformID, PrefabID.c_str(), InstanceTransform->LocalScale[ 0 ],
			   PrefabTransformID, PrefabID.c_str(), InstanceTransform->LocalScale[ 1 ],
			   PrefabTransformID, PrefabID.c_str(), InstanceTransform->LocalScale[ 2 ],

			   PrefabID.c_str()
	);

	return Text;
}
std::string GameObject::GetGameObjectString( bool WritePrefab )
{
	int serializedVersion = 6;
	
	char Text[ 1024 ];
	snprintf( Text, sizeof( Text ),
		"--- !u!1 &%lld\n"
		"GameObject:\n"
		"  m_ObjectHideFlags: 0\n"
		"  m_CorrespondingSourceObject: {fileID: 0}\n"
		"  m_PrefabInstance: {fileID: 0}\n"
		"  m_PrefabAsset: {fileID: 0}\n"
		"  serializedVersion: %d\n"
		"  m_Component:\n",
			 this->ID, serializedVersion );

	std::string Str = Text;

	for ( int i = 0; i < Components.size(); i++ )
	{
		auto Comp = Components[ i ];
		char Line[ 128 ];
		if ( serializedVersion >= 5 )
		{
			snprintf( Line, sizeof( Line ), "  - component: {fileID: %lld}\n", Comp->ID );
		}		
		
		Str += Line;
	}
	
	const char* TargetName = Name.c_str();
	if( WritePrefab )
		TargetName = PrefabName.c_str();
	snprintf( Text, sizeof( Text ),
	"  m_Layer: 0\n"
	"  m_Name: %s\n"
	"  m_TagString: Untagged\n"
	"  m_Icon: {fileID: 0}\n"
	"  m_NavMeshLayer: 0\n"
	"  m_StaticEditorFlags: 0\n"
	"  m_IsActive: 1\n",
			   TargetName );

	Str += Text;

	return Str;
}
void UnityScene::Add( GameObject* GO )
{
	GameObjects.push_back( GO );
	GO->OwnerScene = this;
}
void UnityScene::Replace( GameObject* Target, GameObject* Replacement )
{
	for( int i = 0; i < GameObjects.size(); i++ )
	{
		GameObject* GO = GameObjects[ i ];
		if( GO == Target )
		{
			GameObjects[ i ] = Replacement;
			break;
		}
	}
}
GameObject* UnityScene::Find( const char* Name )
{
	for( int i = 0; i < GameObjects.size(); i++ )
	{
		GameObject* GO = GameObjects[ i ];
		if( !GO )
			continue;

		if( GO->Name.compare( Name ) == 0 )
			return GO;
	}

	return nullptr;
}
void UnityScene::WriteScene( const char* File, const char* ProxyScene )
{
	#ifdef ENABLE_GODOT_EXPORT
	if( UTUSettings->Engine == EngineType::GODOT )
	{
		WriteSceneForGodot( this, File );
		return;
	}
	#endif

	FILE *f = nullptr;
	f = fopen( File, "w" );
	if( !f )
	{
		return;
	}

	std::string SceneProxy;
	std::string Str = SceneProxy;
	
	for( int i = 0; i < GameObjects.size(); i++ )
	{
		GameObject *GO = GameObjects[ i ];
		if( !GO )
			continue;

		if( !GO->Parent )
		{
			if( UsePrefabs //&& GO->GetComponentInChildren( CT_MESHRENDERER )
						   && GO->PrefabTemplate)
			{
				std::string TextData = GO->GeneratePrefabInstance();
				Str += TextData;
			}
			else
			{
				std::string TextData = GO->ToSceneData();
				Str += TextData;
			}
		}
	}

	unsigned char *ProxySceneData = nullptr;
	int Size = LoadFile( ProxyScene, &ProxySceneData );
	if( !ProxySceneData || Size <= 0 )
	{
		FString Str2 = ProxyScene;
		UE_LOG( LogTemp, Error, TEXT( "LoadFile( %s ) failed" ), *Str2 );
		return;
	}

	std::string FinalSceneData = (char*)ProxySceneData;
	
	FinalSceneData += Str;

	fprintf( f, "%s", FinalSceneData.c_str() );
	fclose( f );
}
void UnityScene::WritePrefabs( const char* PrefabFolder )
{
	#ifdef ENABLE_GODOT_EXPORT
	if( UTUSettings->Engine == EngineType::GODOT )
	{
		WritePrefabsForGodot( this, PrefabFolder );
		return;
	}
	#endif
	for( int i = 0; i < Prefabs.size(); i++ )
	{
		GameObject* GO = Prefabs[ i ];
		
		const char PrefabHeader[] = {
		"%YAML 1.1\n"
		"%TAG !u! tag:unity3d.com,2011:\n"
		};
		std::string TextData = PrefabHeader;
		TextData += GO->ToSceneData( true );

		std::string File = PrefabFolder;
		std::string NameWide = GO->PrefabName;
		File += NameWide;
		File += ".prefab";

		FILE* f = nullptr;
		f = fopen( File.c_str(), "w" );
		if( f )
		{
			fprintf( f, "%s", TextData.c_str() );
			fclose( f );
		}
		GO->PrefabGUID = GenerateGUIDFromString( File );
		std::string PrefabMetaContent = GeneratePrefabMeta( GO->PrefabGUID );

		std::string MetaFile = PrefabFolder;
		MetaFile += NameWide;
		MetaFile += ".prefab.meta";
		f = fopen( MetaFile.c_str(), "w" );
		if( f )
		{
			fprintf( f, "%s", PrefabMetaContent.c_str() );
			fclose( f );
		}
	}
}
std::string UnityScene::GetPrefabName( GameObject* GO )
{
	std::vector< UnityComponent* > AllComponents;
	GO->GetAllComponentsInChildren( AllComponents);

	for( int c = 0; c < AllComponents.size(); c++ )
	{
		if( AllComponents[ c ]->Type == CT_MESHFILTER )
		{
			MeshFilter* MF = (MeshFilter*)AllComponents[ c ];
			return MF->Mesh->Name;
		}
		else if( AllComponents[ c ]->Type == CT_SKINNEDMESHRENDERER )
		{
			SkinnedMeshRenderer* SMR = (SkinnedMeshRenderer*)AllComponents[ c ];
			return SMR->Mesh->Name;
		}
	}

	return "";
}
void UnityScene::FixDuplicatePrefabNames()
{
	if( Prefabs.size() == 0 )
		return;
	for( int i = 0; i < Prefabs.size() - 1; i++ )
	{
		auto PrefabA = Prefabs[ i ];
		int Instances = 1;
		for( int u = i + 1; u < Prefabs.size(); u++ )
		{
			auto PrefabB = Prefabs[ u ];
			//compare disregarding case
			if( stricmp( PrefabA->PrefabName.c_str(), PrefabB->PrefabName.c_str()) == 0)
			{
				char Text[ 32 ];
				snprintf( Text, sizeof( Text ), "_%d", Instances );
				PrefabB->PrefabName += Text;
				Instances++;
			}
		}
	}
}
void UnityScene::EvaluatePrefab( GameObject* GO )
{
	if( !UsePrefabs )
		return;
	bool MustBePrefab = false;
	int FoliageID = -1;
	if( GO->Name.find( "UTU_FoliageID" ) != -1 )
	{
		sscanf( GO->Name.c_str(), "UTU_FoliageID %d", &FoliageID );
		if( FoliageID != -1 )
			MustBePrefab = true;
	}

	bool IsPrefabInstance = false;
	if( !MustBePrefab )
	{
		for( int i = 0; i < Prefabs.size(); i++ )
		{
			std::vector< UnityComponent* > AllComponentsA;
			std::vector< UnityComponent* > AllComponentsB;
			auto Prefab = Prefabs[ i ];
			Prefab->GetAllComponentsInChildren( AllComponentsA );
			GO->GetAllComponentsInChildren( AllComponentsB );

			if( AllComponentsA.size() != AllComponentsB.size() )
				continue;

			bool Identical = true;
			for( int c = 0; c < AllComponentsA.size(); c++ )
			{
				if( AllComponentsA[ c ]->Type != AllComponentsB[ c ]->Type )
				{
					Identical = false;
					break;
				}
				if( AllComponentsA[ c ]->Type == CT_MESHFILTER )
				{
					MeshFilter* MF_A = (MeshFilter*)AllComponentsA[ c ];
					MeshFilter* MF_B = (MeshFilter*)AllComponentsB[ c ];
					if( MF_A->Mesh != MF_B->Mesh )
					{
						Identical = false;
						break;
					}
				}
				if( AllComponentsA[ c ]->Type == CT_MESHRENDERER )
				{
					MeshRenderer* MR_A = (MeshRenderer*)AllComponentsA[ c ];
					MeshRenderer* MR_B = (MeshRenderer*)AllComponentsB[ c ];
					if( MR_A->Materials.size() != MR_B->Materials.size() )
					{
						Identical = false;
						break;
					}
					for( int m = 0; m < MR_A->Materials.size(); m++ )
					{
						if( MR_A->Materials[ m ] != MR_B->Materials[ m ] )
						{
							Identical = false;
							break;
						}
					}
				}
				if( AllComponentsA[ c ]->Type == CT_SKINNEDMESHRENDERER )
				{
					SkinnedMeshRenderer* SMR_A = (SkinnedMeshRenderer*)AllComponentsA[ c ];
					SkinnedMeshRenderer* SMR_B = (SkinnedMeshRenderer*)AllComponentsB[ c ];
					if( SMR_A->Mesh != SMR_B->Mesh )
					{
						Identical = false;
						break;
					}
					if( SMR_A->Materials.size() != SMR_B->Materials.size() )
					{
						Identical = false;
						break;
					}
					for( int m = 0; m < SMR_A->Materials.size(); m++ )
					{
						if( SMR_A->Materials[ m ] != SMR_B->Materials[ m ] )
						{
							Identical = false;
							break;
						}
					}
				}
			}

			if( !Identical )
				continue;

			IsPrefabInstance = true;
			GO->PrefabTemplate = Prefab;
		}
	}

	if( !IsPrefabInstance )
	{
		if( GO->CanBePrefab )
		{
			//Give the prefab the name of the mesh
			GO->PrefabName = GetPrefabName( GO );
			GameObject* PrefabInstance = nullptr;
			
			if( FoliageID == -1 )
			{
				PrefabInstance = new GameObject();
				PrefabInstance->PrefabTemplate = GO;
				PrefabInstance->Name = GO->Name;
			}
			else
			{
				SetupFoliagePrefab( GO, FoliageID );
			}
			TransformComponent* TemplateTransform = (TransformComponent*)GO->GetComponent( CT_TRANSFORM );
			if( FoliageID == -1 )
			{
				TransformComponent* InstanceTransform = (TransformComponent*)PrefabInstance->GetComponent( CT_TRANSFORM );
				InstanceTransform->Copy( *TemplateTransform );
				Replace( GO, PrefabInstance );
			}
			else//remove FoliagePrefabs as instances
				Replace( GO, nullptr );

			Prefabs.push_back( GO );
		}
	}
}
extern GameObject* GameObjectForTrees;
void UnityScene::SetupFoliagePrefab( GameObject* FoliagePrefab, int FoliageID )
{
	if( !GameObjectForTrees )
		return;

	TreeInstancesComponent* TIC = ( TreeInstancesComponent*)GameObjectForTrees->GetComponent( CT_TREEINSTANCES );

	for( int i = 0; i < TIC->Instances.size(); i++ )
	{
		TreeInstancesComponent::TreeInstance* Instance =TIC->Instances[ i ];
		if( Instance->FoliageID == FoliageID )
		{
			Instance->Prefab = FoliagePrefab;
		}
	}
}
std::string GetGUIDFromSizeT( size_t Input )
{
	char Base[] = "abc00000000000000000000000000000";
	char Num[ 32 ];
	#if PLATFORM_WINDOWS
		uint64 Input64 = Input;
	#else
		unsigned long Input64 = Input;
	#endif
	snprintf( Num, sizeof( Num ), "%zu", Input64 );
	int NumLen = strlen( Num );
	std::string GUID = Base;
	for( int i = 32 - NumLen,u = 0; i < 32; i++, u++ )
	{
		GUID[ i ] = Num[ u ];
	}

#ifdef ENABLE_GODOT_EXPORT
	if( UTUSettings->Engine == EngineType::GODOT )
	{
		GUID = GodotInt64ToTextGUID( Input );
	}
#endif
	return GUID;
}

enum FileIDType
{
	FIT_MATERIALS,
	FIT_MESHES,
};
class FileID
{
public:
	FileID( int pBaseID, const char* str, int pIndex = 0)
	{
		BaseID = pBaseID;
		//Type = pType;
		Identifier = str;
		Index = pIndex;
	}
	int BaseID;
	//FileIDType Type;
	int Index;
	std::string Identifier;

	static int GetBase( FileIDType Type )
	{
		switch( Type )
		{
			case FIT_MATERIALS: return 2100000;
			case FIT_MESHES	  : return 4300000;
			default:return Type;
		}

		return Type;
	}
	std::string GetMetaLine()
	{
		//int Base = GetBase( Type );
		int ID = BaseID + Index * 2;
		char Line[ 1024 ];
		snprintf( Line, sizeof( Line ), "    %d: %s\n", ID, Identifier.c_str() );

		return Line;
	}
};
void AddLodObjects( int ID, int NumLods, const char* MeshName, std::string & str )
{
	char Text[ 1024 ] = "";
	for( int i = 0; i < NumLods; i++ )
	{
		snprintf( Text, sizeof( Text ), "    %d: %s_LOD%i\n", ID, MeshName, i );
		ID += 2;
		str += Text;
	}
}
std::string GenerateMaterialIDs( UnityMesh* M )
{
	char Text[ 1024 ] = "";
	std::string MaterialsText;
	for( int i = 0; i < M->Materials.size(); i++ )
	{
		int ID = 2100000 + i * 2;
		snprintf( Text, sizeof( Text ), "    %d: %s\n", ID, M->Materials[ i ]->Name.c_str() );
		MaterialsText += Text;
	}

	return MaterialsText;
}
std::string GenerateFileIDsForBones( UnityMesh* M, int BaseID )
{
	std::string Ret;
	char Text[ 4096 ] = "";
	for( int i = 0; i < M->BoneNames.size(); i++ )
	{
		int ID = BaseID + i * 2;
		snprintf( Text, sizeof( Text ), "    %d: %s\n", ID, M->BoneNames[i].c_str() );
		Ret += Text;
	}

	return Ret;
}
std::string GenerateMeshMetaFileIDs( UnityMesh* M, bool IsFBX, int TotalLods )
{
	const char* MeshName = M->Name.c_str();
	if( IsFBX )
	{
		std::string Ret;
		int TextSize = 4096;
		char* Text = new char[ TextSize ];
		std::string MaterialsText = GenerateMaterialIDs( M );
		if( TotalLods > 1 )
		{
			std::string BoneNames1 = "";
			std::string BoneNames2 = "";
			if( M->BoneNames.size() > 0 )
			{
				int BaseID1 = 100000 + ( TotalLods + 1 ) * 2;
				int BaseID2 = 400000 + ( TotalLods + 1 ) * 2;
				BoneNames1 = GenerateFileIDsForBones( M, BaseID1 );
				BoneNames2 = GenerateFileIDsForBones( M, BaseID2 );
			}
			snprintf( Text, TextSize, "    100000: //RootNode\n" );
			Ret += Text;
			AddLodObjects( 100002, TotalLods, MeshName, Ret );
			Ret += BoneNames1;
			snprintf( Text, TextSize, "    400000: //RootNode\n" );
			Ret += Text;
			AddLodObjects( 400002, TotalLods, MeshName, Ret );
			Ret += BoneNames2;
			Ret += MaterialsText;
			AddLodObjects( 2300000, TotalLods, MeshName, Ret );
			AddLodObjects( 3300000, TotalLods, MeshName, Ret );
			AddLodObjects( 4300000, TotalLods, MeshName, Ret );
			if( M->HasConvexHulls )
			{
				snprintf( Text, TextSize, "    %d: %s_ConvexHulls\n", M->ConvexHullMeshID, MeshName );
				Ret += Text;
			}
			snprintf( Text, TextSize, "    20500000: //RootNode\n" );
			Ret += Text;
		}
		else
		{
			std::string BoneNames1 = "";
			std::string BoneNames2 = "";
			if( M->BoneNames.size() > 0 )
			{
				TextSize = 256 * M->BoneNames.size() * 2;
				delete[]Text;
				Text = new char[ TextSize ];
				BoneNames1 = GenerateFileIDsForBones( M, 100002 );
				BoneNames2 = GenerateFileIDsForBones( M, 400002 );
			}
			snprintf( Text, TextSize,
							 "    100000: //RootNode\n"
							 "%s"
							 "    400000: //RootNode\n"
							 "%s"
							 "%s"
							 "    2300000: //RootNode\n"
							 "    3300000: //RootNode\n"
							 "    4300000: %s\n"
							 "    4300002: %s\n"
					   , BoneNames1.c_str(), BoneNames2.c_str(), MaterialsText.c_str(), MeshName, MeshName
			);
			Ret += Text;
			if( M->HasConvexHulls )
			{
				snprintf( Text, TextSize, "    %d: %s_ConvexHulls\n", M->ConvexHullMeshID, MeshName );
				Ret += Text;
			}
		}
		delete[] Text;
		return Ret;
	}
	else
	{
		int SubMeshes = M->Sections.size();

		std::string Ret;	
		if( SubMeshes <= 1 )
		{
			char Text[ 4096 ] = "";
			snprintf( Text, sizeof( Text ),
				"    100000: %s\n"
				"    100002: //RootNode\n"
				"    400000: %s\n"
				"    400002: //RootNode\n"
				"    2300000: %s\n"
				"    3300000: %s\n"
				"    4300000: %s\n",
						   MeshName, MeshName, MeshName, MeshName, MeshName  );
			return  Text;
		}
		int TextLength = 1024 + SubMeshes * 128;
		char *Text = new char[ TextLength ];

		snprintf( Text, TextLength,
			"    100000: %s\n"
			"    100002: //RootNode\n",
			MeshName );
		Ret += Text;

		std::vector<FileID> FileIDArray;

		//100000: //RootNode
		//400000 : //RootNode
		//2100000 : MI_BS_Screens
		//2100002 : MI_BS_TV_Screen_01
		//2300000 : //RootNode
		//3300000 : //RootNode
		//4300000 : SM_BS_Screen_01_2

		FileIDArray.push_back( FileID( 100000, "//RootNode", 0 ) );
		FileIDArray.push_back( FileID( 400000, "//RootNode", 0 ) );

		for( int i = 0; i < M->Materials.size(); i++ )
		{
			if ( M->Materials[i] )
				FileIDArray.push_back( FileID( 2100000, M->Materials[i]->Name.c_str(), i ) );
		}

		FileIDArray.push_back( FileID( 2300000, "//RootNode", 0 ) );
		FileIDArray.push_back( FileID( 3300000, "//RootNode", 0 ) );

		FileIDArray.push_back( FileID( 4300000, M->Name.c_str(), 0 ) );
	
		for( int i = 0; i < FileIDArray.size(); i++ )
		{
			std::string Line = FileIDArray[ i ].GetMetaLine();
			Ret += Line;
		}

		return Ret;
	}
}

std::string GenerateMeshMeta( UnityMesh* Mesh, bool IsFBX, int TotalLods )
{
	#ifdef ENABLE_GODOT_EXPORT
	if( UTUSettings->Engine == EngineType::GODOT )
	{
		return GenerateGodotMeshImport( Mesh, TotalLods );
	}
	else
	#endif
		return GenerateMeshMetaForUnity( Mesh, IsFBX, TotalLods );
}
std::string GenerateMeshMetaForUnity( UnityMesh* Mesh, bool IsFBX, int TotalLods )
{
	const char* MeshName = Mesh->Name.c_str();
	int SubMeshes = Mesh->Sections.size();
	
	Mesh->GenerateGUID();

	std::string MetaFileIDs = GenerateMeshMetaFileIDs( Mesh, IsFBX, TotalLods );
	
	int TextLength = 4096 + MetaFileIDs.length();
	char *Text = new char[ TextLength ];
	snprintf( Text, TextLength,
"fileFormatVersion: 2\n"
"guid: %s\n"
"ModelImporter:\n"
"  serializedVersion: 23\n"
"  fileIDToRecycleName:\n"
"%s"//MetaFileIDs
"  externalObjects: {}\n"
"  materials:\n"
"    importMaterials: 1\n"
"    materialName: 1\n"
"    materialSearch: 1\n"
"    materialLocation: 0\n"
"  animations:\n"
"    legacyGenerateAnimations: 4\n"
"    bakeSimulation: 0\n"
"    resampleCurves: 1\n"
"    optimizeGameObjects: 0\n"
"    motionNodeName: \n"
"    rigImportErrors: \n"
"    rigImportWarnings: \n"
"    animationImportErrors: \n"
"    animationImportWarnings: \n"
"    animationRetargetingWarnings: \n"
"    animationDoRetargetingWarnings: 0\n"
"    animationCompression: 1\n"
"    animationRotationError: 0.5\n"
"    animationPositionError: 0.5\n"
"    animationScaleError: 0.5\n"
"    animationWrapMode: 0\n"
"    extraExposedTransformPaths: []\n"
"    clipAnimations: []\n"
"    isReadable: 1\n"
"  meshes:\n"
"    lODScreenPercentages: []\n"
"    globalScale: 1\n"
"    meshCompression: 0\n"
"    addColliders: 0\n"
"    importBlendShapes: 1\n"
"    swapUVChannels: 0\n"
"    generateSecondaryUV: 0\n"
"    useFileUnits: 1\n"
"    optimizeMeshForGPU: 0\n"
"    keepQuads: 0\n"
"    weldVertices: 0\n"
"    preserveHierarchy: 0\n"
"    indexFormat : 2\n"
"    secondaryUVAngleDistortion: 8\n"
"    secondaryUVAreaDistortion: 15.000001\n"
"    secondaryUVHardAngle: 88\n"
"    secondaryUVPackMargin: 4\n"
"    useFileScale: 1\n"
"  tangentSpace:\n"
"    normalSmoothAngle: 60\n"
"    normalImportMode: 0\n"
"    tangentImportMode: 0\n"
"  importAnimation: 1\n"
"  copyAvatar: 0\n"
"  humanDescription:\n"
"    serializedVersion: 2\n"
"    human: []\n"
"    skeleton: []\n"
"    armTwist: 0.5\n"
"    foreArmTwist: 0.5\n"
"    upperLegTwist: 0.5\n"
"    legTwist: 0.5\n"
"    armStretch: 0.05\n"
"    legStretch: 0.05\n"
"    feetSpacing: 0\n"
"    rootMotionBoneName: \n"
"    rootMotionBoneRotation: {x: 0, y: 0, z: 0, w: 1}\n"
"    hasTranslationDoF: 0\n"
"    hasExtraRoot: 0\n"
"    skeletonHasParents: 1\n"
"  lastHumanDescriptionAvatarSource: {instanceID: 0}\n"
"  animationType: 2\n"
"  humanoidOversampling: 1\n"
"  additionalBone: 0\n"
"  userData: \n"
"  assetBundleName: \n"
"  assetBundleVariant:\n"

	, Mesh->GUID.c_str(), MetaFileIDs.c_str() );

	std::string Ret;
	Ret = Text;
	delete[] Text;
	return Ret;
}
std::string GenerateAnimationFBXMeta( std::string GUID )//const char* AnimationName )
{
	int TextLength = 4096;
	char* Text = new char[ TextLength ];
	snprintf( Text, TextLength,
			  "fileFormatVersion: 2\n"
			  "guid: %s\n"
			  "ModelImporter:\n"
			  "  serializedVersion: 23\n"
			  "  animations:\n"
			  "    animationWrapMode: 2\n"
			  "  animationType: 1\n"
			 
			  , GUID.c_str() );

	std::string Ret;
	Ret = Text;
	delete[] Text;
	return Ret;
}

extern TAutoConsoleVariable<int> CVarUseStandardMaterial;
extern TAutoConsoleVariable<int> CVarRenderPipeline;
std::string  UnityMaterial::GenerateMaterialFile( )
{
	#ifdef ENABLE_GODOT_EXPORT
	if( UTUSettings->Engine == EngineType::GODOT )
	{
		return GenerateGodotMaterial( this );
	}
	#endif

	std::string Ret;
	if( UTUSettings->Shaders == ShadersType::ST_STANDARD_SHADERS )
	{
		char Text[ 2048 ] = "";
		const char* StandardShaderGUID = "0000000000000000f000000000000000";
		int StandardShaderFileID = 46;
		const char* URPLitShaderGUID	= "933532a4fcc9baf4fa0491de14d08ed7";
		int URPFileID = 4800000;
		const char* URPDecalShaderGUID = "9b4e681081e2b4c469111bb649e2f7ee";
		int64 URPDecalFileID = -6465566751694194690;
		const char* HDRPLitShaderGUID	= "6e4ae4064600d784cac1e41a9e6f2e59";
		int HDRPFileID = 4800000;
		const char* UsedShaderGUID = StandardShaderGUID;
		int64 UsedFileID = StandardShaderFileID;
		int type = 0;
		if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_URP )
		{
			if( IsDecalMaterial )
			{
				UsedShaderGUID = URPDecalShaderGUID;
				UsedFileID = URPDecalFileID;
			}
			else
			{
				UsedShaderGUID = URPLitShaderGUID;
				UsedFileID = URPFileID;
			}
			type = 3;
		}
		if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
		{
			UsedShaderGUID = HDRPLitShaderGUID;
			UsedFileID = HDRPFileID;
			type = 3;
		}
		char ExtraKeywords[2048] = "  - _EMISSION\n";
		if(!EnableEmission )
		{
			ExtraKeywords[0] = 0;
		}
		int SurfaceType = 0;
		if( BaseColorMultiplier.A < 1.0f )
		{
			strcat( ExtraKeywords, "  - _SURFACE_TYPE_TRANSPARENT\n" );
			SurfaceType = 1;
		}
		snprintf( Text, sizeof( Text ),
				   "%%YAML 1.1\n"
				   "%%TAG !u! tag:unity3d.com,2011:\n"
				   "--- !u!114 &-6605459782340829755\n"
				   "MonoBehaviour:\n"
				   "  m_ObjectHideFlags: 11\n"
				   "  m_CorrespondingSourceObject: {fileID: 0}\n"
				   "  m_PrefabInstance: {fileID: 0}\n"
				   "  m_PrefabAsset: {fileID: 0}\n"
				   "  m_GameObject: {fileID: 0}\n"
				   "  m_Enabled: 1\n"
				   "  m_EditorHideFlags: 0\n"
				   "  m_Script: {fileID: 11500000, guid: d0353a89b1f911e48b9e16bdc9f2e058, type: 3}\n"
				   "  m_Name: \n"
				   "  m_EditorClassIdentifier: \n"
				   "  version: 5\n"
				   "--- !u!21 &2100000\n"
				   "Material:\n"
				   "  serializedVersion: 8\n"
				   "  m_ObjectHideFlags: 0\n"
				   "  m_CorrespondingSourceObject: {fileID: 0}\n"
				   "  m_PrefabInstance: {fileID: 0}\n"
				   "  m_PrefabAsset: {fileID: 0}\n"
				   "  m_Name: %s\n"
				   "  m_Shader: {fileID: %lld, guid: %s, type: %d}\n"
				   "  m_ValidKeywords:\n"
				   "%s"
				   "  - _NORMALMAP\n"
				   "  m_InvalidKeywords: []\n"
				   "  m_LightmapFlags: 4\n"
				   "  m_EnableInstancingVariants: 1\n"
				   "  m_DoubleSidedGI: 0\n"
				   "  m_CustomRenderQueue: -1\n"
				   "  stringTagMap:\n"
				   "    RenderType: Opaque\n"
				   "  disabledShaderPasses: []\n"
				   "  m_SavedProperties:\n"
				   "    serializedVersion: 3\n", Name.c_str(), UsedFileID, UsedShaderGUID, type,
				  ExtraKeywords );
		Ret += Text;

		if( Textures.size() > 0 )
		{
			Ret += "    m_TexEnvs:\n";
			const int MaxSemantics = 11;
			const char* SemanticNames[ MaxSemantics ] = {
				"_BaseMap",
				"_BumpMap",
				"_DetailAlbedoMap",
				"_DetailMask",
				"_DetailNormalMap",
				"_EmissionMap",
				"_MainTex",
				"_MetallicGlossMap",
				"_OcclusionMap",
				"_ParallaxMap",
				"_SpecGlossMap"
			};
			if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_URP && IsDecalMaterial )
			{
				SemanticNames[ 0 ] = "Base_Map";
				SemanticNames[ 1 ] = "Normal_Map";
			}
			if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_BUILTIN )
			{
				SemanticNames[ 0 ] = "_MainTex";
				SemanticNames[ 6 ] = nullptr;
			}
			if( CVarRenderPipeline.GetValueOnAnyThread() == (int)RenderPipeline::RP_HDRP )
			{
				SemanticNames[ 0 ] = "_BaseColorMap";
				SemanticNames[ 1 ] = "_NormalMap";
				SemanticNames[ 2 ] = "_DetailMap";
				SemanticNames[ 5 ] = "_EmissiveColorMap";
				SemanticNames[ 7 ] = "_MaskMap";
			}
			
			for( int i = 0; i < MaxSemantics; i++ )
			{
				if( !SemanticNames[ i ] )
					continue;
				TextureSemantic Semantic = (TextureSemantic)( i + 1 );
				UnityTexture* Tex = GetTexture( Semantic );
				std::string TexGUID = NullGUID;
				if( Tex )
				{
					TexGUID = Tex->GUID;
					if( Semantic == TS_MetallicGlossMap )
					{
						//Makes smoothness take texture value without modifying it
						SmoothnessMultiplier = 1.0f;
					}
				}

				snprintf( Text, sizeof( Text ), "    - %s:\n", SemanticNames [i] );
				Ret += Text;

				if( Tex )
				{
					snprintf( Text, sizeof( Text ), "        m_Texture: {fileID: 2800000, guid: %s, type: 3}\n",
							   TexGUID.c_str() );
				}
				else
					snprintf( Text, sizeof( Text ), "        m_Texture: {fileID: 0}\n" );

				Ret += Text;
				snprintf( Text, sizeof( Text ),
						   "        m_Scale: {x: 1, y: 1}\n"
						   "        m_Offset: {x: 0, y: 0}\n" );

				Ret += Text;
			}
		}
		
		snprintf( Text, sizeof( Text ),
				   "    m_Ints: []\n"
				   "    m_Floats:\n"
				   "    - _DstBlend: 0\n"
				   "    - _SrcBlend: 1\n"
				   "    - _UVSec: 0\n"
				   "    - _ZWrite: 1\n"
				   "    - _Smoothness: %f\n"
				   "    - _AlphaClip: %d\n"
				   "    - _Cutoff: 0.333\n"
				   "    - _Cull: %1f\n"
				   "    - _Surface: %d\n"
				   "    m_Colors:\n"
				   "    - _BaseColor: {r: %f, g: %f, b: %f, a: %f}\n"
				   "    - _Color: {r: %f, g: %f, b: %f, a: %f}\n"
				   "    - _EmissionColor: {r: %f, g: %f, b: %f, a: %f}\n"
				   "    - _SpecColor: {r: 0.5, g : 0.5, b : 0.5, a : 0.5}\n"
				   "  m_BuildTextureStacks: []\n",
				  SmoothnessMultiplier, HasOpacityMask, CullMode, SurfaceType,
				  BaseColorMultiplier.R, BaseColorMultiplier.G, BaseColorMultiplier.B, BaseColorMultiplier.A,
				  BaseColorMultiplier.R, BaseColorMultiplier.G, BaseColorMultiplier.B, BaseColorMultiplier.A,
				  EmissionColor.R, EmissionColor.G, EmissionColor.B, EmissionColor.A
		);

		Ret += Text;
	}
	else
	{
		int serializedVersion = 3;
		char Text[ 2048 ] = "";
		int m_CustomRenderQueue = -1;
		if( IsDecalMaterial )
		{
			m_CustomRenderQueue = 2000 + DecalDrawOrder;
		}
		snprintf( Text, sizeof( Text ),
				   "%%YAML 1.1\n"
				   "%%TAG !u! tag:unity3d.com,2011:\n"
				   "--- !u!21 &2100000\n"
				   "Material:\n"
				   "  serializedVersion: 6\n"
				   "  m_ObjectHideFlags: 0\n"
				   "  m_CorrespondingSourceObject: {fileID: 0}\n"
				   "  m_PrefabInstance: {fileID: 0}\n"
				   "  m_PrefabAsset: {fileID: 0}\n"
				   "  m_Name: %s\n"
				   "  m_Shader: {fileID: 4800000, guid: %s, type: 3}\n"
				   "  m_ShaderKeywords: \n"
				   "  m_LightmapFlags: 4\n"
				   "  m_EnableInstancingVariants: 1\n"
				   "  m_DoubleSidedGI: 0\n"
				   "  m_CustomRenderQueue: %d\n"
				   "  stringTagMap: {}\n"
				   "  disabledShaderPasses: []\n"
				   "  m_SavedProperties:\n"
				   "    serializedVersion: %d\n", Name.c_str(), Shader->GUID.c_str(), m_CustomRenderQueue, serializedVersion );
		Ret += Text;

		if( Textures.size() > 0 )
		{
			Ret += "    m_TexEnvs:\n";
		}
		for( int i = 0; i < Textures.size(); i++ )
		{
			auto Tex = Textures[ i ];
			std::string TexGUID = NullGUID;
			if( Tex )
				TexGUID = Tex->GUID;

			if( serializedVersion == 3 )//Unity 2017.1
			{
				const char* Tex2D = "Material_Texture2D_";
				int Tex2DFileID = 2800000;
				const char* TexCube = "Material_TextureCube_";
				int TexCubeFileID = 8900000;
				const char* Tex2DArray = "Material_Texture2DArray_";
				int Tex2DArrayFileID = 18700000;
				const char* Tex3D = "Material_VolumeTexture_";
				int Tex3DFileID = 11700000;
				const char* Prefix = Tex2D;
				int fileID = Tex2DFileID;
				int TexIndex = i;
				if( Tex && Tex->Shape == UTS_Cube )
				{
					Prefix = TexCube;
					fileID = TexCubeFileID;
					TexIndex = Tex->SpecificIndex;
				}
				if( Tex && Tex->Shape == UTS_2DArray )
				{
					Prefix = Tex2DArray;
					fileID = Tex2DArrayFileID;
					TexIndex = Tex->SpecificIndex;
				}
				if( Tex && Tex->Shape == UTS_3D )
				{
					Prefix = Tex3D;
					fileID = Tex3DFileID;
					TexIndex = Tex->SpecificIndex;
				}
				if( Tex && Tex->IsVirtual )
				{
					Prefix = "Material_VirtualTexturePhysical_";
					TexIndex = Tex->SpecificIndex;
				}
				snprintf( Text, sizeof( Text ),
						   "    - %s%d:\n"
						   "        m_Texture: {fileID: %d, guid: %s, type: 3}\n"
						   "        m_Scale: {x: 1, y: 1}\n"
						   "        m_Offset: {x: 0, y: 0}\n",
						   Prefix,
						   TexIndex,
						   fileID,
						   TexGUID.c_str() );
			}

			Ret += Text;
		}

		snprintf( Text, sizeof( Text ),
				  "    m_Ints: []\n" );
		Ret += Text;

		snprintf( Text, sizeof( Text ),
				  "    m_Floats:\n" );
		Ret += Text;
		if( IsDecalMaterial )
		{
			snprintf( Text, sizeof( Text ),
					  "    - _DecalMeshBiasType: 0\n"
					  "    - _DecalMeshDepthBias: 0\n"
					  "    - _DecalMeshViewBias: 0\n"
					  "    - _DrawOrder: %d\n", DecalDrawOrder );
			Ret += Text;
		}

		snprintf( Text, sizeof( Text ),
				  "    - _DstBlend: 0\n"
				  "    - _SrcBlend: 1\n"
				  "    - _UVSec: 0\n"
				  "    - _ZWrite: 1\n" );
		Ret += Text;

		snprintf( Text, sizeof( Text ),
				   "    m_Colors:\n"
				   "    - _Color: {r: 0.8, g: 0.8, b: 0.8, a: 1}\n"
				   "    - _EmissionColor: {r: 0, g: 0, b: 0, a: 1}\n" );
		Ret += Text;
	}
	
	return Ret;
}
UnityTexture* UnityMaterial::GetTexture( TextureSemantic Semantic )
{
	for( int i = 0; i < Textures.size(); i++ )
	{
		if( Textures[ i ]->Semantic == Semantic )
		{
			return Textures[ i ];
		}
	}

	return nullptr;
}
std::string  GenerateMaterialMeta( std::string GUID )
{

	char Text[ 2048 ] = "";
	snprintf( Text, sizeof( Text ),
"fileFormatVersion: 2\n"
"guid: %s\n"
"NativeFormatImporter:\n"
"  mainObjectFileID: 2100000\n"
"  userData: \n"
"  assetBundleName: \n"
"  assetBundleVariant: \n",
	GUID.c_str() );

	return Text;
}

std::string  GenerateShaderMeta( std::string GUID )
{
	char Text[ 2048 ] = "";
	snprintf( Text, sizeof( Text ),
"fileFormatVersion: 2\n"
"guid: %s\n"
"ShaderImporter:\n"
"  defaultTextures: []\n"
"  userData: \n"
"  assetBundleName: \n"
"  assetBundleVariant: \n",
GUID.c_str() );

	return Text;
}

std::string  GenerateTextureMeta( UnityTexture* Tex, bool IsNormalMap, int sRGB, UnityTextureShape Shape, int TileX, int TileY,
								  int TextureCompression )
{
	#ifdef ENABLE_GODOT_EXPORT
		if( UTUSettings->Engine == EngineType::GODOT )
		{
			return GenerateGodotTextureImport( Tex, IsNormalMap, sRGB, Shape, TileX, TileY, TextureCompression );
		}
	#endif
	char Text[ 2048 ] = "";

	//int sRGB = 1;
	int texturetype = 0;
	
	if( IsNormalMap )
	{
		//sRGB = 0;
		texturetype = 1;
	}

	int textureShape = 1;
	if( Shape == UTS_Cube )
		textureShape = 2;
	else if( Shape == UTS_2DArray )
		textureShape = 4;
	else if ( Shape == UTS_3D )
		textureShape = 8;

	int serializedVersion = 4;
	if ( serializedVersion == 4 )
	{
	snprintf( Text, sizeof( Text ),
	"fileFormatVersion: 2\n"
	"guid: %s\n"	
	"TextureImporter:\n"
	"  fileIDToRecycleName: {}\n"
	"  serializedVersion: 4\n"
	"  mipmaps:\n"
	"    mipMapMode: 0\n"
	"    enableMipMap: 1\n"
	"    sRGBTexture: %d\n"
	"    linearTexture: 0\n"
	"    fadeOut: 0\n"
	"    borderMipMap: 0\n"
	"    mipMapsPreserveCoverage: 0\n"
	"    alphaTestReferenceValue: 0.5\n"
	"    mipMapFadeDistanceStart: 1\n"
	"    mipMapFadeDistanceEnd: 3\n"
	"  bumpmap:\n"
	"    convertToNormalMap: 0\n"
	"    externalNormalMap: 0\n"
	"    heightScale: 0.25\n"
	"    normalMapFilter: 0\n"
	"  isReadable: 0\n"
	"  grayScaleToAlpha: 0\n"
	"  generateCubemap: 6\n"
	"  cubemapConvolution: 0\n"
	"  seamlessCubemap: 0\n"
	"  textureFormat: 1\n"
	"  maxTextureSize: 8192\n"
	"  textureSettings:\n"
	"    serializedVersion: 2\n"
	"    filterMode: -1\n"
	"    aniso: -1\n"
	"    mipBias: -1\n"
	"    wrapU: -1\n"
	"    wrapV: -1\n"
	"    wrapW: -1\n"
	"  nPOTScale: 0\n"
	"  lightmap: 0\n"
	"  compressionQuality: 50\n"
	"  spriteMode: 0\n"
	"  spriteExtrude: 1\n"
	"  spriteMeshType: 1\n"
	"  alignment: 0\n"
	"  spritePivot: {x: 0.5, y: 0.5}\n"
	"  spriteBorder: {x: 0, y: 0, z: 0, w: 0}\n"
	"  spritePixelsToUnits: 100\n"
	"  alphaUsage: 1\n"
	"  alphaIsTransparency: 0\n"
	"  spriteTessellationDetail: -1\n"
	"  textureType: %d\n"
	"  textureShape: %d\n"
	"  singleChannelComponent: 0\n"
	"  flipbookRows : %d\n"
	"  flipbookColumns : %d\n"
	"  maxTextureSizeSet: 0\n"
	"  compressionQualitySet: 0\n"
	"  textureFormatSet: 0\n"
	"  platformSettings:\n"
	"  - buildTarget: DefaultTexturePlatform\n"
	"    maxTextureSize: 8192\n"
	"    textureFormat: -1\n"
	"    textureCompression: %d\n"
	"    compressionQuality: 50\n"
	"    crunchedCompression: 0\n"
	"    allowsAlphaSplitting: 0\n"
	"    overridden: 0\n"
	"  spriteSheet:\n"
	"    serializedVersion: 2\n"
	"    sprites: []\n"
	"    outline: []\n"
	"    physicsShape: []\n"
	"  spritePackingTag: \n"
	"  userData: \n"
	"  assetBundleName: \n"
	"  assetBundleVariant: \n",
				   Tex->GUID.c_str(), sRGB, texturetype, textureShape, TileY, TileX, TextureCompression );
	}
	return Text;
}
std::string  GeneratePrefabMeta( std::string GUID )
{
	char Text[ 2048 ] = "";
	snprintf( Text, sizeof( Text ),
			   "fileFormatVersion: 2\n"
			   "guid: %s\n"
			   "PrefabImporter:\n"
			   "  externalObjects: {}\n"
			   "  userData: \n"
			   "  assetBundleName: \n"
			   "  assetBundleVariant: \n",
			   GUID.c_str()
	);
	return Text;
}
UnityLightIntensityUnity GetUnityLightIntensity( ELightUnits Unit )
{
	switch( Unit )
	{
		default: return LIU_LUX;
		case ELightUnits::Candelas: return LIU_CANDELAS;
		case ELightUnits::Lumens: return LIU_LUMENS;
	}
}
void TranslateLightDataForUnity( ULightComponent* LightComp, LightComponent* NewLightComponent, AdditionalLightData* LightData )
{
	ELightComponentType Type = LightComp->GetLightType();
	if( Type == LightType_Directional )
	{
		UDirectionalLightComponent* DirectionalLightComp = Cast< UDirectionalLightComponent>( LightComp );

		float Brightness = DirectionalLightComp->ComputeLightBrightness();
		if( UTUSettings->ScriptableRenderPipeline == RenderPipeline::RP_HDRP )
		{
			//HDRP uses Lux for directional light as well
			NewLightComponent->Intensity = DirectionalLightComp->Intensity;
		}
		else
			NewLightComponent->Intensity = DirectionalLightComp->Intensity;// Brightness / PI;
	}
	else if( Type == LightType_Point )
	{
		UPointLightComponent* PointLightComp = Cast< UPointLightComponent>( LightComp );
		NewLightComponent->Range = PointLightComp->AttenuationRadius / 100.0f;

		if( UTUSettings->ScriptableRenderPipeline == RenderPipeline::RP_HDRP && PointLightComp->IntensityUnits != ELightUnits::Unitless )
		{
			LightData->Unit = GetUnityLightIntensity( PointLightComp->IntensityUnits );
			NewLightComponent->Intensity = PointLightComp->Intensity;
		}
		else
		{
			if( PointLightComp->IntensityUnits != ELightUnits::Candelas )
			{
				float LastLightBrigtness = PointLightComp->ComputeLightBrightness();
				PointLightComp->IntensityUnits = ELightUnits::Candelas;
			#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 26) || ENGINE_MAJOR_VERSION == 5
				PointLightComp->SetLightBrightness( LastLightBrigtness );
			#endif
			}

			if( UTUSettings->ScriptableRenderPipeline == RenderPipeline::RP_HDRP )
				NewLightComponent->Intensity = PointLightComp->Intensity;
			else if ( UTUSettings->ScriptableRenderPipeline == RenderPipeline::RP_URP )
				NewLightComponent->Intensity = PointLightComp->Intensity * 3.0f;
			else
				NewLightComponent->Intensity = PointLightComp->Intensity / 3.0f;
		}
	}
	else if( Type == LightType_Spot )
	{
		USpotLightComponent* SpotLightComp = Cast< USpotLightComponent>( LightComp );
		NewLightComponent->Range = SpotLightComp->AttenuationRadius / 100.0f;
		NewLightComponent->SpotAngle = ConvertSpotAngle( SpotLightComp->OuterConeAngle );

		if( UTUSettings->ScriptableRenderPipeline == RenderPipeline::RP_HDRP && SpotLightComp->IntensityUnits != ELightUnits::Unitless )
		{
			LightData->Unit = GetUnityLightIntensity( SpotLightComp->IntensityUnits );
			NewLightComponent->Intensity = SpotLightComp->Intensity;
		}
		else
		{
			if( SpotLightComp->IntensityUnits != ELightUnits::Candelas )
			{
				float LastLightBrigtness = SpotLightComp->ComputeLightBrightness();
				SpotLightComp->IntensityUnits = ELightUnits::Candelas;
			#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 26) || ENGINE_MAJOR_VERSION == 5
				SpotLightComp->SetLightBrightness( LastLightBrigtness );
			#endif
			}

			if( UTUSettings->ScriptableRenderPipeline == RenderPipeline::RP_HDRP )
				NewLightComponent->Intensity = SpotLightComp->Intensity;
			else if( UTUSettings->ScriptableRenderPipeline == RenderPipeline::RP_URP )
				NewLightComponent->Intensity = SpotLightComp->Intensity * 3.0f;
			else
				NewLightComponent->Intensity = SpotLightComp->Intensity / 3.0f;
		}
	}
	else if( Type == LightType_Rect )
	{
		URectLightComponent* RectLightComponent = Cast< URectLightComponent>( LightComp );

		NewLightComponent->Width = RectLightComponent->SourceHeight / 100.0f;
		NewLightComponent->Height = RectLightComponent->SourceWidth / 100.0f;
		NewLightComponent->Range = RectLightComponent->AttenuationRadius / 100.0f;

		if( UTUSettings->ScriptableRenderPipeline == RenderPipeline::RP_HDRP && RectLightComponent->IntensityUnits != ELightUnits::Unitless )
		{
			LightData->Unit = GetUnityLightIntensity( RectLightComponent->IntensityUnits );
			NewLightComponent->Intensity = RectLightComponent->Intensity;
		}
		else
		{
			if( RectLightComponent->IntensityUnits != ELightUnits::Candelas )
			{
				float LastLightBrigtness = RectLightComponent->ComputeLightBrightness();
				RectLightComponent->IntensityUnits = ELightUnits::Candelas;
			#if (ENGINE_MAJOR_VERSION == 4 && ENGINE_MINOR_VERSION >= 26) || ENGINE_MAJOR_VERSION == 5
				RectLightComponent->SetLightBrightness( LastLightBrigtness );
			#endif
			}

			if( UTUSettings->ScriptableRenderPipeline == RenderPipeline::RP_HDRP )
				NewLightComponent->Intensity = RectLightComponent->Intensity;
			else if( UTUSettings->ScriptableRenderPipeline == RenderPipeline::RP_URP )
				NewLightComponent->Intensity = RectLightComponent->Intensity * 3.0f;
			else
				NewLightComponent->Intensity = RectLightComponent->Intensity / 3.0f;
		}
	}
}
#endif